
#ifndef _C11_st531_
#define _C11_st531_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_CHARACTER_32 F792_10232(EIF_REFERENCE);
extern EIF_REFERENCE F792_10234(EIF_REFERENCE);
extern EIF_BOOLEAN F792_10235(EIF_REFERENCE);
extern void F792_10236(EIF_REFERENCE);
extern void F792_10237(EIF_REFERENCE);
extern EIF_REFERENCE F792_10238(EIF_REFERENCE);
extern void EIF_Minit531(void);
extern char *(*R14989[])();

#ifdef __cplusplus
}
#endif

#endif
