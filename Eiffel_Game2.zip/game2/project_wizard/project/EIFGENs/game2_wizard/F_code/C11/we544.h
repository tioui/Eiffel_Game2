
#ifndef _C11_we544_
#define _C11_we544_

#ifdef __cplusplus
extern "C" {
#endif

extern void F766_11031(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F766_11032(EIF_REFERENCE, EIF_REFERENCE, EIF_REFERENCE);
extern void F766_11035(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F766_11036(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void EIF_Minit544(void);
extern long O11797[];

#ifdef __cplusplus
}
#endif

#endif
