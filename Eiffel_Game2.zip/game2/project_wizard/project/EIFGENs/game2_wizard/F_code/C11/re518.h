
#ifndef _C11_re518_
#define _C11_re518_

#ifdef __cplusplus
extern "C" {
#endif

extern void F740_9848(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F740_9852(EIF_REFERENCE);
extern EIF_REFERENCE F740_9853(EIF_REFERENCE);
extern void F740_9857(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit518(void);

#ifdef __cplusplus
}
#endif

#endif
