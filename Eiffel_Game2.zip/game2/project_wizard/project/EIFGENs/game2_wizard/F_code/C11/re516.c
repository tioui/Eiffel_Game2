/*
 * Code for class REFLECTED_OBJECT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re516.h"
#include "eif_built_in.h"
#include "eif_internal.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REFLECTED_OBJECT}.field */
EIF_REFERENCE F738_9775 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	switch (F738_9791(Current, arg1)) {
		case 9L:
			Result = RTLNS(eif_new_type(1342, 0x00).id, 1342, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_INTEGER_8 *)Result = F738_9803(Current, arg1);
			break;
		case 10L:
			Result = RTLNS(eif_new_type(1375, 0x00).id, 1375, _OBJSIZ_0_0_1_0_0_0_0_0_);
			*(EIF_INTEGER_16 *)Result = F738_9804(Current, arg1);
			break;
		case 4L:
			Result = RTLNS(eif_new_type(1366, 0x00).id, 1366, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_INTEGER_32 *)Result = F738_9805(Current, arg1);
			break;
		case 11L:
			Result = RTLNS(eif_new_type(1345, 0x00).id, 1345, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_INTEGER_64 *)Result = F738_9806(Current, arg1);
			break;
		case 13L:
			Result = RTLNS(eif_new_type(1372, 0x00).id, 1372, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_NATURAL_8 *)Result = F738_9799(Current, arg1);
			break;
		case 14L:
			Result = RTLNS(eif_new_type(1351, 0x00).id, 1351, _OBJSIZ_0_0_1_0_0_0_0_0_);
			*(EIF_NATURAL_16 *)Result = F738_9800(Current, arg1);
			break;
		case 15L:
			Result = RTLNS(eif_new_type(1348, 0x00).id, 1348, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_NATURAL_32 *)Result = F738_9801(Current, arg1);
			break;
		case 16L:
			Result = RTLNS(eif_new_type(1357, 0x00).id, 1357, _OBJSIZ_0_0_0_0_0_0_1_0_);
			*(EIF_NATURAL_64 *)Result = F738_9802(Current, arg1);
			break;
		case 5L:
			Result = RTLNS(eif_new_type(1354, 0x00).id, 1354, _OBJSIZ_0_0_0_0_1_0_0_0_);
			*(EIF_REAL_32 *)Result = F738_9807(Current, arg1);
			break;
		case 6L:
			Result = RTLNS(eif_new_type(1360, 0x00).id, 1360, _OBJSIZ_0_0_0_0_0_0_0_1_);
			*(EIF_REAL_64 *)Result = F738_9809(Current, arg1);
			break;
		case 2L:
			Result = RTLNS(eif_new_type(1369, 0x00).id, 1369, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_CHARACTER_8 *)Result = F738_9796(Current, arg1);
			break;
		case 12L:
			Result = RTLNS(eif_new_type(1339, 0x00).id, 1339, _OBJSIZ_0_0_0_1_0_0_0_0_);
			*(EIF_CHARACTER_32 *)Result = F738_9797(Current, arg1);
			break;
		case 3L:
			Result = RTLNS(eif_new_type(1363, 0x00).id, 1363, _OBJSIZ_0_1_0_0_0_0_0_0_);
			*(EIF_BOOLEAN *)Result = F738_9798(Current, arg1);
			break;
		case 0L:
			Result = RTLNS(eif_new_type(1408, 0x00).id, 1408, _OBJSIZ_0_0_0_0_0_1_0_0_);
			*(EIF_POINTER *)Result = F738_9808(Current, arg1);
			break;
		case 1L:
		case 7L:
			Result = F738_9776(Current, arg1);
			break;
		default:
			RTEC(EN_WHEN);
	}
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.reference_field */
EIF_REFERENCE F738_9776 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_REFERENCE) eif_builtin_ISE_RUNTIME_reference_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.field_type */
EIF_INTEGER_32 F738_9791 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	
	
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O9185[Dtype(Current)-737]);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) eif_builtin_ISE_RUNTIME_field_type_of_type (arg1, ti4_1);
}

/* {REFLECTED_OBJECT}.character_8_field */
EIF_CHARACTER_8 F738_9796 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_CHARACTER_8 Result = ((EIF_CHARACTER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_CHARACTER_8) eif_builtin_ISE_RUNTIME_character_8_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.character_32_field */
EIF_CHARACTER_32 F738_9797 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_CHARACTER_32 Result = ((EIF_CHARACTER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_CHARACTER_32) eif_builtin_ISE_RUNTIME_character_32_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.boolean_field */
EIF_BOOLEAN F738_9798 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_BOOLEAN) eif_builtin_ISE_RUNTIME_boolean_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.natural_8_field */
EIF_NATURAL_8 F738_9799 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_NATURAL_8 Result = ((EIF_NATURAL_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_NATURAL_8) eif_builtin_ISE_RUNTIME_natural_8_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.natural_16_field */
EIF_NATURAL_16 F738_9800 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_NATURAL_16 Result = ((EIF_NATURAL_16) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_NATURAL_16) eif_builtin_ISE_RUNTIME_natural_16_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.natural_32_field */
EIF_NATURAL_32 F738_9801 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_NATURAL_32) eif_builtin_ISE_RUNTIME_natural_32_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.natural_64_field */
EIF_NATURAL_64 F738_9802 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_NATURAL_64 Result = ((EIF_NATURAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_NATURAL_64) eif_builtin_ISE_RUNTIME_natural_64_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.integer_8_field */
EIF_INTEGER_8 F738_9803 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_8 Result = ((EIF_INTEGER_8) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_INTEGER_8) eif_builtin_ISE_RUNTIME_integer_8_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.integer_16_field */
EIF_INTEGER_16 F738_9804 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_16 Result = ((EIF_INTEGER_16) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_INTEGER_16) eif_builtin_ISE_RUNTIME_integer_16_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.integer_32_field */
EIF_INTEGER_32 F738_9805 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_INTEGER_32) eif_builtin_ISE_RUNTIME_integer_32_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.integer_64_field */
EIF_INTEGER_64 F738_9806 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_64 Result = ((EIF_INTEGER_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_INTEGER_64) eif_builtin_ISE_RUNTIME_integer_64_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.real_32_field */
EIF_REAL_32 F738_9807 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_32 Result = ((EIF_REAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_REAL_32) eif_builtin_ISE_RUNTIME_real_32_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.pointer_field */
EIF_POINTER F738_9808 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_POINTER) eif_builtin_ISE_RUNTIME_pointer_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.real_64_field */
EIF_REAL_64 F738_9809 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(Current)-738])(Current);
	Result = (EIF_REAL_64) eif_builtin_ISE_RUNTIME_real_64_field (arg1, tp1, ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {REFLECTED_OBJECT}.field_count */
EIF_INTEGER_32 F738_9829 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	
	
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O9185[Dtype(Current)-737]);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) ei_count_field_of_type(((EIF_INTEGER) ti4_1));
}

void EIF_Minit516 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
