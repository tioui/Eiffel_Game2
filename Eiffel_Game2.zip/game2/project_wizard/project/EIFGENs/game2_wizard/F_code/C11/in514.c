/*
 * Code for class INTERNAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in514.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTERNAL}.type_name */
EIF_REFERENCE F736_9714 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = F1_5(arg1);
	Result = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R13939[Dtype(tr1)-1289])(RTCW(tr1));
	RTLE;
	return Result;
}

/* {INTERNAL}.dynamic_type */
EIF_INTEGER_32 F736_9715 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(9767,F736_9767,(Current));
	tr2 = RTCCL(arg1);
	F740_9857(RTCW(tr1), tr2);
	Result = *(EIF_INTEGER_32 *)(RTCV(RTOSCF(9767,F736_9767,(Current)))+ _LNGOFF_1_0_0_0_);
	RTLE;
	return Result;
}

/* {INTERNAL}.field */
EIF_REFERENCE F736_9718 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg2);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTOSCF(9767,F736_9767,(Current));
	tr2 = RTCCL(arg2);
	F740_9857(RTCW(tr1), tr2);
	tr1 = RTOSCF(9767,F736_9767,(Current));
	Result = F738_9775(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {INTERNAL}.field_name */
EIF_REFERENCE F736_9720 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = RTCCL(arg2);
	ti4_1 = F736_9715(Current, tr1);
	Result = F735_9695(Current, arg1, ti4_1);
	RTLE;
	return Result;
}

/* {INTERNAL}.field_count */
EIF_INTEGER_32 F736_9761 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tr1 = RTOSCF(9767,F736_9767,(Current));
	tr2 = RTCCL(arg1);
	F740_9857(RTCW(tr1), tr2);
	Result = F738_9829(RTCV(RTOSCF(9767,F736_9767,(Current))));
	RTLE;
	return Result;
}

/* {INTERNAL}.reflected_object */
static EIF_REFERENCE F736_9767_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (9767);
#define Result RTOSR(9767)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(739, 0x01).id, 739, _OBJSIZ_1_0_0_2_0_0_0_0_);
	F740_9848(RTCW(tr1), Current);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9767);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F736_9767 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9767,F736_9767_body,(Current));
}

void EIF_Minit514 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
