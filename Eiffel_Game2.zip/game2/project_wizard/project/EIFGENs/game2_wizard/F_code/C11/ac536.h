
#ifndef _C11_ac536_
#define _C11_ac536_

#ifdef __cplusplus
extern "C" {
#endif

extern void F947_10424(EIF_REFERENCE, EIF_INTEGER_32);
extern void F947_10425(EIF_REFERENCE, EIF_INTEGER_32);
extern void F947_10428(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F947_10429(EIF_REFERENCE);
extern void F947_10430(EIF_REFERENCE);
extern EIF_REFERENCE F947_10431(EIF_REFERENCE);
extern void EIF_Minit536(void);
extern void F946_10412(EIF_REFERENCE, EIF_REFERENCE);
extern void F1082_11663(EIF_REFERENCE);
extern void F946_10403(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R10442[])();

#ifdef __cplusplus
}
#endif

#endif
