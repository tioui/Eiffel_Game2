/*
 * Code for class WEL_SHARED_METRICS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we503.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_SHARED_METRICS}.metrics */
static EIF_REFERENCE F709_9510_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9510);
#define Result RTOSR(9510)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1727, 0x01).id, 1727, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (9510);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F709_9510 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9510,F709_9510_body,(Current));
}

void EIF_Minit503 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
