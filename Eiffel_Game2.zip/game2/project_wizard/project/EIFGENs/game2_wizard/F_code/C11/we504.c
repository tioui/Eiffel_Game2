/*
 * Code for class WEL_TVI_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we504.h"
#include "cctrl.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_TVI_CONSTANTS}.tvi_root */
EIF_POINTER F710_9511 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) TVI_ROOT;
	return Result;
}

/* {WEL_TVI_CONSTANTS}.tvi_first */
EIF_POINTER F710_9512 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) TVI_FIRST;
	return Result;
}

/* {WEL_TVI_CONSTANTS}.tvi_last */
EIF_POINTER F710_9513 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) TVI_LAST;
	return Result;
}

void EIF_Minit504 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
