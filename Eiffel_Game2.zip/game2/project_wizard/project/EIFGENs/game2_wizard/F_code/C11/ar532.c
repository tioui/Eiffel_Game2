/*
 * Code for class ARGUMENTS_32
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar532.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENTS_32}.argument */
EIF_REFERENCE F793_10241 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(10259,F793_10259,(Current));
	Result = F1015_10908(RTCW(tr1), arg1);
	RTLE;
	return Result;
}

/* {ARGUMENTS_32}.new_cursor */
EIF_REFERENCE F793_10245 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1015_10912(RTCV(RTOSCF(10259,F793_10259,(Current))));
	RTLE;
	return Result;
}

/* {ARGUMENTS_32}.argument_count */
EIF_INTEGER_32 F793_10255 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count (Current);
	return Result;
}

/* {ARGUMENTS_32}.internal_argument_array */
static EIF_REFERENCE F793_10259_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (10259);
#define Result RTOSR(10259)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1014,0xFF01,1427,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1014, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTLNS(eif_new_type(1427, 0x01).id, 1427, _OBJSIZ_1_0_0_4_0_0_0_0_);
	F1419_17415(RTCW(tr2));
	ti4_1 = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count (Current);
	F1015_10903(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	F450_8700(RTCW(Result));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count (Current))) break;
		tr1 = F793_10260(Current, loc1);
		F1015_10927(RTCW(Result), tr1, loc1);
		loc1++;
	}
	RTOSE (10259);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F793_10259 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10259,F793_10259_body,(Current));
}

/* {ARGUMENTS_32}.i_th_argument_string */
EIF_REFERENCE F793_10260 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,tr2);
	RTLR(4,Result);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1084, 0x01).id, 1084, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F1085_11738(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	loc1 = (EIF_REFERENCE) tr1;
	loc2 = (EIF_POINTER) eif_builtin_ARGUMENTS_32_i_th_argument_pointer (Current, arg1);
	{
		/* INLINED CODE (default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(loc2 != tp1)) {
		F1085_11754(RTCW(loc1), loc2);
		tr1 = RTLNS(eif_new_type(1427, 0x01).id, 1427, _OBJSIZ_1_0_0_4_0_0_0_0_);
		tr2 = F1085_11742(RTCW(loc1));
		F1420_17512(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1427, 0x01).id, 1427, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1419_17415(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {ARGUMENTS_32}.i_th_argument_pointer */
EIF_POINTER F793_10261 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) eif_builtin_ARGUMENTS_32_i_th_argument_pointer (Current, arg1);
	return Result;
}

void EIF_Minit532 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
