/*
 * Code for class WEL_SHARED_TEMPORARY_OBJECTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we529.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_SHARED_TEMPORARY_OBJECTS}.wel_rect */
static EIF_REFERENCE F748_10191_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10191);
#define Result RTOSR(10191)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1201, 0x01).id, 1201, _OBJSIZ_0_1_0_0_0_1_0_0_);
	F1202_14800(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10191);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F748_10191 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10191,F748_10191_body,(Current));
}

/* {WEL_SHARED_TEMPORARY_OBJECTS}.wel_string */
static EIF_REFERENCE F748_10192_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10192);
#define Result RTOSR(10192)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F1085_11738(RTCW(tr1), ((EIF_INTEGER_32) 256L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10192);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F748_10192 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10192,F748_10192_body,(Current));
}

/* {WEL_SHARED_TEMPORARY_OBJECTS}.wel_string_from_string */
EIF_REFERENCE F748_10194 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R15025[Dtype(arg1)-1419])(RTCW(arg1));
	if ((EIF_BOOLEAN) (ti4_1 < ((EIF_INTEGER_32) 10000L))) {
		Result = RTOSCF(10192,F748_10192,(Current));
		F1085_11752(RTCW(Result), arg1);
	} else {
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F1085_11737(RTCW(tr1), arg1);
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

void EIF_Minit529 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
