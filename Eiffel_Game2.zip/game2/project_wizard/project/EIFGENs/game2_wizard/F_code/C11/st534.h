
#ifndef _C11_st534_
#define _C11_st534_

#ifdef __cplusplus
extern "C" {
#endif

extern void F894_10361(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F894_10362(EIF_REFERENCE);
extern EIF_REFERENCE F894_10363(EIF_REFERENCE);
extern EIF_REFERENCE F894_10365(EIF_REFERENCE);
extern EIF_INTEGER_32 F894_10366(EIF_REFERENCE);
extern void EIF_Minit534(void);
extern EIF_INTEGER_32 F1421_17612(EIF_REFERENCE);
extern char *(*R15137[])();
extern long O15136[];

#ifdef __cplusplus
}
#endif

#endif
