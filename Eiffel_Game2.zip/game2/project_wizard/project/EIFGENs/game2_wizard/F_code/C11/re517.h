
#ifndef _C11_re517_
#define _C11_re517_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F739_9843(EIF_REFERENCE);
extern EIF_REFERENCE F739_9844(EIF_REFERENCE);
extern EIF_POINTER F739_9846(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void EIF_Minit517(void);
extern char *(*R9248[])();

#ifdef __cplusplus
}
#endif

#endif
