/*
 * Code for class REFLECTED_COPY_SEMANTICS_OBJECT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re517.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F739_9846
static EIF_POINTER inline_F739_9846 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	return *(EIF_REFERENCE *) eif_obj_at(arg1, arg2);
	;
}
#define INLINE_F739_9846
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REFLECTED_COPY_SEMANTICS_OBJECT}.object_address */
EIF_POINTER F739_9843 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current);
	tp1 = (FUNCTION_CAST(EIF_POINTER, (EIF_REFERENCE)) R9248[Dtype(tr1)-738])(RTCW(tr1));
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_);
	tp1 = inline_F739_9846(tp1, ti4_1);
	Result = RTPOF(tp1,*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
	RTLE;
	return Result;
}

/* {REFLECTED_COPY_SEMANTICS_OBJECT}.referring_object */
EIF_REFERENCE F739_9844 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {REFLECTED_COPY_SEMANTICS_OBJECT}.dereference */
EIF_POINTER F739_9846 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F739_9846 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	return Result;
}

void EIF_Minit517 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
