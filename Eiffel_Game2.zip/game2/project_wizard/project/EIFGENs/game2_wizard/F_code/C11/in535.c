/*
 * Code for class INTEGER_INTERVAL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "in535.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {INTEGER_INTERVAL}.make */
void F946_10384 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 <= arg2)) {
		*(EIF_INTEGER_32 *)(Current + O9731[dtype-945]) = (EIF_INTEGER_32) arg1;
		*(EIF_INTEGER_32 *)(Current + O9730[dtype-945]) = (EIF_INTEGER_32) arg2;
	} else {
		*(EIF_INTEGER_32 *)(Current + O9731[dtype-945]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
		*(EIF_INTEGER_32 *)(Current + O9730[dtype-945]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTLE;
}

/* {INTEGER_INTERVAL}.lower */
EIF_INTEGER_32 F946_10387 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O9731[Dtype(Current) - 945]);
}


/* {INTEGER_INTERVAL}.upper */
EIF_INTEGER_32 F946_10389 (EIF_REFERENCE Current)
{
	return *(EIF_INTEGER_32 *)(Current + O9730[Dtype(Current) - 945]);
}


/* {INTEGER_INTERVAL}.item */
EIF_INTEGER_32 F946_10390 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_INTEGER_32) arg1;
}

/* {INTEGER_INTERVAL}.valid_index */
EIF_BOOLEAN F946_10393 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	
	
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O9730[dtype-945]);
	ti4_2 = *(EIF_INTEGER_32 *)(Current + O9731[dtype-945]);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN) ((EIF_BOOLEAN) (arg1 <= ti4_1) && (EIF_BOOLEAN) (arg1 >= ti4_2));
	return Result;
}

/* {INTEGER_INTERVAL}.capacity */
EIF_INTEGER_32 F946_10395 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	RTLE;
	return (EIF_INTEGER_32) F946_10396(Current);
}

/* {INTEGER_INTERVAL}.count */
EIF_INTEGER_32 F946_10396 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = *(EIF_INTEGER_32 *)(Current + O9730[dtype-945]);
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O9731[dtype-945]);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) ((EIF_INTEGER_32) (Result - ti4_1) + ((EIF_INTEGER_32) 1L));
	RTLE;
	return Result;
}

/* {INTEGER_INTERVAL}.is_equal */
EIF_BOOLEAN F946_10398 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = EIF_TRUE;
	if (tb2) {
		ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9731[Dtype(arg1)-945]);
		tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9731[dtype-945]) == ti4_1);
	}
	if ((tb1)) {
		tb1 = '\0';
		tb2 = EIF_TRUE;
		if (tb2) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O9730[Dtype(arg1)-945]);
			tb1 = (EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O9730[dtype-945]) == ti4_1);
		}
		Result = (tb1);
	}
	RTLE;
	return Result;
}

/* {INTEGER_INTERVAL}.extendible */
EIF_BOOLEAN F946_10400 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {INTEGER_INTERVAL}.prunable */
EIF_BOOLEAN F946_10401 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {INTEGER_INTERVAL}.extend */
void F946_10402 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O9731[dtype-945]))) {
		*(EIF_INTEGER_32 *)(Current + O9731[dtype-945]) = (EIF_INTEGER_32) arg1;
	} else {
		if ((EIF_BOOLEAN) (arg1 > *(EIF_INTEGER_32 *)(Current + O9730[dtype-945]))) {
			*(EIF_INTEGER_32 *)(Current + O9730[dtype-945]) = (EIF_INTEGER_32) arg1;
		}
	}
	RTLE;
}

/* {INTEGER_INTERVAL}.wipe_out */
void F946_10408 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current + O9731[dtype-945]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	*(EIF_INTEGER_32 *)(Current + O9730[dtype-945]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {INTEGER_INTERVAL}.as_array */
EIF_REFERENCE F946_10409 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	loc1 = *(EIF_INTEGER_32 *)(Current + O9731[dtype-945]);
	loc2 = *(EIF_INTEGER_32 *)(Current + O9730[dtype-945]);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1016,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1016, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	F1017_10903(RTCW(tr1), ((EIF_INTEGER_32) 0L), loc1, loc2);
	Result = (EIF_REFERENCE) tr1;
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > loc2)) break;
		F1017_10927(RTCW(Result), loc1, loc1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {INTEGER_INTERVAL}.linear_representation */
EIF_REFERENCE F946_10411 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1017_10954(RTCV(F946_10409(Current)));
	RTLE;
	return Result;
}

/* {INTEGER_INTERVAL}.copy */
void F946_10412 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		eif_builtin_ANY_standard_copy (Current, arg1);
	}
	RTLE;
}

/* {INTEGER_INTERVAL}.put */
void F946_10403 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 < *(EIF_INTEGER_32 *)(Current + O9731[dtype-945]))) {
		*(EIF_INTEGER_32 *)(Current + O9731[dtype-945]) = (EIF_INTEGER_32) arg1;
	} else {
		if ((EIF_BOOLEAN) (arg1 > *(EIF_INTEGER_32 *)(Current + O9730[dtype-945]))) {
			*(EIF_INTEGER_32 *)(Current + O9730[dtype-945]) = (EIF_INTEGER_32) arg1;
		}
	}
	RTLE;
}

void EIF_Minit535 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
