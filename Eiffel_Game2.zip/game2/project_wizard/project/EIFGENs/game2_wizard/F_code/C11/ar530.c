/*
 * Code for class ARGUMENTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ar530.h"
#include "eif_built_in.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {ARGUMENTS}.argument */
EIF_REFERENCE F791_10206 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = RTOSCF(10229,F791_10229,(Current));
	Result = F793_10241(RTCW(Result), arg1);
	Result = F1419_17471(RTCW(Result));
	RTLE;
	return Result;
}

/* {ARGUMENTS}.argument_array */
static EIF_REFERENCE F791_10207_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (10207);
#define Result RTOSR(10207)
	RTOC_NEW(Result);
	Result = F791_10228(Current);
	RTOSE (10207);
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F791_10207 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10207,F791_10207_body,(Current));
}

/* {ARGUMENTS}.new_cursor */
EIF_REFERENCE F791_10210 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	Result = F1015_10912(RTCV(RTOSCF(10207,F791_10207,(Current))));
	RTLE;
	return Result;
}

/* {ARGUMENTS}.argument_count */
EIF_INTEGER_32 F791_10224 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) eif_builtin_ARGUMENTS_32_argument_count (RTOSCF(10229,F791_10229,(Current)));
	RTLE;
	return Result;
}

/* {ARGUMENTS}.internal_argument_array */
EIF_REFERENCE F791_10228 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1014,0xFF01,1423,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1014, _OBJSIZ_1_1_0_2_0_0_0_0_);
	}
	tr2 = RTMS_EX_H("",0,0);
	ti4_1 = F791_10224(Current);
	F1015_10903(RTCW(tr1), tr2, ((EIF_INTEGER_32) 0L), ti4_1);
	Result = (EIF_REFERENCE) tr1;
	F450_8700(RTCW(Result));
	for (;;) {
		if ((EIF_BOOLEAN) (loc1 > F791_10224(Current))) break;
		tr1 = F791_10206(Current, loc1);
		F1015_10927(RTCW(Result), tr1, loc1);
		loc1++;
	}
	RTLE;
	return Result;
}

/* {ARGUMENTS}.internal_arguments */
static EIF_REFERENCE F791_10229_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10229);
#define Result RTOSR(10229)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(792, 0x01).id, 792, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10229);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F791_10229 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10229,F791_10229_body,(Current));
}

void EIF_Minit530 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
