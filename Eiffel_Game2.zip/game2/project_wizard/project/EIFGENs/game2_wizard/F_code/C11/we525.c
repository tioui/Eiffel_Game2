/*
 * Code for class WEL_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we525.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_CONSTANTS}.wel_window_constants */
static EIF_REFERENCE F744_10123_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10123);
#define Result RTOSR(10123)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(91, 0x01).id, 91, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10123);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F744_10123 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10123,F744_10123_body,(Current));
}

/* {WEL_CONSTANTS}.wel_input_constants */
static EIF_REFERENCE F744_10125_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10125);
#define Result RTOSR(10125)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(124, 0x01).id, 124, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10125);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F744_10125 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10125,F744_10125_body,(Current));
}

/* {WEL_CONSTANTS}.wel_color_constants */
static EIF_REFERENCE F744_10126_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10126);
#define Result RTOSR(10126)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1088, 0x01).id, 1088, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10126);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F744_10126 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10126,F744_10126_body,(Current));
}

/* {WEL_CONSTANTS}.wel_drawing_constants */
static EIF_REFERENCE F744_10127_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10127);
#define Result RTOSR(10127)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(205, 0x01).id, 205, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10127);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F744_10127 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10127,F744_10127_body,(Current));
}

/* {WEL_CONSTANTS}.wel_ownerdraw_constants */
static EIF_REFERENCE F744_10128_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (10128);
#define Result RTOSR(10128)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(284, 0x01).id, 284, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10128);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F744_10128 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10128,F744_10128_body,(Current));
}

void EIF_Minit525 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
