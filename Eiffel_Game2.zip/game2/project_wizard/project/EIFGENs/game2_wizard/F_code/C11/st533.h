
#ifndef _C11_st533_
#define _C11_st533_

#ifdef __cplusplus
extern "C" {
#endif

extern void F893_10355(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F893_10356(EIF_REFERENCE);
extern EIF_REFERENCE F893_10357(EIF_REFERENCE);
extern EIF_REFERENCE F893_10359(EIF_REFERENCE);
extern EIF_INTEGER_32 F893_10360(EIF_REFERENCE);
extern void EIF_Minit533(void);
extern EIF_INTEGER_32 F1420_17561(EIF_REFERENCE);
extern char *(*R15106[])();
extern long O15105[];

#ifdef __cplusplus
}
#endif

#endif
