
#ifndef _C11_we504_
#define _C11_we504_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F710_9511(EIF_REFERENCE);
extern EIF_POINTER F710_9512(EIF_REFERENCE);
extern EIF_POINTER F710_9513(EIF_REFERENCE);
extern void EIF_Minit504(void);

#ifdef __cplusplus
}
#endif

#endif
