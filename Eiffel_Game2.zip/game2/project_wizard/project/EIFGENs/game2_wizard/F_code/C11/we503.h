
#ifndef _C11_we503_
#define _C11_we503_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_REFERENCE,9510)
static EIF_REFERENCE F709_9510_body(EIF_REFERENCE);
extern EIF_REFERENCE F709_9510(EIF_REFERENCE);
extern void EIF_Minit503(void);

#ifdef __cplusplus
}
#endif

#endif
