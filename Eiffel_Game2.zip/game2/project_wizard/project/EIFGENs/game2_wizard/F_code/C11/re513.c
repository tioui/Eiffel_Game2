/*
 * Code for class REFLECTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "re513.h"
#include "eif_built_in.h"
#include "eif_gen_conf.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F82_1517
static EIF_INTEGER_32 inline_F82_1517 (EIF_INTEGER_32 arg1)
{
	return eif_non_attached_type(arg1)
	;
}
#define INLINE_F82_1517
#endif
#ifndef INLINE_F82_1511
static int inline_F82_1511 (EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	return eif_gen_conf(arg1, arg2);
	;
}
#define INLINE_F82_1511
#endif
#ifndef INLINE_F82_1516
static int inline_F82_1516 (EIF_INTEGER_32 arg1)
{
	return eif_is_attached_type(arg1)
	;
}
#define INLINE_F82_1516
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {REFLECTOR}.field_conforms_to */
EIF_BOOLEAN F735_9675 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	RTGC;
	ti4_1 = inline_F82_1517(arg2);
	Result = EIF_TEST (inline_F82_1511(arg1, ti4_1));
	return Result;
}

/* {REFLECTOR}.is_attached_type */
EIF_BOOLEAN F735_9685 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	
	
	return (EIF_BOOLEAN) EIF_TEST (inline_F82_1516(arg1));
}

/* {REFLECTOR}.field_name_of_type */
EIF_REFERENCE F735_9695 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1423, 0x01).id, 1423, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tp1 = (EIF_POINTER) eif_builtin_ISE_RUNTIME_field_name_of_type (arg1, arg2);
	F1421_17565(RTCW(tr1), tp1);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

void EIF_Minit513 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
