
#ifndef _C11_re513_
#define _C11_re513_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F735_9675(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_BOOLEAN F735_9685(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_REFERENCE F735_9695(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit513(void);
extern void F1421_17565(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
