/*
 * Code for class WEL_SHARED_FONTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we526.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_SHARED_FONTS}.gui_font */
EIF_REFERENCE F745_10130 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F745_10132(Current);
}

/* {WEL_SHARED_FONTS}.system_font */
EIF_REFERENCE F745_10131 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) F745_10132(Current);
}

/* {WEL_SHARED_FONTS}.message_font */
EIF_REFERENCE F745_10132 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(10137,F745_10137,(Current));
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8692[Dtype(tr1)-695])(RTCW(tr1));
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc1 = (EIF_REFERENCE) tr1;
		loc2 = F1801_25203(RTCW(loc1));
		tr1 = RTLNS(eif_new_type(1817, 0x01).id, 1817, _OBJSIZ_0_2_0_3_0_1_0_0_);
		tr2 = F1217_15091(RTCW(loc2));
		F1818_25590(RTCW(tr1), tr2);
		loc3 = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(10137,F745_10137,(Current));
		F696_9148(RTCW(tr1), loc3);
	}
	RTLE;
	return (EIF_REFERENCE) loc3;
}

/* {WEL_SHARED_FONTS}.menu_font */
EIF_REFERENCE F745_10133 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc3);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,loc2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	tr1 = RTOSCF(10138,F745_10138,(Current));
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8692[Dtype(tr1)-695])(RTCW(tr1));
	if ((EIF_BOOLEAN)(loc3 == NULL)) {
		tr1 = RTLNS(eif_new_type(1800, 0x01).id, 1800, _OBJSIZ_0_0_0_0_0_0_0_0_);
		loc1 = (EIF_REFERENCE) tr1;
		loc2 = F1801_25203(RTCW(loc1));
		tr1 = RTLNS(eif_new_type(1817, 0x01).id, 1817, _OBJSIZ_0_2_0_3_0_1_0_0_);
		tr2 = F1217_15089(RTCW(loc2));
		F1818_25590(RTCW(tr1), tr2);
		loc3 = (EIF_REFERENCE) tr1;
		tr1 = RTOSCF(10138,F745_10138,(Current));
		F696_9148(RTCW(tr1), loc3);
	}
	RTLE;
	return (EIF_REFERENCE) loc3;
}

/* {WEL_SHARED_FONTS}.message_font_cell */
static EIF_REFERENCE F745_10137_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10137);
#define Result RTOSR(10137)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,695,1817,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 695, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F696_9148(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10137);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F745_10137 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10137,F745_10137_body,(Current));
}

/* {WEL_SHARED_FONTS}.menu_font_cell */
static EIF_REFERENCE F745_10138_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10138);
#define Result RTOSR(10138)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,695,1817,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 695, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F696_9148(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10138);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F745_10138 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10138,F745_10138_body,(Current));
}

/* {WEL_SHARED_FONTS}.status_font_cell */
static EIF_REFERENCE F745_10139_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10139);
#define Result RTOSR(10139)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,695,1817,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 695, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F696_9148(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10139);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F745_10139 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10139,F745_10139_body,(Current));
}

/* {WEL_SHARED_FONTS}.caption_font_cell */
static EIF_REFERENCE F745_10140_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10140);
#define Result RTOSR(10140)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,695,1817,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 695, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F696_9148(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10140);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F745_10140 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10140,F745_10140_body,(Current));
}

/* {WEL_SHARED_FONTS}.small_caption_font_cell */
static EIF_REFERENCE F745_10141_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (10141);
#define Result RTOSR(10141)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,695,1817,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 695, _OBJSIZ_1_0_0_0_0_0_0_0_);
	}
	F696_9148(RTCW(tr1), NULL);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (10141);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F745_10141 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(10141,F745_10141_body,(Current));
}

void EIF_Minit526 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
