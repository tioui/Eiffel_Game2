
#ifndef _C11_pl508_
#define _C11_pl508_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F774_9554(EIF_REFERENCE);
extern EIF_BOOLEAN F774_9556(EIF_REFERENCE);
extern EIF_BOOLEAN F774_9557(EIF_REFERENCE);
extern void EIF_Minit508(void);

#ifdef __cplusplus
}
#endif

#endif
