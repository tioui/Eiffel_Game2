/*
 * Code for class WEL_MEASURE_ITEM_STRUCT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we726.h"
#include <measureitem.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_MEASURE_ITEM_STRUCT}.ctl_type */
EIF_INTEGER_32 F1179_14247 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_measureitemstruct_get_ctltype((tp1));
}

/* {WEL_MEASURE_ITEM_STRUCT}.item_data */
EIF_INTEGER_32 F1179_14252 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_measureitemstruct_get_itemdata((tp1));
}

/* {WEL_MEASURE_ITEM_STRUCT}.set_item_width */
void F1179_14253 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_measureitemstruct_set_itemwidth((tp1), (arg1));
}

/* {WEL_MEASURE_ITEM_STRUCT}.set_item_height */
void F1179_14254 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_measureitemstruct_set_itemheight((tp1), (arg1));
}

/* {WEL_MEASURE_ITEM_STRUCT}.structure_size */
static EIF_INTEGER_32 F1179_14255_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14255);
#define Result RTOSR(14255)
	Result = (EIF_INTEGER_32) sizeof (MEASUREITEMSTRUCT);
	RTOSE (14255);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1179_14255 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14255,F1179_14255_body,(Current));
}

/* {WEL_MEASURE_ITEM_STRUCT}.c_size_of_measureitemstruct */
EIF_INTEGER_32 F1179_14256 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (MEASUREITEMSTRUCT);
	return Result;
}

/* {WEL_MEASURE_ITEM_STRUCT}.cwel_measureitemstruct_get_ctltype */
EIF_INTEGER_32 F1179_14257 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_measureitemstruct_get_ctltype((arg1));
	return Result;
}

/* {WEL_MEASURE_ITEM_STRUCT}.cwel_measureitemstruct_get_itemdata */
EIF_INTEGER_32 F1179_14262 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_measureitemstruct_get_itemdata((arg1));
	return Result;
}

/* {WEL_MEASURE_ITEM_STRUCT}.cwel_measureitemstruct_set_itemwidth */
void F1179_14263 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_measureitemstruct_set_itemwidth((arg1), (arg2));
}

/* {WEL_MEASURE_ITEM_STRUCT}.cwel_measureitemstruct_set_itemheight */
void F1179_14264 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_measureitemstruct_set_itemheight((arg1), (arg2));
}

void EIF_Minit726 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
