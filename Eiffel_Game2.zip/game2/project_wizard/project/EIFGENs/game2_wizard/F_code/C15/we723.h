
#ifndef _C15_we723_
#define _C15_we723_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_INTEGER_32,14212)
static EIF_INTEGER_32 F1177_14212_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F1177_14212(EIF_REFERENCE);
extern EIF_INTEGER_32 F1177_14213(EIF_REFERENCE);
extern void EIF_Minit723(void);

#ifdef __cplusplus
}
#endif

#endif
