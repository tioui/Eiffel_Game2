/*
 * Code for class WEL_GDIP_IMAGE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we700.h"
#include "wel_gdi_plus.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1160_13747
static EIF_NATURAL_32 inline_F1160_13747 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	static FARPROC GdipGetImageWidth = NULL;
EIF_NATURAL_32 l_result;

*(EIF_NATURAL_32 *) arg3 = 1;

if (!GdipGetImageWidth) {
	GdipGetImageWidth = GetProcAddress ((HMODULE) arg1, "GdipGetImageWidth");
}
if (GdipGetImageWidth) {
	*(EIF_INTEGER *)arg3 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpImage *, UINT *)) GdipGetImageWidth)
				((GpImage *) arg2,
				(UINT *) &l_result);
}

return l_result;
	;
}
#define INLINE_F1160_13747
#endif
#ifndef INLINE_F1160_13748
static EIF_NATURAL_32 inline_F1160_13748 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	{
	static FARPROC GdipGetImageHeight = NULL;
	EIF_NATURAL_32 l_result;
	
	*(EIF_NATURAL_32 *) arg3 = 1;
	
	if (!GdipGetImageHeight) {
		GdipGetImageHeight = GetProcAddress ((HMODULE) arg1, "GdipGetImageHeight");
	}			
	
	if (GdipGetImageHeight) {
		*(EIF_INTEGER *)arg3 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpImage *, UINT *)) GdipGetImageHeight)
					((GpImage *) arg2,
					(UINT *) &l_result);
	}
	return l_result;
}
	;
}
#define INLINE_F1160_13748
#endif
#ifndef INLINE_F1160_13750
static void inline_F1160_13750 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	{
	static FARPROC GdipDisposeImage = NULL;
	*(EIF_INTEGER *) arg3 = 1;
	
	if (!GdipDisposeImage) {
		GdipDisposeImage = GetProcAddress ((HMODULE) arg1, "GdipDisposeImage");
	}			
	if (GdipDisposeImage) {
		*(EIF_INTEGER *)arg3 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpImage *)) GdipDisposeImage)
					((GpImage *) arg2);
	}
}
	;
}
#define INLINE_F1160_13750
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_GDIP_IMAGE}.width */
EIF_INTEGER_32 F1160_13732 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12003[dtype-1149]);
	tp2 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
	tu4_1 = inline_F1160_13747(tp1, tp2, (EIF_INTEGER_32 *) &(loc1));
	Result = (EIF_INTEGER_32) tu4_1;
	RTLE;
	return Result;
}

/* {WEL_GDIP_IMAGE}.height */
EIF_INTEGER_32 F1160_13733 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_NATURAL_32 tu4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O12003[dtype-1149]);
	tp2 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
	tu4_1 = inline_F1160_13748(tp1, tp2, (EIF_INTEGER_32 *) &(loc1));
	Result = (EIF_INTEGER_32) tu4_1;
	RTLE;
	return Result;
}

/* {WEL_GDIP_IMAGE}.destroy_item */
void F1160_13738 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O11797[dtype-1129]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O12003[dtype-1149]);
		tp2 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
		inline_F1160_13750(tp1, tp2, (EIF_INTEGER_32 *) &(loc1));
		{
			/* INLINED CODE (default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current + O11797[dtype-1129]) = (EIF_POINTER) tp2;
	}
	RTLE;
}

/* {WEL_GDIP_IMAGE}.c_gdip_get_image_width */
EIF_NATURAL_32 F1160_13747 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = inline_F1160_13747 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3);
	return Result;
}

/* {WEL_GDIP_IMAGE}.c_gdip_get_image_height */
EIF_NATURAL_32 F1160_13748 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = inline_F1160_13748 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3);
	return Result;
}

/* {WEL_GDIP_IMAGE}.c_gdip_dispose_image */
void F1160_13750 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	
	inline_F1160_13750 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3);
}

void EIF_Minit700 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
