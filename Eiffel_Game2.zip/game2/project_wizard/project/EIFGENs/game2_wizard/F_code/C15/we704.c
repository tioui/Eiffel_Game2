/*
 * Code for class WEL_MENU_BAR_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we704.h"
#include <rect.h>
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1163_13806
static EIF_POINTER inline_F1163_13806 (EIF_POINTER arg1)
{
	return (EIF_POINTER) ((& (((MENUBARINFO *)(arg1))->rcBar) ))
	;
}
#define INLINE_F1163_13806
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_MENU_BAR_INFO}.make */
void F1163_13801 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1162_13788(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	ti4_1 = (EIF_INTEGER_32) sizeof (MENUBARINFO);
	(((MENUBARINFO *)tp1)->cbSize = (DWORD)(ti4_1));
	RTLE;
}

/* {WEL_MENU_BAR_INFO}.rc_bar */
EIF_REFERENCE F1163_13802 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1201, 0x01).id, 1201, _OBJSIZ_0_1_0_0_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	tp1 = inline_F1163_13806(tp1);
	F1130_13375(RTCW(tr1), tp1);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {WEL_MENU_BAR_INFO}.structure_size */
static EIF_INTEGER_32 F1163_13803_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (13803);
#define Result RTOSR(13803)
	Result = (EIF_INTEGER_32) sizeof (MENUBARINFO);
	RTOSE (13803);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1163_13803 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13803,F1163_13803_body,(Current));
}

/* {WEL_MENU_BAR_INFO}.c_size_of_menubarinfo */
EIF_INTEGER_32 F1163_13804 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (MENUBARINFO);
	return Result;
}

/* {WEL_MENU_BAR_INFO}.cwel_menubarinfo_set_cbsize */
void F1163_13805 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((MENUBARINFO *)arg1)->cbSize = (DWORD)(arg2));
	
}

/* {WEL_MENU_BAR_INFO}.cwel_menubarinfo_get_rcbar */
EIF_POINTER F1163_13806 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1163_13806 ((EIF_POINTER) arg1);
	return Result;
}

void EIF_Minit704 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
