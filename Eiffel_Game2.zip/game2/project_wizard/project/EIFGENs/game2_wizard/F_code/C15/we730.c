/*
 * Code for class WEL_TEXT_RANGE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we730.h"
#include <richedit.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1182_14335
static void inline_F1182_14335 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	((TEXTRANGE *) arg1)->lpstrText = (LPTSTR) arg2;
	;
}
#define INLINE_F1182_14335
#endif
#ifndef INLINE_F1182_14334
static EIF_INTEGER_32 inline_F1182_14334 (void)
{
	return sizeof (TEXTRANGE);
	;
}
#define INLINE_F1182_14334
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_TEXT_RANGE}.make */
void F1182_14329 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1162_13788(Current);
	tr1 = RTLNSMART(eif_new_type(1085, 1).id);
	F1085_11738(RTCW(tr1), arg1);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_2_1_0_0_0_0_);
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tp2 = F1085_11744(RTCW(tr1));
	inline_F1182_14335(tp1, tp2);
	tr1 = RTLNSMART(eif_new_type(1219, 1).id);
	F1130_13375(RTCW(tr1), *(EIF_POINTER *)(Current+ _PTROFF_2_1_0_0_0_0_));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	tr1 = *(EIF_REFERENCE *)(Current);
	F1130_13380(RTCW(tr1));
	tr1 = *(EIF_REFERENCE *)(Current);
	F1220_15249(RTCW(tr1), arg2, arg3);
	RTLE;
}

/* {WEL_TEXT_RANGE}.range */
EIF_REFERENCE F1182_14330 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {WEL_TEXT_RANGE}.text */
EIF_REFERENCE F1182_14331 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {WEL_TEXT_RANGE}.structure_size */
static EIF_INTEGER_32 F1182_14333_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14333);
#define Result RTOSR(14333)
	Result = inline_F1182_14334();
	RTOSE (14333);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1182_14333 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14333,F1182_14333_body,(Current));
}

/* {WEL_TEXT_RANGE}.cwel_size_of_textrange */
EIF_INTEGER_32 F1182_14334 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F1182_14334 ();
	return Result;
}

/* {WEL_TEXT_RANGE}.cwel_charrange_set_text */
void F1182_14335 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F1182_14335 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

void EIF_Minit730 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
