/*
 * Code for class WEL_BLEND_FUNCTION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we721.h"
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_BLEND_FUNCTION}.make */
void F1175_14144 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1162_13788(Current);
	F1175_14149(Current, ((EIF_INTEGER_32) 0L));
	F1175_14151(Current, ((EIF_INTEGER_32) 0L));
	F1175_14153(Current, ((EIF_INTEGER_32) 255L));
	F1175_14155(Current, ((EIF_INTEGER_32) 1L));
	RTLE;
}

/* {WEL_BLEND_FUNCTION}.structure_size */
EIF_INTEGER_32 F1175_14147 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) (EIF_INTEGER_32) sizeof (BLENDFUNCTION);
}

/* {WEL_BLEND_FUNCTION}.set_blend_op */
void F1175_14149 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	(((BLENDFUNCTION *)tp1)->BlendOp = (BYTE)(arg1));
}

/* {WEL_BLEND_FUNCTION}.set_blend_flags */
void F1175_14151 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	(((BLENDFUNCTION *)tp1)->BlendFlags = (BYTE)(arg1));
}

/* {WEL_BLEND_FUNCTION}.set_source_constant_alpha */
void F1175_14153 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	(((BLENDFUNCTION *)tp1)->SourceConstantAlpha = (BYTE)(arg1));
}

/* {WEL_BLEND_FUNCTION}.set_alpha_format */
void F1175_14155 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	(((BLENDFUNCTION *)tp1)->AlphaFormat = (BYTE)(arg1));
}

/* {WEL_BLEND_FUNCTION}.c_size_of_blend_function */
EIF_INTEGER_32 F1175_14156 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (BLENDFUNCTION);
	return Result;
}

/* {WEL_BLEND_FUNCTION}.c_set_blend_op */
void F1175_14157 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((BLENDFUNCTION *)arg1)->BlendOp = (BYTE)(arg2));
	
}

/* {WEL_BLEND_FUNCTION}.c_set_blend_flags */
void F1175_14159 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((BLENDFUNCTION *)arg1)->BlendFlags = (BYTE)(arg2));
	
}

/* {WEL_BLEND_FUNCTION}.c_set_source_constant_alpha */
void F1175_14161 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((BLENDFUNCTION *)arg1)->SourceConstantAlpha = (BYTE)(arg2));
	
}

/* {WEL_BLEND_FUNCTION}.c_set_alpha_format */
void F1175_14163 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	(((BLENDFUNCTION *)arg1)->AlphaFormat = (BYTE)(arg2));
	
}

void EIF_Minit721 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
