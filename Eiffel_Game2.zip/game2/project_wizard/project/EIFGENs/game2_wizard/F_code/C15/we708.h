
#ifndef _C15_we708_
#define _C15_we708_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1167_13872(EIF_REFERENCE);
extern void EIF_Minit708(void);

#ifdef __cplusplus
}
#endif

#endif
