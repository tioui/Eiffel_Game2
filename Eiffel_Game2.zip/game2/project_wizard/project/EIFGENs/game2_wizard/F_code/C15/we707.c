/*
 * Code for class WEL_NM_TREE_VIEW_GETINFOTIP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we707.h"
#include <commctrl.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_NM_TREE_VIEW_GETINFOTIP}.hitem */
EIF_POINTER F1166_13860 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_POINTER) (EIF_POINTER) (((NMTVGETINFOTIP *)tp1)->hItem);
}

/* {WEL_NM_TREE_VIEW_GETINFOTIP}.structure_size */
static EIF_INTEGER_32 F1166_13862_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (13862);
#define Result RTOSR(13862)
	Result = (EIF_INTEGER_32) sizeof (NMTVGETINFOTIP);
	RTOSE (13862);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1166_13862 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13862,F1166_13862_body,(Current));
}

/* {WEL_NM_TREE_VIEW_GETINFOTIP}.c_size_of_nm_tvgetinfotip */
EIF_INTEGER_32 F1166_13863 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (NMTVGETINFOTIP);
	return Result;
}

/* {WEL_NM_TREE_VIEW_GETINFOTIP}.cwel_nmtvinfotip_get_hitem */
EIF_POINTER F1166_13867 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) (((NMTVGETINFOTIP *)arg1)->hItem);
	
	return Result;
}

void EIF_Minit707 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
