
#ifndef _C15_we707_
#define _C15_we707_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F1166_13860(EIF_REFERENCE);
RTOSHF (EIF_INTEGER_32,13862)
static EIF_INTEGER_32 F1166_13862_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F1166_13862(EIF_REFERENCE);
extern EIF_INTEGER_32 F1166_13863(EIF_REFERENCE);
extern EIF_POINTER F1166_13867(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit707(void);

#ifdef __cplusplus
}
#endif

#endif
