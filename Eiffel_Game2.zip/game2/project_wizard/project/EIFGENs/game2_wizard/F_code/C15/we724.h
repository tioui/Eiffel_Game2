
#ifndef _C15_we724_
#define _C15_we724_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1178_14220(EIF_REFERENCE);
extern EIF_REFERENCE F1178_14221(EIF_REFERENCE);
extern EIF_INTEGER_32 F1178_14224(EIF_REFERENCE);
extern void F1178_14225(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_POINTER F1178_14226(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit724(void);
extern void F1162_13788(EIF_REFERENCE);
extern void F1130_13375(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
