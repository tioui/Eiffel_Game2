
#ifndef _C15_we700_
#define _C15_we700_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1160_13732(EIF_REFERENCE);
extern EIF_INTEGER_32 F1160_13733(EIF_REFERENCE);
extern void F1160_13738(EIF_REFERENCE);
extern EIF_NATURAL_32 F1160_13747(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32*);
extern EIF_NATURAL_32 F1160_13748(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32*);
extern void F1160_13750(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32*);
extern void EIF_Minit700(void);
extern long O12003[];
extern long O11797[];

#ifdef __cplusplus
}
#endif

#endif
