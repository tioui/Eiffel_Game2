/*
 * Code for class WEL_BITMAP_INFO_HEADER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we718.h"
#include <bmpinfoh.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_BITMAP_INFO_HEADER}.make */
void F1173_14071 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1162_13788(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	ti4_1 = RTOSCF(14093,F1173_14093,(Current));
	cwel_bitmapinfoheader_set_size((tp1), (ti4_1));
	F1173_14083(Current, ((EIF_INTEGER_32) 0L));
	F1173_14084(Current, ((EIF_INTEGER_32) 0L));
	F1173_14085(Current, ((EIF_INTEGER_32) 0L));
	F1173_14086(Current, ((EIF_INTEGER_32) 0L));
	F1173_14087(Current, ((EIF_INTEGER_32) 0L));
	F1173_14088(Current, ((EIF_INTEGER_32) 0L));
	F1173_14089(Current, ((EIF_INTEGER_32) 0L));
	F1173_14090(Current, ((EIF_INTEGER_32) 0L));
	F1173_14091(Current, ((EIF_INTEGER_32) 0L));
	F1173_14092(Current, ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {WEL_BITMAP_INFO_HEADER}.height */
EIF_INTEGER_32 F1173_14073 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_bitmapinfoheader_get_height((tp1));
}

/* {WEL_BITMAP_INFO_HEADER}.bit_count */
EIF_INTEGER_32 F1173_14075 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_bitmapinfoheader_get_bitcount((tp1));
}

/* {WEL_BITMAP_INFO_HEADER}.compression */
EIF_INTEGER_32 F1173_14076 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_bitmapinfoheader_get_compression((tp1));
}

/* {WEL_BITMAP_INFO_HEADER}.size_image */
EIF_INTEGER_32 F1173_14077 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_bitmapinfoheader_get_sizeimage((tp1));
}

/* {WEL_BITMAP_INFO_HEADER}.clr_used */
EIF_INTEGER_32 F1173_14080 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_bitmapinfoheader_get_clrused((tp1));
}

/* {WEL_BITMAP_INFO_HEADER}.color_count */
EIF_INTEGER_32 F1173_14082 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	switch (F1173_14075(Current)) {
		case 0L:
			break;
		case 1L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2L);
			break;
		case 4L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16L);
			break;
		case 8L:
			Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 256L);
			break;
		case 16L:
		case 32L:
			if ((EIF_BOOLEAN)(F1173_14076(Current) == ((EIF_INTEGER_32) 0L))) {
				Result = F1173_14080(Current);
			} else {
				if ((EIF_BOOLEAN)(F1173_14076(Current) == ((EIF_INTEGER_32) 3L))) {
					Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 3L);
				}
			}
			break;
		case 24L:
			Result = F1173_14080(Current);
			break;
		default:
			break;
	}
	RTLE;
	return Result;
}

/* {WEL_BITMAP_INFO_HEADER}.set_width */
void F1173_14083 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_width((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_height */
void F1173_14084 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_height((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_planes */
void F1173_14085 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_planes((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_bit_count */
void F1173_14086 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_bitcount((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_compression */
void F1173_14087 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_compression((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_size_image */
void F1173_14088 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_sizeimage((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_x_pels_per_meter */
void F1173_14089 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_xpelspermeter((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_y_pels_per_meter */
void F1173_14090 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_ypelspermeter((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_clr_used */
void F1173_14091 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_clrused((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.set_clr_important */
void F1173_14092 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmapinfoheader_set_clrimportant((tp1), (arg1));
}

/* {WEL_BITMAP_INFO_HEADER}.structure_size */
static EIF_INTEGER_32 F1173_14093_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14093);
#define Result RTOSR(14093)
	Result = (EIF_INTEGER_32) sizeof (BITMAPINFOHEADER);
	RTOSE (14093);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1173_14093 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14093,F1173_14093_body,(Current));
}

/* {WEL_BITMAP_INFO_HEADER}.c_size_of_bitmapinfoheader */
EIF_INTEGER_32 F1173_14094 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (BITMAPINFOHEADER);
	return Result;
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_size */
void F1173_14095 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_size((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_width */
void F1173_14096 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_width((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_height */
void F1173_14097 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_height((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_planes */
void F1173_14098 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_planes((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_bitcount */
void F1173_14099 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_bitcount((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_compression */
void F1173_14100 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_compression((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_sizeimage */
void F1173_14101 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_sizeimage((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_xpelspermeter */
void F1173_14102 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_xpelspermeter((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_ypelspermeter */
void F1173_14103 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_ypelspermeter((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_clrused */
void F1173_14104 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_clrused((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_set_clrimportant */
void F1173_14105 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_bitmapinfoheader_set_clrimportant((arg1), (arg2));
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_get_height */
EIF_INTEGER_32 F1173_14107 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_bitmapinfoheader_get_height((arg1));
	return Result;
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_get_bitcount */
EIF_INTEGER_32 F1173_14109 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_bitmapinfoheader_get_bitcount((arg1));
	return Result;
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_get_compression */
EIF_INTEGER_32 F1173_14110 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_bitmapinfoheader_get_compression((arg1));
	return Result;
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_get_sizeimage */
EIF_INTEGER_32 F1173_14111 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_bitmapinfoheader_get_sizeimage((arg1));
	return Result;
}

/* {WEL_BITMAP_INFO_HEADER}.cwel_bitmapinfoheader_get_clrused */
EIF_INTEGER_32 F1173_14114 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_bitmapinfoheader_get_clrused((arg1));
	return Result;
}

void EIF_Minit718 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
