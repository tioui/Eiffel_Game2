/*
 * Code for class WEL_NM_COMBO_BOX_EX_ENDEDIT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we731.h"
#include "nmcbeendedit.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_NM_COMBO_BOX_EX_ENDEDIT}.make_by_nmhdr */
void F1183_14336 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_0_0_0_);
	F1130_13375(Current, tp1);
	RTLE;
}

/* {WEL_NM_COMBO_BOX_EX_ENDEDIT}.structure_size */
static EIF_INTEGER_32 F1183_14342_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14342);
#define Result RTOSR(14342)
	Result = (EIF_INTEGER_32) sizeof (NMCBEENDEDIT);
	RTOSE (14342);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1183_14342 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14342,F1183_14342_body,(Current));
}

/* {WEL_NM_COMBO_BOX_EX_ENDEDIT}.c_size_of_nm_cbeendedit */
EIF_INTEGER_32 F1183_14343 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (NMCBEENDEDIT);
	return Result;
}

void EIF_Minit731 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
