
#ifndef _C15_we703_
#define _C15_we703_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1162_13788(EIF_REFERENCE);
extern void F1162_13789(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1162_13790(EIF_REFERENCE, EIF_REFERENCE);
extern void F1162_13791(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F1162_13795(EIF_REFERENCE);
extern void EIF_Minit703(void);
extern EIF_BOOLEAN F1377_16804(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void F357_8166(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R12161[])();
extern char *(*R12165[])();
extern long O11797[];
extern long O11798[];

#ifdef __cplusplus
}
#endif

#endif
