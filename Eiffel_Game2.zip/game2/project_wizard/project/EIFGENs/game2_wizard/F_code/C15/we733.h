
#ifndef _C15_we733_
#define _C15_we733_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1185_14363(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_INTEGER_32 F1185_14365(EIF_REFERENCE);
RTOSHF (EIF_INTEGER_32,14366)
static EIF_INTEGER_32 F1185_14366_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F1185_14366(EIF_REFERENCE);
extern EIF_INTEGER_32 F1185_14367(EIF_REFERENCE);
extern EIF_INTEGER_32 F1185_14369(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit733(void);
extern void F1130_13375(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
