/*
 * Code for class WEL_RGB_QUAD
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we719.h"
#include <rgbquad.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_RGB_QUAD}.make */
void F1174_14116 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1162_13788(Current);
	F1174_14121(Current, ((EIF_INTEGER_32) 0L));
	F1174_14122(Current, ((EIF_INTEGER_32) 0L));
	F1174_14123(Current, ((EIF_INTEGER_32) 0L));
	F1174_14124(Current, ((EIF_INTEGER_32) 0L));
	RTLE;
}

/* {WEL_RGB_QUAD}.red */
EIF_INTEGER_32 F1174_14117 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_rgb_quad_get_rgb_red((tp1));
}

/* {WEL_RGB_QUAD}.green */
EIF_INTEGER_32 F1174_14118 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_rgb_quad_get_rgb_green((tp1));
}

/* {WEL_RGB_QUAD}.blue */
EIF_INTEGER_32 F1174_14119 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_rgb_quad_get_rgb_blue((tp1));
}

/* {WEL_RGB_QUAD}.set_red */
void F1174_14121 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_rgb_quad_set_rgb_red((tp1), (arg1));
}

/* {WEL_RGB_QUAD}.set_green */
void F1174_14122 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_rgb_quad_set_rgb_green((tp1), (arg1));
}

/* {WEL_RGB_QUAD}.set_blue */
void F1174_14123 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_rgb_quad_set_rgb_blue((tp1), (arg1));
}

/* {WEL_RGB_QUAD}.set_reserved */
void F1174_14124 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	cwel_rgb_quad_set_rgb_reserved((tp1), (arg1));
}

/* {WEL_RGB_QUAD}.structure_size */
static EIF_INTEGER_32 F1174_14125_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14125);
#define Result RTOSR(14125)
	Result = (EIF_INTEGER_32) sizeof (RGBQUAD);
	RTOSE (14125);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1174_14125 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14125,F1174_14125_body,(Current));
}

/* {WEL_RGB_QUAD}.c_size_of_rgb_quad */
EIF_INTEGER_32 F1174_14126 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (RGBQUAD);
	return Result;
}

/* {WEL_RGB_QUAD}.cwel_rgb_quad_set_rgb_red */
void F1174_14127 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_rgb_quad_set_rgb_red((arg1), (arg2));
}

/* {WEL_RGB_QUAD}.cwel_rgb_quad_set_rgb_green */
void F1174_14128 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_rgb_quad_set_rgb_green((arg1), (arg2));
}

/* {WEL_RGB_QUAD}.cwel_rgb_quad_set_rgb_blue */
void F1174_14129 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_rgb_quad_set_rgb_blue((arg1), (arg2));
}

/* {WEL_RGB_QUAD}.cwel_rgb_quad_set_rgb_reserved */
void F1174_14130 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	cwel_rgb_quad_set_rgb_reserved((arg1), (arg2));
}

/* {WEL_RGB_QUAD}.cwel_rgb_quad_get_rgb_red */
EIF_INTEGER_32 F1174_14131 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_rgb_quad_get_rgb_red((arg1));
	return Result;
}

/* {WEL_RGB_QUAD}.cwel_rgb_quad_get_rgb_green */
EIF_INTEGER_32 F1174_14132 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_rgb_quad_get_rgb_green((arg1));
	return Result;
}

/* {WEL_RGB_QUAD}.cwel_rgb_quad_get_rgb_blue */
EIF_INTEGER_32 F1174_14133 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_rgb_quad_get_rgb_blue((arg1));
	return Result;
}

void EIF_Minit719 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
