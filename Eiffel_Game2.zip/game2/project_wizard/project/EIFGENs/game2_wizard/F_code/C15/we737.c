/*
 * Code for class WEL_BITMAP_INFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we737.h"
#include <wel.h>
#include <bmpinfo.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1188_14425
static EIF_NATURAL_32 inline_F1188_14425 (EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	union {
					RGBQUAD rgb;
					EIF_NATURAL_32 n32;
				} xconvert;
				xconvert.rgb = ((BITMAPINFO*) arg1)->bmiColors[arg2];
				return xconvert.n32;
	;
}
#define INLINE_F1188_14425
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_BITMAP_INFO}.make */
void F1188_14406 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) arg2;
	F1162_13788(Current);
	F1188_14412(Current, arg1);
	RTLE;
}

/* {WEL_BITMAP_INFO}.make_by_dc */
void F1188_14407 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_POINTER tp5;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,tr1);
	RTLR(3,arg1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	F1162_13788(Current);
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_0_1_0_0_0_1_0_0_);
	F1173_14071(RTCW(tr1));
	loc1 = (EIF_REFERENCE) tr1;
	F1188_14412(Current, loc1);
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
	tp2 = *(EIF_POINTER *)(RTCW(arg2)+ _PTROFF_0_3_0_3_0_0_);
	{
		/* INLINED CODE (default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	tp5 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
	GetDIBits(((HDC) tp1), ((HBITMAP) tp2), ((UINT) ((EIF_INTEGER_32) 0L)), ((UINT) ((EIF_INTEGER_32) 0L)), ((VOID *) tp4), ((BITMAPINFO *) tp5), ((UINT) arg3));
	ti4_1 = F1173_14082(RTCV(F1188_14408(Current)));
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) = (EIF_INTEGER_32) ti4_1;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_) > ((EIF_INTEGER_32) 0L))) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
		ti4_1 = F1188_14414(Current);
		tr1 = RTLNS(eif_new_type(1408, 0x00).id, 1408, _OBJSIZ_0_0_0_0_0_1_0_0_);
		*(EIF_POINTER *)tr1 = tp1;
		tp1 = F1377_16802(RTCW(tr1), ti4_1);
		*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) = (EIF_POINTER) tp1;
		{
			/* INLINED CODE (default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_) == tp1)) {
			tr1 = RTLNS(eif_new_type(356, 0x01).id, 356, _OBJSIZ_0_0_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H("No more memory",14,904766585);
			F357_8166(RTCW(tr1), tr2);
		}
	}
	RTLE;
}

/* {WEL_BITMAP_INFO}.header */
EIF_REFERENCE F1188_14408 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_0_1_0_0_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) cwel_bitmap_info_get_header(((BITMAPINFO*) tp1));
	F1130_13375(RTCW(tr1), tp1);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {WEL_BITMAP_INFO}.rgb_quad */
EIF_REFERENCE F1188_14410 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1173, 0x01).id, 1173, _OBJSIZ_0_1_0_0_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
	tp1 = (EIF_POINTER) cwel_bitmap_info_get_rgb_quad((tp1), (arg1));
	F1130_13375(RTCW(tr1), tp1);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {WEL_BITMAP_INFO}.rgb_quad_natural */
EIF_NATURAL_32 F1188_14411 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
	return (EIF_NATURAL_32) inline_F1188_14425(tp1, arg1);
}

/* {WEL_BITMAP_INFO}.set_bitmap_info_header */
void F1188_14412 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_1_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_0_0_0_);
	cwel_bitmap_info_set_header((tp1), (tp2));
	RTLE;
}

/* {WEL_BITMAP_INFO}.structure_size */
EIF_INTEGER_32 F1188_14414 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = (EIF_INTEGER_32) sizeof (BITMAPINFO);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_0_);
	ti4_2 = (EIF_INTEGER_32) sizeof (RGBQUAD);
	Result = (EIF_INTEGER_32) (EIF_INTEGER_32) (Result + ((EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)) * ti4_2)));
	RTLE;
	return Result;
}

/* {WEL_BITMAP_INFO}.c_size_of_bitmap_info */
EIF_INTEGER_32 F1188_14416 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (BITMAPINFO);
	return Result;
}

/* {WEL_BITMAP_INFO}.c_size_of_rgb_quad */
EIF_INTEGER_32 F1188_14417 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (RGBQUAD);
	return Result;
}

/* {WEL_BITMAP_INFO}.cwel_bitmap_info_set_header */
void F1188_14419 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	cwel_bitmap_info_set_header((arg1), (arg2));
}

/* {WEL_BITMAP_INFO}.cwel_bitmap_info_get_header */
EIF_POINTER F1188_14423 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) cwel_bitmap_info_get_header(((BITMAPINFO*) arg1));
	return Result;
}

/* {WEL_BITMAP_INFO}.cwel_bitmap_info_get_rgb_quad */
EIF_POINTER F1188_14424 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) cwel_bitmap_info_get_rgb_quad((arg1), (arg2));
	return Result;
}

/* {WEL_BITMAP_INFO}.cwel_bitmap_info_get_rgb_quad_natural */
EIF_NATURAL_32 F1188_14425 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	
	
	Result = inline_F1188_14425 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2);
	return Result;
}

/* {WEL_BITMAP_INFO}.cwin_get_di_bits */
void F1188_14426 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_POINTER arg5, EIF_POINTER arg6, EIF_INTEGER_32 arg7)
{
	GTCX
	
	
	GetDIBits(((HDC) arg1), ((HBITMAP) arg2), ((UINT) arg3), ((UINT) arg4), ((VOID *) arg5), ((BITMAPINFO *) arg6), ((UINT) arg7));
}

void EIF_Minit737 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
