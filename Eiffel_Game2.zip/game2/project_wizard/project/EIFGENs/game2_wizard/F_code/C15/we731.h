
#ifndef _C15_we731_
#define _C15_we731_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1183_14336(EIF_REFERENCE, EIF_REFERENCE);
RTOSHF (EIF_INTEGER_32,14342)
static EIF_INTEGER_32 F1183_14342_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F1183_14342(EIF_REFERENCE);
extern EIF_INTEGER_32 F1183_14343(EIF_REFERENCE);
extern void EIF_Minit731(void);
extern void F1130_13375(EIF_REFERENCE, EIF_POINTER);

#ifdef __cplusplus
}
#endif

#endif
