
#ifndef _C15_we728_
#define _C15_we728_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1180_14296(EIF_REFERENCE);
extern void EIF_Minit728(void);

#ifdef __cplusplus
}
#endif

#endif
