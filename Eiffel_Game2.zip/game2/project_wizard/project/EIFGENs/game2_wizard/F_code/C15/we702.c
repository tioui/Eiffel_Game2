/*
 * Code for class WEL_GDIP_BITMAP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we702.h"
#include <string.h>
#include "wel_gdi_plus.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1161_13778
static EIF_POINTER inline_F1161_13778 (EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32* arg5)
{
	{
				static FARPROC GdipCreateBitmapFromScan0 = NULL;
				GpBitmap *l_result = NULL;
				*(EIF_INTEGER *) arg5 = 1;

				if (!GdipCreateBitmapFromScan0)	{
					GdipCreateBitmapFromScan0 = GetProcAddress ((HMODULE) arg1, "GdipCreateBitmapFromScan0");
				}
				if (GdipCreateBitmapFromScan0) {
					*(EIF_INTEGER *)arg5 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (INT, INT, INT, PixelFormat, BYTE*, GpBitmap **)) GdipCreateBitmapFromScan0)
								((INT) arg2,
								(INT) arg3,
								(INT) 0,
								(PixelFormat) arg4,
								(BYTE*) NULL,
								(GpBitmap **) &l_result);
				}
				return (EIF_POINTER) l_result;
			}
	;
}
#define INLINE_F1161_13778
#endif
#ifndef INLINE_F1161_13782
static EIF_POINTER inline_F1161_13782 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	{
				static FARPROC GdipCreateBitmapFromHICON = NULL;
				GpBitmap *l_result = NULL;
				*(EIF_INTEGER *) arg3 = 1;

				if (!GdipCreateBitmapFromHICON)	{
					GdipCreateBitmapFromHICON = GetProcAddress ((HMODULE) arg1, "GdipCreateBitmapFromHICON");
				}
				if (GdipCreateBitmapFromHICON) {
					*(EIF_INTEGER *)arg3 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (HICON, GpBitmap **)) GdipCreateBitmapFromHICON)
								((HICON) arg2,
								(GpBitmap **) &l_result);
				}
				return (EIF_POINTER) l_result;
			}
	;
}
#define INLINE_F1161_13782
#endif
#ifndef INLINE_F1161_13785
static void inline_F1161_13785 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_NATURAL_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32* arg6, EIF_POINTER arg7)
{
	{
	static FARPROC GdipBitmapLockBits = NULL;
		
	*(EIF_INTEGER *) arg6 = 1;
	
	if (!GdipBitmapLockBits)	{
		GdipBitmapLockBits = GetProcAddress ((HMODULE) arg1, "GdipBitmapLockBits");
	}					
	if (GdipBitmapLockBits) {
		*(EIF_INTEGER *)arg6 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpBitmap *, GDIPCONST GpRect*, UINT, PixelFormat, BitmapData*)) GdipBitmapLockBits)
					((GpBitmap *) arg2,
					(GDIPCONST GpRect *) arg3,
					(UINT) arg4,
					(PixelFormat) arg5,
					(BitmapData *) arg7);
	}
}
	;
}
#define INLINE_F1161_13785
#endif
#ifndef INLINE_F1161_13786
static void inline_F1161_13786 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32* arg4)
{
	{
	static FARPROC GdipBitmapUnlockBits = NULL;
	*(EIF_INTEGER *) arg4 = 1;
	
	if (!GdipBitmapUnlockBits) {
		GdipBitmapUnlockBits = GetProcAddress ((HMODULE) arg1, "GdipBitmapUnlockBits");
	}
	if (GdipBitmapUnlockBits) {
		*(EIF_INTEGER *)arg4 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpBitmap*, BitmapData*)) GdipBitmapUnlockBits)
					((GpBitmap*) arg2,
					(BitmapData*) arg3);				
	}
}
	;
}
#define INLINE_F1161_13786
#endif
#ifndef INLINE_F1161_13783
static void inline_F1161_13783 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_NATURAL_32 arg3, EIF_NATURAL_32 arg4, EIF_NATURAL_32* arg5, EIF_INTEGER_32* arg6)
{
	{
	static FARPROC GdipGetPixel = NULL;
		
	*(EIF_INTEGER *) arg6 = 1;
	
	if (!GdipGetPixel)	{
		GdipGetPixel = GetProcAddress ((HMODULE) arg1, "GdipBitmapGetPixel");
	}					
	if (GdipGetPixel) {
		*(EIF_INTEGER *)arg6 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpBitmap *, INT, INT, ARGB*)) GdipGetPixel)
					((GpBitmap *) arg2,
					(INT) arg3,
					(INT) arg4,
					(ARGB*) arg5);
	}
}
	;
}
#define INLINE_F1161_13783
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_GDIP_BITMAP}.make_with_size */
void F1161_13760 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	
	
	F1161_13761(Current, arg1, arg2, ((EIF_INTEGER_32) 2498570L));
}

/* {WEL_GDIP_BITMAP}.make_formatted */
void F1161_13761 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1150_13616(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_);
	tp1 = inline_F1161_13778(tp1, arg1, arg2, arg3, (EIF_INTEGER_32 *) &(loc1));
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {WEL_GDIP_BITMAP}.make_from_icon */
void F1161_13763 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1150_13616(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_2_0_3_0_0_);
	tp1 = inline_F1161_13782(tp1, tp2, (EIF_INTEGER_32 *) &(loc1));
	*(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {WEL_GDIP_BITMAP}.make_from_bitmap_with_alpha */
void F1161_13767 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER loc3 = (EIF_POINTER) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc5 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc10 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(9);
	RTLR(0,arg1);
	RTLR(1,loc7);
	RTLR(2,tr1);
	RTLR(3,loc8);
	RTLR(4,loc9);
	RTLR(5,loc6);
	RTLR(6,Current);
	RTLR(7,loc2);
	RTLR(8,loc1);
	RTLIU(9);
	
	RTGC;
	loc4 = F1143_13507(RTCW(arg1));
	loc5 = F1143_13508(RTCW(arg1));
	tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_6_2_0_3_0_7_0_0_);
	F1444_18829(RTCW(tr1));
	loc7 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1187, 0x01).id, 1187, _OBJSIZ_0_1_0_1_0_1_0_0_);
	F1188_14407(RTCW(tr1), loc7, arg1, ((EIF_INTEGER_32) 0L));
	loc8 = (EIF_REFERENCE) tr1;
	loc9 = F1188_14408(RTCW(loc8));
	F1173_14084(RTCW(loc9), (EIF_INTEGER_32) -loc5);
	loc6 = F1443_18732(RTCW(loc7), arg1, ((EIF_INTEGER_32) 0L), loc5, loc8, ((EIF_INTEGER_32) 0L));
	ti4_1 = F1173_14075(RTCW(loc9));
	switch (ti4_1) {
		case 1L:
			loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 196865L);
			break;
		case 4L:
			loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 197634L);
			break;
		case 8L:
			loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 198659L);
			break;
		case 16L:
			ti4_1 = F1173_14076(RTCW(loc9));
			if ((EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 3L))) {
				tb1 = '\0';
				tb2 = '\0';
				tu4_1 = F1188_14411(RTCW(loc8), ((EIF_INTEGER_32) 0L));
				if ((EIF_BOOLEAN)(tu4_1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 63488L))) {
					tu4_1 = F1188_14411(RTCW(loc8), ((EIF_INTEGER_32) 1L));
					tb2 = (EIF_BOOLEAN)(tu4_1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 2016L));
				}
				if (tb2) {
					tu4_1 = F1188_14411(RTCW(loc8), ((EIF_INTEGER_32) 2L));
					tb1 = (EIF_BOOLEAN)(tu4_1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 31L));
				}
				if (tb1) {
					loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135174L);
				} else {
					loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135173L);
				}
			} else {
				loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 135173L);
			}
			break;
		case 24L:
			loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 137224L);
			break;
		case 32L:
			loc10 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2498570L);
			break;
		default:
			break;
	}
	F1161_13761(Current, loc4, loc5, loc10);
	tr1 = RTLNS(eif_new_type(51, 0x01).id, 51, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F52_1119(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), loc4, loc5);
	loc2 = (EIF_REFERENCE) tr1;
	loc1 = F1161_13770(Current, loc2, ((EIF_NATURAL_32) 2U), loc10);
	loc3 = F97_3693(RTCW(loc1));
	tp1 = *(EIF_POINTER *)(RTCW(loc6)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc6)+ _LNGOFF_0_1_0_0_);
	memcpy((void *)loc3, (const void *) tp1, (size_t) ti4_1);
	F1161_13771(Current, loc1);
	F1130_13383(RTCW(loc8));
	RTLE;
}

/* {WEL_GDIP_BITMAP}.lock_bits */
EIF_REFERENCE F1161_13770 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_NATURAL_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Result);
	RTLR(2,Current);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(96, 0x01).id, 96, _OBJSIZ_1_0_0_0_0_0_0_0_);
	F97_3680(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_);
	tp3 = F52_1129(RTCW(arg1));
	tp4 = F97_3695(RTCW(Result));
	inline_F1161_13785(tp1, tp2, tp3, arg2, arg3, (EIF_INTEGER_32 *) &(loc1), tp4);
	RTLE;
	return Result;
}

/* {WEL_GDIP_BITMAP}.unlock_bits */
void F1161_13771 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_);
	tp3 = F97_3695(RTCW(arg1));
	inline_F1161_13786(tp1, tp2, tp3, (EIF_INTEGER_32 *) &(loc1));
	RTLE;
}

/* {WEL_GDIP_BITMAP}.get_pixel */
EIF_NATURAL_32 F1161_13773 (EIF_REFERENCE Current, EIF_NATURAL_32 arg1, EIF_NATURAL_32 arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_NATURAL_32 Result = ((EIF_NATURAL_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_1_1_0_0_0_0_);
	inline_F1161_13783(tp1, tp2, arg1, arg2, (EIF_NATURAL_32 *) &(Result), (EIF_INTEGER_32 *) &(loc1));
	RTLE;
	return Result;
}

/* {WEL_GDIP_BITMAP}.new_bitmap */
EIF_REFERENCE F1161_13775 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,Result);
	RTLR(4,loc3);
	RTLR(5,loc4);
	RTLIU(6);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1172, 0x01).id, 1172, _OBJSIZ_0_1_0_0_0_1_0_0_);
	F1173_14071(RTCW(tr1));
	loc1 = (EIF_REFERENCE) tr1;
	F1173_14085(RTCW(loc1), ((EIF_INTEGER_32) 1L));
	F1173_14086(RTCW(loc1), ((EIF_INTEGER_32) 32L));
	F1173_14087(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	F1173_14088(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	F1173_14089(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	F1173_14090(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	F1173_14091(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	F1173_14092(RTCW(loc1), ((EIF_INTEGER_32) 0L));
	ti4_1 = F1160_13732(Current);
	F1173_14083(RTCW(loc1), ti4_1);
	ti4_1 = F1160_13733(Current);
	F1173_14084(RTCW(loc1), ti4_1);
	tr1 = RTLNS(eif_new_type(1142, 0x01).id, 1142, _OBJSIZ_0_3_0_3_0_2_0_0_);
	F1143_13506(RTCW(tr1), loc1);
	Result = (EIF_REFERENCE) tr1;
	F1130_13383(RTCW(loc1));
	loc2 = *(EIF_POINTER *)(RTCW(Result)+ _PTROFF_0_3_0_3_0_1_);
	tr1 = RTLNS(eif_new_type(51, 0x01).id, 51, _OBJSIZ_1_0_0_0_0_0_0_0_);
	ti4_1 = F1160_13732(Current);
	ti4_2 = F1160_13733(Current);
	F52_1119(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	loc3 = F1161_13770(Current, tr1, ((EIF_NATURAL_32) 1U), ((EIF_INTEGER_32) 925707L));
	tp1 = F97_3693(RTCW(loc3));
	ti4_1 = F1160_13732(Current);
	ti4_2 = F1160_13733(Current);
	memcpy((void *)loc2, (const void *) tp1, (size_t) (EIF_INTEGER_32) ((EIF_INTEGER_32) (ti4_1 * ti4_2) * ((EIF_INTEGER_32) 4L)));
	F1161_13771(Current, loc3);
	tr1 = RTLNS(eif_new_type(58, 0x01).id, 58, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc4 = (EIF_REFERENCE) tr1;
	F59_1316(RTCW(loc4), Result);
	RTLE;
	return Result;
}

/* {WEL_GDIP_BITMAP}.c_gdip_create_bitmap_from_scan0 */
EIF_POINTER F1161_13778 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32* arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1161_13778 ((EIF_POINTER) arg1, (EIF_INTEGER_32) arg2, (EIF_INTEGER_32) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32*) arg5);
	return Result;
}

/* {WEL_GDIP_BITMAP}.c_gdip_create_bitmap_from_hicon */
EIF_POINTER F1161_13782 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1161_13782 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3);
	return Result;
}

/* {WEL_GDIP_BITMAP}.c_gdip_bitmap_get_pixel */
void F1161_13783 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_NATURAL_32 arg3, EIF_NATURAL_32 arg4, EIF_NATURAL_32* arg5, EIF_INTEGER_32* arg6)
{
	GTCX
	
	
	inline_F1161_13783 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_NATURAL_32) arg3, (EIF_NATURAL_32) arg4, (EIF_NATURAL_32*) arg5, (EIF_INTEGER_32*) arg6);
}

/* {WEL_GDIP_BITMAP}.c_gdip_bitmap_lock_bits */
void F1161_13785 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_NATURAL_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32* arg6, EIF_POINTER arg7)
{
	GTCX
	
	
	inline_F1161_13785 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_NATURAL_32) arg4, (EIF_INTEGER_32) arg5, (EIF_INTEGER_32*) arg6, (EIF_POINTER) arg7);
}

/* {WEL_GDIP_BITMAP}.c_gdip_bitmap_unlock_bits */
void F1161_13786 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32* arg4)
{
	GTCX
	
	
	inline_F1161_13786 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_INTEGER_32*) arg4);
}

void EIF_Minit702 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
