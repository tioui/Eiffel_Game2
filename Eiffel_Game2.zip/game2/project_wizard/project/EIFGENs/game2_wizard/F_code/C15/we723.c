/*
 * Code for class WEL_ACCELERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we723.h"
#include <wel.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_ACCELERATOR}.structure_size */
static EIF_INTEGER_32 F1177_14212_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14212);
#define Result RTOSR(14212)
	Result = (EIF_INTEGER_32) sizeof (ACCEL);
	RTOSE (14212);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1177_14212 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14212,F1177_14212_body,(Current));
}

/* {WEL_ACCELERATOR}.c_size_of_accel */
EIF_INTEGER_32 F1177_14213 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (ACCEL);
	return Result;
}

void EIF_Minit723 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
