/*
 * Code for class WEL_PRINTER_INFO_2
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we728.h"
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1180_14296
static EIF_INTEGER_32 inline_F1180_14296 (void)
{
	return sizeof(PRINTER_INFO_2);
	;
}
#define INLINE_F1180_14296
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_PRINTER_INFO_2}.structure_size */
EIF_INTEGER_32 F1180_14296 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = inline_F1180_14296 ();
	return Result;
}

void EIF_Minit728 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
