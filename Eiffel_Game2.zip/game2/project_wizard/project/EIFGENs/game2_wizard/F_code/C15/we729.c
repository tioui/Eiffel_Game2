/*
 * Code for class WEL_TV_HITTESTINFO
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we729.h"
#include "tvhittestinfo.h"
#include "cctrl.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_TV_HITTESTINFO}.make_with_point */
void F1181_14318 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1162_13788(Current);
	F1181_14322(Current, arg1);
	RTLE;
}

/* {WEL_TV_HITTESTINFO}.flags */
EIF_INTEGER_32 F1181_14320 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_INTEGER_32) (EIF_INTEGER_32) cwel_tv_hittestinfo_get_flags((tp1));
}

/* {WEL_TV_HITTESTINFO}.hitem */
EIF_POINTER F1181_14321 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	return (EIF_POINTER) (EIF_POINTER) cwel_tv_hittestinfo_get_hitem((tp1));
}

/* {WEL_TV_HITTESTINFO}.set_point */
void F1181_14322 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_0_0_0_);
	cwel_tv_hittestinfo_set_pt((tp1), (tp2));
	RTLE;
}

/* {WEL_TV_HITTESTINFO}.structure_size */
static EIF_INTEGER_32 F1181_14323_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14323);
#define Result RTOSR(14323)
	Result = (EIF_INTEGER_32) sizeof (TVHITTESTINFO);
	RTOSE (14323);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1181_14323 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14323,F1181_14323_body,(Current));
}

/* {WEL_TV_HITTESTINFO}.c_size_of_tv_hittestinfo */
EIF_INTEGER_32 F1181_14324 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (TVHITTESTINFO);
	return Result;
}

/* {WEL_TV_HITTESTINFO}.cwel_tv_hittestinfo_set_pt */
void F1181_14325 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	cwel_tv_hittestinfo_set_pt((arg1), (arg2));
}

/* {WEL_TV_HITTESTINFO}.cwel_tv_hittestinfo_get_flags */
EIF_INTEGER_32 F1181_14327 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) cwel_tv_hittestinfo_get_flags((arg1));
	return Result;
}

/* {WEL_TV_HITTESTINFO}.cwel_tv_hittestinfo_get_hitem */
EIF_POINTER F1181_14328 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) cwel_tv_hittestinfo_get_hitem((arg1));
	return Result;
}

void EIF_Minit729 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
