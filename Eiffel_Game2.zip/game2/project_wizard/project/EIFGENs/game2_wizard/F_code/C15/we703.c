/*
 * Code for class WEL_STRUCTURE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we703.h"
#include <string.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_STRUCTURE}.make */
void F1162_13788 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12165[dtype-1162])(Current);
	tp1 = calloc((size_t)((EIF_INTEGER_32) 1L), (size_t) ti4_1);
	*(EIF_POINTER *)(Current + O11797[dtype-1129]) = (EIF_POINTER) tp1;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O11797[dtype-1129]) == loc1)) {
		tr1 = RTLNS(eif_new_type(356, 0x01).id, 356, _OBJSIZ_0_0_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H("No more memory",14,904766585);
		F357_8166(RTCW(tr1), tr2);
	}
	*(EIF_BOOLEAN *)(Current + O11798[dtype-1129]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	RTLE;
}

/* {WEL_STRUCTURE}.copy */
void F1162_13789 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != Current)) {
		tb1 = '\01';
		tb2 = '\01';
		tp1 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
		if (!(EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O11797[dtype-1129]) == tp1)) {
			tb2 = *(EIF_BOOLEAN *)(Current + O11798[dtype-1129]);
		}
		if (!tb2) {
			tb1 = (EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O11797[dtype-1129]) == loc1);
		}
		if (tb1) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R12161[dtype-1161])(Current);
		}
		tp1 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
		tp2 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12165[dtype-1162])(Current);
		memcpy((void *)tp1, (const void *) tp2, (size_t) ti4_1);
	}
	RTLE;
}

/* {WEL_STRUCTURE}.is_equal */
EIF_BOOLEAN F1162_13790 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
	tp2 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R12165[dtype-1162])(Current);
	tr1 = RTLNS(eif_new_type(1408, 0x00).id, 1408, _OBJSIZ_0_0_0_0_0_1_0_0_);
	*(EIF_POINTER *)tr1 = tp1;
	Result = F1377_16804(RTCW(tr1), tp2, ti4_1);
	RTLE;
	return Result;
}

/* {WEL_STRUCTURE}.memory_copy */
void F1162_13791 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11797[Dtype(Current)-1129]);
	memcpy((void *)tp1, (const void *) arg1, (size_t) arg2);
	RTLE;
}

/* {WEL_STRUCTURE}.destroy_item */
void F1162_13795 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O11797[dtype-1129]) != loc1)) {
		tp1 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
		free(tp1);
		*(EIF_POINTER *)(Current + O11797[dtype-1129]) = (EIF_POINTER) loc1;
	}
	RTLE;
}

void EIF_Minit703 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
