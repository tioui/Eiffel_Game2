
#ifndef _C15_we714_
#define _C15_we714_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1170_13987(EIF_REFERENCE);
extern EIF_INTEGER_32 F1170_13998(EIF_REFERENCE);
extern void F1170_13999(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern void EIF_Minit714(void);
extern EIF_BOOLEAN F1130_13378(EIF_REFERENCE);
extern void F1162_13788(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
