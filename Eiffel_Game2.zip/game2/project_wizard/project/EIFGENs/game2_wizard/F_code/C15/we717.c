/*
 * Code for class WEL_NM_COMBO_BOX_EX
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we717.h"
#include "nmcomboboxex.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_NM_COMBO_BOX_EX}.make_by_nmhdr */
void F1172_14064 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_0_0_0_);
	F1130_13375(Current, tp1);
	RTLE;
}

/* {WEL_NM_COMBO_BOX_EX}.hdr */
EIF_REFERENCE F1172_14065 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1824, 0x01).id, 1824, _OBJSIZ_0_1_0_0_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	tp1 = (EIF_POINTER) cwel_nm_comboboxex_get_hdr(((NMCOMBOBOXEX*) tp1));
	F1130_13375(RTCW(tr1), tp1);
	Result = (EIF_REFERENCE) tr1;
	RTLE;
	return Result;
}

/* {WEL_NM_COMBO_BOX_EX}.comboboxex_item */
EIF_REFERENCE F1172_14066 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc1);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1430, 0x01).id, 1430, _OBJSIZ_1_1_0_0_0_1_0_0_);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	tp1 = (EIF_POINTER) cwel_nm_comboboxex_get_ceitem(((NMCOMBOBOXEX*) tp1));
	F1130_13375(RTCW(tr1), tp1);
	Result = (EIF_REFERENCE) tr1;
	tr1 = F1825_25787(RTCV(F1172_14065(Current)));
	loc1 = tr1;
	loc1 = RTRV(eif_new_type(1866, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		ti4_1 = F1431_17972(RTCW(Result));
		Result = F1867_27319(loc1, ti4_1);
	}
	RTLE;
	return Result;
}

/* {WEL_NM_COMBO_BOX_EX}.structure_size */
static EIF_INTEGER_32 F1172_14067_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (14067);
#define Result RTOSR(14067)
	Result = (EIF_INTEGER_32) sizeof (NMCOMBOBOXEX);
	RTOSE (14067);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1172_14067 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(14067,F1172_14067_body,(Current));
}

/* {WEL_NM_COMBO_BOX_EX}.c_size_of_nm_comboboxex */
EIF_INTEGER_32 F1172_14068 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) sizeof (NMCOMBOBOXEX);
	return Result;
}

/* {WEL_NM_COMBO_BOX_EX}.cwel_nm_comboboxex_get_hdr */
EIF_POINTER F1172_14069 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) cwel_nm_comboboxex_get_hdr(((NMCOMBOBOXEX*) arg1));
	return Result;
}

/* {WEL_NM_COMBO_BOX_EX}.cwel_nm_comboboxex_get_ceitem */
EIF_POINTER F1172_14070 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) cwel_nm_comboboxex_get_ceitem(((NMCOMBOBOXEX*) arg1));
	return Result;
}

void EIF_Minit717 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
