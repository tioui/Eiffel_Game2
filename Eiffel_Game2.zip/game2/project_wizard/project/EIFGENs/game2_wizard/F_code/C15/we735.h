
#ifndef _C15_we735_
#define _C15_we735_

#ifdef __cplusplus
extern "C" {
#endif

RTOSHF (EIF_INTEGER_32,14389)
static EIF_INTEGER_32 F1186_14389_body(EIF_REFERENCE);
extern EIF_INTEGER_32 F1186_14389(EIF_REFERENCE);
extern void F1186_14391(EIF_REFERENCE);
extern EIF_INTEGER_32 F1186_14392(EIF_REFERENCE);
extern void EIF_Minit735(void);
extern void F773_11164(EIF_REFERENCE);
extern void F1162_13795(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
