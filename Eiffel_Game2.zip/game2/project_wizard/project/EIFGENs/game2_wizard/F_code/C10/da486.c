/*
 * Code for class DATE_TIME_DURATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "da486.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {DATE_TIME_DURATION}.make_by_date_time */
void F442_8572 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	RTAR(Current, arg1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) arg1;
	RTAR(Current, arg2);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) arg2;
	RTLE;
}

/* {DATE_TIME_DURATION}.date */
EIF_REFERENCE F442_8574 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {DATE_TIME_DURATION}.time */
EIF_REFERENCE F442_8575 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {DATE_TIME_DURATION}.is_less */
EIF_BOOLEAN F442_8580 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	tb1 = '\0';
	if (F442_8582(Current)) {
		tb2 = F442_8582(RTCW(arg1));
		tb1 = tb2;
	}
	if (tb1) {
		Result = '\01';
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = F443_8622(RTCW(tr1));
		ti4_2 = F303_7365(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		ti4_3 = F443_8622(RTCW(tr1));
		if (!((EIF_BOOLEAN) ((EIF_INTEGER_32) (F303_7365(Current) + ti4_1) < (EIF_INTEGER_32) (ti4_2 + ti4_3)))) {
			tb1 = '\0';
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
			ti4_1 = F443_8622(RTCW(tr1));
			ti4_2 = F303_7365(RTCW(arg1));
			tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
			ti4_3 = F443_8622(RTCW(tr1));
			if ((EIF_BOOLEAN)((EIF_INTEGER_32) (F303_7365(Current) + ti4_1) == (EIF_INTEGER_32) (ti4_2 + ti4_3))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tr1 = F443_8623(RTCW(tr1));
				tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
				tr2 = F443_8623(RTCW(tr2));
				tb2 = F443_8606(RTCW(tr1), tr2);
				tb1 = tb2;
			}
			Result = tb1;
		}
	}
	RTLE;
	return Result;
}

/* {DATE_TIME_DURATION}.is_equal */
EIF_BOOLEAN F442_8581 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLIU(4);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	tb2 = '\0';
	ti4_1 = F303_7363(RTCW(arg1));
	if ((EIF_BOOLEAN)(F303_7363(Current) == ti4_1)) {
		ti4_1 = F303_7364(RTCW(arg1));
		tb2 = (EIF_BOOLEAN)(F303_7364(Current) == ti4_1);
	}
	if (tb2) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		ti4_1 = F443_8622(RTCW(tr1));
		ti4_2 = F303_7365(RTCW(arg1));
		tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		ti4_3 = F443_8622(RTCW(tr1));
		tb1 = (EIF_BOOLEAN)((EIF_INTEGER_32) (F303_7365(Current) + ti4_1) == (EIF_INTEGER_32) (ti4_2 + ti4_3));
	}
	if (tb1) {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr1 = F443_8623(RTCW(tr1));
		tr2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
		tr2 = F443_8623(RTCW(tr2));
		tb1 = F443_8607(RTCW(tr1), tr2);
		Result = tb1;
	}
	RTLE;
	return Result;
}

/* {DATE_TIME_DURATION}.definite */
EIF_BOOLEAN F442_8582 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	Result = F441_8552(RTCW(tr1));
	RTLE;
	return Result;
}

void EIF_Minit486 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
