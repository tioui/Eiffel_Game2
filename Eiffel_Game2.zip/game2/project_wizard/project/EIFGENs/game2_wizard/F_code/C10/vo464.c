/*
 * Code for class VOID_ASSIGNED_TO_EXPANDED
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "vo464.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {VOID_ASSIGNED_TO_EXPANDED}.code */
EIF_INTEGER_32 F385_8281 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 19L);
}

void EIF_Minit464 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
