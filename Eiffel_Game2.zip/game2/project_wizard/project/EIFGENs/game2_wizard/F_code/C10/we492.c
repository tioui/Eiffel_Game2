/*
 * Code for class WEL_WORD_OPERATIONS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we492.h"
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F448_8654
static EIF_POINTER inline_F448_8654 (EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	return (EIF_POINTER) (rt_uint_ptr) MAKELONG(arg1, arg2);
	;
}
#define INLINE_F448_8654
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_WORD_OPERATIONS}.cwin_lo_word */
EIF_INTEGER_32 F448_8652 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) LOWORD((arg1));
	return Result;
}

/* {WEL_WORD_OPERATIONS}.cwin_hi_word */
EIF_INTEGER_32 F448_8653 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) HIWORD((arg1));
	return Result;
}

/* {WEL_WORD_OPERATIONS}.cwin_make_long */
EIF_POINTER F448_8654 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F448_8654 ((EIF_INTEGER_32) arg1, (EIF_INTEGER_32) arg2);
	return Result;
}

void EIF_Minit492 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
