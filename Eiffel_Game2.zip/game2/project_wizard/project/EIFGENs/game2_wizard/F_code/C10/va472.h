
#ifndef _C10_va472_
#define _C10_va472_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F393_8293(EIF_REFERENCE);
extern void EIF_Minit472(void);

#ifdef __cplusplus
}
#endif

#endif
