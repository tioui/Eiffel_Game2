/*
 * Code for class WEL_TOOLTIP_CONSTANTS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we476.h"
#include "cctrl.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_TOOLTIP_CONSTANTS}.ttdt_initial */
EIF_INTEGER_32 F397_8305 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTDT_INITIAL;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.ttm_activate */
EIF_INTEGER_32 F397_8307 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTM_ACTIVATE;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.ttm_addtool */
EIF_INTEGER_32 F397_8308 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTM_ADDTOOL;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.ttm_deltool */
EIF_INTEGER_32 F397_8309 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTM_DELTOOL;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.ttm_getdelaytime */
EIF_INTEGER_32 F397_8312 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTM_GETDELAYTIME;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.ttm_setmaxtipwidth */
EIF_INTEGER_32 F397_8316 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTM_SETMAXTIPWIDTH;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.ttm_setdelaytime */
EIF_INTEGER_32 F397_8323 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTM_SETDELAYTIME;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.ttm_updatetiptext */
EIF_INTEGER_32 F397_8327 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTM_UPDATETIPTEXT;
	return Result;
}

/* {WEL_TOOLTIP_CONSTANTS}.tts_alwaystip */
EIF_INTEGER_32 F397_8329 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) TTS_ALWAYSTIP;
	return Result;
}

void EIF_Minit476 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
