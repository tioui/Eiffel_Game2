
#ifndef _C10_vo464_
#define _C10_vo464_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F385_8281(EIF_REFERENCE);
extern void EIF_Minit464(void);

#ifdef __cplusplus
}
#endif

#endif
