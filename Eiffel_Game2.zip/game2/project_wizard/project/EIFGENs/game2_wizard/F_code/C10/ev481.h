
#ifndef _C10_ev481_
#define _C10_ev481_

#ifdef __cplusplus
extern "C" {
#endif

extern void F401_8444(EIF_REFERENCE, EIF_REFERENCE);
extern void F401_8446(EIF_REFERENCE);
extern EIF_REFERENCE F401_8447(EIF_REFERENCE);
extern void F401_8449(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F401_8452(EIF_REFERENCE, EIF_BOOLEAN);
extern void F401_8453(EIF_REFERENCE, EIF_BOOLEAN);
static EIF_REFERENCE F401_8459_body(EIF_REFERENCE);
extern EIF_REFERENCE F401_8459(EIF_REFERENCE);
extern void EIF_Minit481(void);
extern void F1146_13558(EIF_REFERENCE, EIF_REFERENCE);
extern void F773_11167(EIF_REFERENCE);
extern void F1444_18829(EIF_REFERENCE);
extern void F1176_14179(EIF_REFERENCE, EIF_REFERENCE);
extern void F1176_14177(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1176_14180(EIF_REFERENCE, EIF_BOOLEAN);
extern void F1443_18728(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1130_13381(EIF_REFERENCE);
extern void F1444_18830(EIF_REFERENCE, EIF_REFERENCE);
extern void F1443_18682(EIF_REFERENCE);
extern void F773_11163(EIF_REFERENCE);
extern void F773_11164(EIF_REFERENCE);
extern void F1176_14176(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1176_14188(EIF_REFERENCE);
extern void F1609_21831(EIF_REFERENCE, EIF_REFERENCE);
extern void F1162_13788(EIF_REFERENCE);
extern void F1143_13501(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1443_18722(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1176_14178(EIF_REFERENCE, EIF_REFERENCE);
extern void F1443_18676(EIF_REFERENCE, EIF_REFERENCE);
extern void F1143_13503(EIF_REFERENCE, EIF_REFERENCE);
extern char *(*R8195[])();
extern char *(*R8196[])();
extern char *(*R8199[])();
extern char *(*R8210[])();
extern char *(*R8211[])();
extern long O8219[];
extern long O8181[];
extern long O8183[];
extern long O8185[];
extern long O8187[];
extern long O8189[];
extern long O8191[];
extern long O8193[];
extern long O6959[];
extern long O6961[];
extern long O6963[];
extern long O8163[];
extern long O8169[];
extern long O8171[];
extern long O6957[];
extern long O8173[];
extern long O8175[];
extern long O8177[];

#ifdef __cplusplus
}
#endif

#endif
