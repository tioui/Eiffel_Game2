/*
 * Code for class POSTCONDITION_VIOLATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "po471.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {POSTCONDITION_VIOLATION}.code */
EIF_INTEGER_32 F392_8291 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 4L);
}

void EIF_Minit471 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
