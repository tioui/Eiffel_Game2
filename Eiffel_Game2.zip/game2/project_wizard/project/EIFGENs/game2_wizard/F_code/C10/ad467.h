
#ifndef _C10_ad467_
#define _C10_ad467_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F388_8285(EIF_REFERENCE);
extern void EIF_Minit467(void);

#ifdef __cplusplus
}
#endif

#endif
