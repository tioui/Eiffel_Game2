
#ifndef _C10_ev479_
#define _C10_ev479_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F399_8402(EIF_REFERENCE);
static EIF_REFERENCE F399_8403_body(EIF_REFERENCE);
extern EIF_REFERENCE F399_8403(EIF_REFERENCE);
extern void F399_8404(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit479(void);
extern void F1082_11663(EIF_REFERENCE);
extern long O8163[];

#ifdef __cplusplus
}
#endif

#endif
