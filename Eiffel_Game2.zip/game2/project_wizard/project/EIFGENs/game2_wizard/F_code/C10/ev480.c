/*
 * Code for class EV_WIDGET_ACTION_SEQUENCES_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev480.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WIDGET_ACTION_SEQUENCES_I}.file_drop_actions */
EIF_REFERENCE F400_8405 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCFDT;
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8166[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,1091,0xFF01,0xFFF9,1,1336,0xFF01,977,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNS(typres0.id, 1091, _OBJSIZ_9_2_0_2_0_0_0_0_);
		}
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8167[dtype-1799])(Current, Result);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8166[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.file_drop_actions_internal */
static EIF_REFERENCE F400_8406_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8406 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8166[Dtype(Current) - 399]);
	if (!r) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1091,0xFF01,0xFFF9,1,1336,0xFF01,977,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			if (RTAT(typres0)) {
				GTCX
				RTLD;
				RTLI(1);
				RTLR(0,Current);
				RTLIU(1);
				r = (F400_8406_body (Current));
				*(EIF_REFERENCE *)(Current + O8166[Dtype(Current) - 399]) = r;
				RTAR(Current, r);
				RTLE;
			}
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_motion_actions */
EIF_REFERENCE F400_8408 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8169[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1105, 0x01).id, 1105, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8169[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_motion_actions_internal */
static EIF_REFERENCE F400_8409_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8409 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8169[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1105, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8409_body (Current));
			*(EIF_REFERENCE *)(Current + O8169[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_button_press_actions */
EIF_REFERENCE F400_8410 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8171[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1111, 0x01).id, 1111, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8171[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_button_press_actions_internal */
static EIF_REFERENCE F400_8411_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8411 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8171[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1111, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8411_body (Current));
			*(EIF_REFERENCE *)(Current + O8171[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_double_press_actions_internal */
static EIF_REFERENCE F400_8413_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8413 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8173[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1111, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8413_body (Current));
			*(EIF_REFERENCE *)(Current + O8173[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_button_release_actions_internal */
static EIF_REFERENCE F400_8415_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8415 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8175[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1111, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8415_body (Current));
			*(EIF_REFERENCE *)(Current + O8175[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_enter_actions_internal */
static EIF_REFERENCE F400_8417_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8417 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8177[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1110, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8417_body (Current));
			*(EIF_REFERENCE *)(Current + O8177[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.mouse_wheel_actions */
EIF_REFERENCE F400_8418 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8179[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1100, 0x01).id, 1100, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8179[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.mouse_wheel_actions_internal */
static EIF_REFERENCE F400_8419_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8419 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8179[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1100, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8419_body (Current));
			*(EIF_REFERENCE *)(Current + O8179[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.pointer_leave_actions_internal */
static EIF_REFERENCE F400_8421_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8421 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8181[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1110, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8421_body (Current));
			*(EIF_REFERENCE *)(Current + O8181[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.key_press_actions */
EIF_REFERENCE F400_8422 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8183[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8183[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.key_press_actions_internal */
static EIF_REFERENCE F400_8423_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8423 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8183[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1097, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8423_body (Current));
			*(EIF_REFERENCE *)(Current + O8183[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.key_press_string_actions */
EIF_REFERENCE F400_8424 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8185[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1102, 0x01).id, 1102, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8185[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.key_press_string_actions_internal */
static EIF_REFERENCE F400_8425_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8425 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8185[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1102, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8425_body (Current));
			*(EIF_REFERENCE *)(Current + O8185[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.key_release_actions */
EIF_REFERENCE F400_8426 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8187[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1097, 0x01).id, 1097, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8187[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.key_release_actions_internal */
static EIF_REFERENCE F400_8427_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8427 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8187[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1097, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8427_body (Current));
			*(EIF_REFERENCE *)(Current + O8187[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.focus_in_actions */
EIF_REFERENCE F400_8428 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8189[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8189[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.focus_in_actions_internal */
static EIF_REFERENCE F400_8429_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8429 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8189[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1110, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8429_body (Current));
			*(EIF_REFERENCE *)(Current + O8189[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.focus_out_actions */
EIF_REFERENCE F400_8430 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8191[dtype-399]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1110, 0x01).id, 1110, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8191[dtype-399]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_WIDGET_ACTION_SEQUENCES_I}.focus_out_actions_internal */
static EIF_REFERENCE F400_8431_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8431 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8191[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1110, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8431_body (Current));
			*(EIF_REFERENCE *)(Current + O8191[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WIDGET_ACTION_SEQUENCES_I}.resize_actions_internal */
static EIF_REFERENCE F400_8433_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F400_8433 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8193[Dtype(Current) - 399]);
	if (!r) {
		if (RTAT(eif_new_type(1095, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F400_8433_body (Current));
			*(EIF_REFERENCE *)(Current + O8193[Dtype(Current) - 399]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


void EIF_Minit480 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
