
#ifndef _C10_da485_
#define _C10_da485_

#ifdef __cplusplus
extern "C" {
#endif

extern void F441_8543(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F441_8545(EIF_REFERENCE);
extern EIF_INTEGER_32 F441_8546(EIF_REFERENCE);
extern EIF_INTEGER_32 F441_8547(EIF_REFERENCE);
extern EIF_BOOLEAN F441_8550(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F441_8551(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F441_8552(EIF_REFERENCE);
extern void EIF_Minit485(void);

#ifdef __cplusplus
}
#endif

#endif
