/*
 * Code for class CREATE_ON_DEFERRED
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "cr468.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {CREATE_ON_DEFERRED}.code */
EIF_INTEGER_32 F389_8287 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_INTEGER_32) ((EIF_INTEGER_32) 17L);
}

void EIF_Minit468 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
