
#ifndef _C10_ev495_
#define _C10_ev495_

#ifdef __cplusplus
extern "C" {
#endif

extern void F510_8736(EIF_REFERENCE);
extern EIF_BOOLEAN F510_8737(EIF_REFERENCE);
extern void F510_8739(EIF_REFERENCE);
extern EIF_BOOLEAN F510_8740(EIF_REFERENCE);
extern void F510_8741(EIF_REFERENCE);
extern EIF_BOOLEAN F510_8742(EIF_REFERENCE);
extern EIF_REFERENCE F510_8747(EIF_REFERENCE);
extern EIF_INTEGER_32 F510_8749(EIF_REFERENCE);
extern EIF_REFERENCE F510_8752(EIF_REFERENCE);
extern EIF_REFERENCE F510_8753(EIF_REFERENCE);
extern void EIF_Minit495(void);
extern void F37_723(EIF_REFERENCE, EIF_NATURAL_32, EIF_NATURAL_32);
extern void F37_710(EIF_REFERENCE);
extern long O18539[];

#ifdef __cplusplus
}
#endif

#endif
