
#ifndef _C10_ei451_
#define _C10_ei451_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F372_8251(EIF_REFERENCE);
extern void F372_8253(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit451(void);

#ifdef __cplusplus
}
#endif

#endif
