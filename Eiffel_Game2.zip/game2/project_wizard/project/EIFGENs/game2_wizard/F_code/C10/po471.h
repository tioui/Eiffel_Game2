
#ifndef _C10_po471_
#define _C10_po471_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F392_8291(EIF_REFERENCE);
extern void EIF_Minit471(void);

#ifdef __cplusplus
}
#endif

#endif
