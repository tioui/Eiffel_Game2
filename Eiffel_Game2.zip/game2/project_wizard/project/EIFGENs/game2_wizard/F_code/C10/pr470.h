
#ifndef _C10_pr470_
#define _C10_pr470_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F391_8289(EIF_REFERENCE);
extern void EIF_Minit470(void);

#ifdef __cplusplus
}
#endif

#endif
