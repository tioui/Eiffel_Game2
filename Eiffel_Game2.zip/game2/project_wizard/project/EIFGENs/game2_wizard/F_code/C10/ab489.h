
#ifndef _C10_ab489_
#define _C10_ab489_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F446_8639(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit489(void);
extern char *(*R8255[])();
extern char *(*R8350[])();

#ifdef __cplusplus
}
#endif

#endif
