
#ifndef _C10_in475_
#define _C10_in475_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F396_8299(EIF_REFERENCE);
extern void F396_8300(EIF_REFERENCE, EIF_BOOLEAN);
extern void EIF_Minit475(void);

#ifdef __cplusplus
}
#endif

#endif
