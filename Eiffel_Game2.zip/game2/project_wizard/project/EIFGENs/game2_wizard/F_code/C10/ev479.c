/*
 * Code for class EV_DRAWABLE_ACTION_SEQUENCES_I
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev479.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_DRAWABLE_ACTION_SEQUENCES_I}.expose_actions */
EIF_REFERENCE F399_8402 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + O8163[dtype-398]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTLE;
		return (EIF_REFERENCE) loc1;
	} else {
		tr1 = RTLNS(eif_new_type(1095, 0x01).id, 1095, _OBJSIZ_9_2_0_2_0_0_0_0_);
		F1082_11663(RTCW(tr1));
		Result = (EIF_REFERENCE) tr1;
		F399_8404(Current, Result);
		RTAR(Current, Result);
		*(EIF_REFERENCE *)(Current + O8163[dtype-398]) = (EIF_REFERENCE) Result;
	}
	RTLE;
	return Result;
}

/* {EV_DRAWABLE_ACTION_SEQUENCES_I}.expose_actions_internal */
static EIF_REFERENCE F399_8403_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F399_8403 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8163[Dtype(Current) - 398]);
	if (!r) {
		if (RTAT(eif_new_type(1095, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F399_8403_body (Current));
			*(EIF_REFERENCE *)(Current + O8163[Dtype(Current) - 398]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_DRAWABLE_ACTION_SEQUENCES_I}.init_expose_actions */
void F399_8404 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	RTGC;
}

void EIF_Minit479 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
