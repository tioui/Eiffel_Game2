
#ifndef _C10_we491_
#define _C10_we491_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_POINTER F447_8649(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_POINTER F447_8650(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_POINTER F447_8651(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit491(void);

#ifdef __cplusplus
}
#endif

#endif
