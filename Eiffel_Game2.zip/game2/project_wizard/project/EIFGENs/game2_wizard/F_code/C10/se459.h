
#ifndef _C10_se459_
#define _C10_se459_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F380_8269(EIF_REFERENCE);
extern void EIF_Minit459(void);

#ifdef __cplusplus
}
#endif

#endif
