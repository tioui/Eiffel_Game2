/*
 * Code for class EV_PIXEL_BUFFER_ITERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev495.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXEL_BUFFER_ITERATOR}.start */
void F510_8736 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_1_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	RTLE;
}

/* {EV_PIXEL_BUFFER_ITERATOR}.after */
EIF_BOOLEAN F510_8737 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_BOOLEAN) (EIF_BOOLEAN) (*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_1_) > *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_3_));
}

/* {EV_PIXEL_BUFFER_ITERATOR}.forth */
void F510_8739 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_) == *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_2_))) {
		*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_NATURAL_32) (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
		(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_1_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	} else {
		(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_)) += (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_ITERATOR}.before */
EIF_BOOLEAN F510_8740 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_1_);
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tu4_1 == (EIF_NATURAL_32) ((EIF_INTEGER_32) 0L));
	return Result;
}

/* {EV_PIXEL_BUFFER_ITERATOR}.back */
void F510_8741 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_) == (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) {
		*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_) = (EIF_NATURAL_32) *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_2_);
		(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_1_)) -= (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	} else {
		(*(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_)) -= (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L);
	}
	RTLE;
}

/* {EV_PIXEL_BUFFER_ITERATOR}.is_empty */
EIF_BOOLEAN F510_8742 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_BOOLEAN) 0;
}

/* {EV_PIXEL_BUFFER_ITERATOR}.item */
EIF_REFERENCE F510_8747 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_BOOLEAN tb1;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	tb1 = *(EIF_BOOLEAN *)(RTCW(tr1) + O18539[Dtype(tr1)-1607]);
	if (tb1) {
		Result = *(EIF_REFERENCE *)(Current);
		tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_);
		tu4_2 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_1_);
		F37_723(RTCW(Result), (EIF_NATURAL_32) (tu4_1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)), (EIF_NATURAL_32) (tu4_2 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L)));
	} else {
		tr1 = RTLNS(eif_new_type(36, 0x01).id, 36, _OBJSIZ_1_4_0_3_0_0_0_0_);
		F37_710(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	}
	RTLE;
	return Result;
}

/* {EV_PIXEL_BUFFER_ITERATOR}.index */
EIF_INTEGER_32 F510_8749 (EIF_REFERENCE Current)
{
	GTCX
	EIF_NATURAL_32 tu4_1;
	EIF_NATURAL_32 tu4_2;
	EIF_NATURAL_32 tu4_3;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tu4_1 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_1_);
	tu4_2 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_2_);
	tu4_3 = *(EIF_NATURAL_32 *)(Current+ _LNGOFF_2_1_0_0_);
	Result = (EIF_INTEGER_32) ((EIF_NATURAL_32) ((EIF_NATURAL_32) (((EIF_NATURAL_32) (tu4_1 - (EIF_NATURAL_32) ((EIF_INTEGER_32) 1L))) * tu4_2) + tu4_3));
	RTLE;
	return Result;
}

/* {EV_PIXEL_BUFFER_ITERATOR}.internal_item */
EIF_REFERENCE F510_8752 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {EV_PIXEL_BUFFER_ITERATOR}.pixel_buffer */
EIF_REFERENCE F510_8753 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


void EIF_Minit495 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
