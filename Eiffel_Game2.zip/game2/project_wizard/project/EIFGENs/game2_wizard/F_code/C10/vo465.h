
#ifndef _C10_vo465_
#define _C10_vo465_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F386_8283(EIF_REFERENCE);
extern void EIF_Minit465(void);

#ifdef __cplusplus
}
#endif

#endif
