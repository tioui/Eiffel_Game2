
#ifndef _C10_io458_
#define _C10_io458_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F379_8263(EIF_REFERENCE);
extern void F379_8266(EIF_REFERENCE, EIF_INTEGER_32);
extern void F379_8267(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit458(void);

#ifdef __cplusplus
}
#endif

#endif
