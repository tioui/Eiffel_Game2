
#ifndef _C10_co488_
#define _C10_co488_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_BOOLEAN F444_8626(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F444_8627(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F444_8628(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F444_8629(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F444_8631(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F444_8632(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit488(void);
extern char *(*R8255[])();

#ifdef __cplusplus
}
#endif

#endif
