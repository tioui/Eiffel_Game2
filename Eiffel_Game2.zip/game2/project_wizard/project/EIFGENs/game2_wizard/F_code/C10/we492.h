
#ifndef _C10_we492_
#define _C10_we492_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F448_8652(EIF_REFERENCE, EIF_POINTER);
extern EIF_INTEGER_32 F448_8653(EIF_REFERENCE, EIF_POINTER);
extern EIF_POINTER F448_8654(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void EIF_Minit492(void);

#ifdef __cplusplus
}
#endif

#endif
