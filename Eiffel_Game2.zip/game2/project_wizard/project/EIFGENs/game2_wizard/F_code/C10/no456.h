
#ifndef _C10_no456_
#define _C10_no456_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F377_8259(EIF_REFERENCE);
extern void F377_8261(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit456(void);

#ifdef __cplusplus
}
#endif

#endif
