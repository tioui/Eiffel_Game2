
#ifndef _C10_cr468_
#define _C10_cr468_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F389_8287(EIF_REFERENCE);
extern void EIF_Minit468(void);

#ifdef __cplusplus
}
#endif

#endif
