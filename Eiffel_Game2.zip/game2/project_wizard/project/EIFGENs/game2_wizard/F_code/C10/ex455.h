
#ifndef _C10_ex455_
#define _C10_ex455_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F376_8257(EIF_REFERENCE);
extern void EIF_Minit455(void);

#ifdef __cplusplus
}
#endif

#endif
