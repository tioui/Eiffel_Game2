/*
 * Code for class RANDOM
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra496.h"
#include <math.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RANDOM}.make */
void F610_9048 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = RTOSCF(9050,F610_9050,(Current));
	F610_9049(Current, ti4_1);
	F609_9039(Current);
	RTLE;
}

/* {RANDOM}.set_seed */
void F610_9049 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_) = (EIF_INTEGER_32) arg1;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTLE;
}

/* {RANDOM}.default_seed */
static EIF_INTEGER_32 F610_9050_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (9050);
#define Result RTOSR(9050)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 123457L);
	RTOSE (9050);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F610_9050 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9050,F610_9050_body,(Current));
}

/* {RANDOM}.modulus */
static EIF_INTEGER_32 F610_9051_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (9051);
#define Result RTOSR(9051)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 2147483647L);
	RTOSE (9051);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F610_9051 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9051,F610_9051_body,(Current));
}

/* {RANDOM}.multiplier */
static EIF_INTEGER_32 F610_9052_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (9052);
#define Result RTOSR(9052)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 16807L);
	RTOSE (9052);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F610_9052 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9052,F610_9052_body,(Current));
}

/* {RANDOM}.increment */
static EIF_INTEGER_32 F610_9053_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (9053);
#define Result RTOSR(9053)
	Result = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	RTOSE (9053);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F610_9053 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9053,F610_9053_body,(Current));
}

/* {RANDOM}.i_th */
EIF_INTEGER_32 F610_9057 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (arg1 >= *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_))) {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_);
		loc1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_);
	} else {
		Result = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_1_);
	}
	for (;;) {
		if ((EIF_BOOLEAN)(loc1 == arg1)) break;
		Result = F610_9062(Current, Result);
		loc1++;
	}
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_3_) = (EIF_INTEGER_32) Result;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_1_0_2_) = (EIF_INTEGER_32) arg1;
	RTLE;
	return Result;
}

/* {RANDOM}.randomize */
EIF_INTEGER_32 F610_9062 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_REAL_64 loc1 = (EIF_REAL_64) 0;
	EIF_REAL_64 tr8_1;
	EIF_REAL_64 tr8_2;
	EIF_REAL_64 tr8_3;
	EIF_REAL_64 tr8_4;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tr8_1 = RTOSCF(9067,F610_9067,(Current));
	tr8_2 = (EIF_REAL_64) (arg1);
	tr8_3 = RTOSCF(9068,F610_9068,(Current));
	tr8_4 = RTOSCF(9066,F610_9066,(Current));
	loc1 = F610_9063(Current, (EIF_REAL_64) ((EIF_REAL_64) (tr8_1 * tr8_2) + tr8_3), tr8_4);
	ti4_1 = (EIF_INTEGER_32) loc1;
	RTLE;
	return (EIF_INTEGER_32) ti4_1;
}

/* {RANDOM}.double_mod */
EIF_REAL_64 F610_9063 (EIF_REFERENCE Current, EIF_REAL_64 arg1, EIF_REAL_64 arg2)
{
	GTCX
	EIF_REAL_64 Result = ((EIF_REAL_64) 0);
	
	
	
	RTGC;
	Result = (EIF_REAL_64) floor((double) (EIF_REAL_64) ((EIF_REAL_64) (arg1) /  (EIF_REAL_64) (arg2)));
	Result = (EIF_REAL_64) (EIF_REAL_64) (arg1 - (EIF_REAL_64) (Result * arg2));
	return Result;
}

/* {RANDOM}.dmod */
static EIF_REAL_64 F610_9066_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9066);
#define Result RTOSR(9066)
	ti4_1 = RTOSCF(9051,F610_9051,(Current));
	Result = (EIF_REAL_64) (ti4_1);
	RTOSE (9066);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F610_9066 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9066,F610_9066_body,(Current));
}

/* {RANDOM}.dmul */
static EIF_REAL_64 F610_9067_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9067);
#define Result RTOSR(9067)
	ti4_1 = RTOSCF(9052,F610_9052,(Current));
	Result = (EIF_REAL_64) (ti4_1);
	RTOSE (9067);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F610_9067 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9067,F610_9067_body,(Current));
}

/* {RANDOM}.dinc */
static EIF_REAL_64 F610_9068_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	

	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (9068);
#define Result RTOSR(9068)
	ti4_1 = RTOSCF(9053,F610_9053,(Current));
	Result = (EIF_REAL_64) (ti4_1);
	RTOSE (9068);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REAL_64 F610_9068 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(9068,F610_9068_body,(Current));
}

void EIF_Minit496 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
