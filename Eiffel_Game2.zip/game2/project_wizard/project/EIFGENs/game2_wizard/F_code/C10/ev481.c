/*
 * Code for class EV_PIXMAP_IMP_STATE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev481.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PIXMAP_IMP_STATE}.copy_events_from_other */
void F401_8444 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc11 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc12 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc13 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc14 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc15 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc16 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc17 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCDT;
	RTLD;
	
	RTLI(20);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc6);
	RTLR(9,loc7);
	RTLR(10,loc8);
	RTLR(11,loc9);
	RTLR(12,loc10);
	RTLR(13,loc11);
	RTLR(14,loc12);
	RTLR(15,loc13);
	RTLR(16,loc14);
	RTLR(17,loc15);
	RTLR(18,loc16);
	RTLR(19,loc17);
	RTLIU(20);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8163[Dtype(arg1)-398]);
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTAR(Current, loc1);
		*(EIF_REFERENCE *)(Current + O8163[dtype-398]) = (EIF_REFERENCE) loc1;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8189[Dtype(arg1)-399]);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		RTAR(Current, loc2);
		*(EIF_REFERENCE *)(Current + O8189[dtype-399]) = (EIF_REFERENCE) loc2;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8191[Dtype(arg1)-399]);
	loc3 = tr1;
	if (EIF_TEST(loc3)) {
		RTAR(Current, loc3);
		*(EIF_REFERENCE *)(Current + O8191[dtype-399]) = (EIF_REFERENCE) loc3;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8183[Dtype(arg1)-399]);
	loc4 = tr1;
	if (EIF_TEST(loc4)) {
		RTAR(Current, loc4);
		*(EIF_REFERENCE *)(Current + O8183[dtype-399]) = (EIF_REFERENCE) loc4;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8185[Dtype(arg1)-399]);
	loc5 = tr1;
	if (EIF_TEST(loc5)) {
		RTAR(Current, loc5);
		*(EIF_REFERENCE *)(Current + O8185[dtype-399]) = (EIF_REFERENCE) loc5;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8187[Dtype(arg1)-399]);
	loc6 = tr1;
	if (EIF_TEST(loc6)) {
		RTAR(Current, loc6);
		*(EIF_REFERENCE *)(Current + O8187[dtype-399]) = (EIF_REFERENCE) loc6;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8171[Dtype(arg1)-399]);
	loc7 = tr1;
	if (EIF_TEST(loc7)) {
		RTAR(Current, loc7);
		*(EIF_REFERENCE *)(Current + O8171[dtype-399]) = (EIF_REFERENCE) loc7;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8175[Dtype(arg1)-399]);
	loc8 = tr1;
	if (EIF_TEST(loc8)) {
		RTAR(Current, loc8);
		*(EIF_REFERENCE *)(Current + O8175[dtype-399]) = (EIF_REFERENCE) loc8;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8173[Dtype(arg1)-399]);
	loc9 = tr1;
	if (EIF_TEST(loc9)) {
		RTAR(Current, loc9);
		*(EIF_REFERENCE *)(Current + O8173[dtype-399]) = (EIF_REFERENCE) loc9;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8177[Dtype(arg1)-399]);
	loc10 = tr1;
	if (EIF_TEST(loc10)) {
		RTAR(Current, loc10);
		*(EIF_REFERENCE *)(Current + O8177[dtype-399]) = (EIF_REFERENCE) loc10;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8181[Dtype(arg1)-399]);
	loc11 = tr1;
	if (EIF_TEST(loc11)) {
		RTAR(Current, loc11);
		*(EIF_REFERENCE *)(Current + O8181[dtype-399]) = (EIF_REFERENCE) loc11;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8169[Dtype(arg1)-399]);
	loc12 = tr1;
	if (EIF_TEST(loc12)) {
		RTAR(Current, loc12);
		*(EIF_REFERENCE *)(Current + O8169[dtype-399]) = (EIF_REFERENCE) loc12;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O8193[Dtype(arg1)-399]);
	loc13 = tr1;
	if (EIF_TEST(loc13)) {
		RTAR(Current, loc13);
		*(EIF_REFERENCE *)(Current + O8193[dtype-399]) = (EIF_REFERENCE) loc13;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O6961[Dtype(arg1)-287]);
	loc14 = tr1;
	if (EIF_TEST(loc14)) {
		RTAR(Current, loc14);
		*(EIF_REFERENCE *)(Current + O6961[dtype-287]) = (EIF_REFERENCE) loc14;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O6963[Dtype(arg1)-287]);
	loc15 = tr1;
	if (EIF_TEST(loc15)) {
		RTAR(Current, loc15);
		*(EIF_REFERENCE *)(Current + O6963[dtype-287]) = (EIF_REFERENCE) loc15;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O6957[Dtype(arg1)-287]);
	loc16 = tr1;
	if (EIF_TEST(loc16)) {
		RTAR(Current, loc16);
		*(EIF_REFERENCE *)(Current + O6957[dtype-287]) = (EIF_REFERENCE) loc16;
	}
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + O6959[Dtype(arg1)-287]);
	loc17 = tr1;
	if (EIF_TEST(loc17)) {
		RTAR(Current, loc17);
		*(EIF_REFERENCE *)(Current + O6959[dtype-287]) = (EIF_REFERENCE) loc17;
	}
	RTLE;
}

/* {EV_PIXMAP_IMP_STATE}.gdi_compact */
void F401_8446 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {EV_PIXMAP_IMP_STATE}.build_icon */
EIF_REFERENCE F401_8447 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = F401_8452(Current, (EIF_BOOLEAN) 1);
	loc1 = RTRV(eif_new_type(1146, 0x00), loc1);
	RTCT0(NULL, EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	RTLE;
	return (EIF_REFERENCE) loc1;
}

/* {EV_PIXMAP_IMP_STATE}.init_from_pixel_buffer */
void F401_8449 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,loc1);
	RTLR(3,arg1);
	RTLIU(4);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(Current + O8219[Dtype(Current)-400]);
	RTCT0(NULL, EX_CHECK);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	loc1 = RTRV(eif_new_type(1608, 0x00), loc1);
	RTCT0(NULL, EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	F1609_21831(RTCW(loc1), loc2);
	RTLE;
}

/* {EV_PIXMAP_IMP_STATE}.build_graphical_resource */
EIF_REFERENCE F401_8452 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc8 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc9 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc10 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(13);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc6);
	RTLR(3,Current);
	RTLR(4,loc7);
	RTLR(5,loc5);
	RTLR(6,loc2);
	RTLR(7,loc3);
	RTLR(8,loc4);
	RTLR(9,loc8);
	RTLR(10,loc9);
	RTLR(11,loc10);
	RTLR(12,Result);
	RTLIU(13);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_2_0_2_0_1_0_0_);
	F1162_13788(RTCW(tr1));
	loc1 = (EIF_REFERENCE) tr1;
	F1130_13381(RTCW(loc1));
	F1176_14180(RTCW(loc1), arg1);
	loc6 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8195[dtype-1799])(Current);
	tr1 = RTLNS(eif_new_type(1142, 0x01).id, 1142, _OBJSIZ_0_3_0_3_0_2_0_0_);
	F1143_13503(RTCW(tr1), loc6);
	loc7 = (EIF_REFERENCE) tr1;
	F773_11163(RTCW(loc7));
	F773_11164(RTCW(loc6));
	if ((EIF_BOOLEAN) !arg1) {
		loc5 = *(EIF_REFERENCE *)(Current + O8219[dtype-400]);
		loc5 = RTRV(eif_new_type(1545, 0x00), loc5);
		if ((EIF_BOOLEAN)(loc5 != NULL)) {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_6_3_0_1_);
			F1176_14176(RTCW(loc1), ti4_1);
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc5)+ _LNGOFF_6_3_0_2_);
			F1176_14177(RTCW(loc1), ti4_1);
		}
	}
	tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_6_2_0_3_0_7_0_0_);
	F1444_18829(RTCW(tr1));
	loc2 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1142, 0x01).id, 1142, _OBJSIZ_0_3_0_3_0_2_0_0_);
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8210[dtype-1799])(Current);
	ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8211[dtype-1799])(Current);
	F1143_13501(RTCW(tr1), loc2, ti4_1, ti4_2);
	loc3 = (EIF_REFERENCE) tr1;
	F773_11163(RTCW(loc3));
	F1443_18676(RTCW(loc2), loc3);
	tr1 = RTLNS(eif_new_type(208, 0x01).id, 208, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc4 = (EIF_REFERENCE) tr1;
	if ((FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8199[dtype-1799])(Current)) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8210[dtype-1799])(Current);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8211[dtype-1799])(Current);
		ti4_3 = ((EIF_INTEGER_32) 16711778L);
		F1443_18728(RTCW(loc2), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2, ti4_3);
		loc8 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8196[dtype-1799])(Current);
		RTCT0(NULL, EX_CHECK);
		if ((EIF_BOOLEAN)(loc8 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_6_2_0_3_0_7_0_0_);
		F1444_18830(RTCW(tr1), loc2);
		loc9 = (EIF_REFERENCE) tr1;
		F1443_18676(RTCW(loc9), loc8);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8210[dtype-1799])(Current);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8211[dtype-1799])(Current);
		ti4_3 = ((EIF_INTEGER_32) 6684742L);
		F1443_18722(RTCW(loc2), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2, loc9, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_3);
		tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_6_2_0_3_0_7_0_0_);
		F1444_18829(RTCW(tr1));
		loc10 = (EIF_REFERENCE) tr1;
		F1443_18676(RTCW(loc10), loc7);
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8210[dtype-1799])(Current);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8211[dtype-1799])(Current);
		ti4_3 = ((EIF_INTEGER_32) 2229030L);
		F1443_18722(RTCW(loc10), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2, loc2, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_3);
		F1443_18682(RTCW(loc10));
		F773_11167(RTCW(loc10));
		F1443_18682(RTCW(loc9));
		F773_11167(RTCW(loc9));
	} else {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8210[dtype-1799])(Current);
		ti4_2 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8211[dtype-1799])(Current);
		ti4_3 = ((EIF_INTEGER_32) 66L);
		F1443_18728(RTCW(loc2), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2, ti4_3);
	}
	F1443_18682(RTCW(loc2));
	F773_11167(RTCW(loc2));
	F1176_14179(RTCW(loc1), loc7);
	F1176_14178(RTCW(loc1), loc3);
	if (arg1) {
		tr1 = RTLNS(eif_new_type(1146, 0x01).id, 1146, _OBJSIZ_0_2_0_3_0_1_0_0_);
		F1146_13558(RTCW(tr1), loc1);
		Result = (EIF_REFERENCE) tr1;
	} else {
		tr1 = RTLNS(eif_new_type(1729, 0x01).id, 1729, _OBJSIZ_0_2_0_3_0_2_0_0_);
		F1146_13558(RTCW(tr1), loc1);
		Result = (EIF_REFERENCE) tr1;
	}
	F773_11164(RTCW(loc3));
	F1176_14188(RTCW(loc1));
	F773_11164(RTCW(loc7));
	if ((EIF_BOOLEAN)(loc8 != NULL)) {
		F773_11164(RTCW(loc8));
	}
	RTLE;
	return Result;
}

/* {EV_PIXMAP_IMP_STATE}.update_for_pick_and_drop */
void F401_8453 (EIF_REFERENCE Current, EIF_BOOLEAN arg1)
{
	GTCX
	
	
	RTGC;
}

/* {EV_PIXMAP_IMP_STATE}.interface */
static EIF_REFERENCE F401_8459_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F401_8459 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O8219[Dtype(Current) - 400]);
	if (!r) {
		if (RTAT(eif_new_type(1544, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F401_8459_body (Current));
			*(EIF_REFERENCE *)(Current + O8219[Dtype(Current) - 400]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


void EIF_Minit481 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
