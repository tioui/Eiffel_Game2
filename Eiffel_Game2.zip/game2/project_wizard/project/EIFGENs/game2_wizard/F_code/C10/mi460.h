
#ifndef _C10_mi460_
#define _C10_mi460_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F381_8271(EIF_REFERENCE);
extern void EIF_Minit460(void);

#ifdef __cplusplus
}
#endif

#endif
