
#ifndef _C10_ch474_
#define _C10_ch474_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F395_8297(EIF_REFERENCE);
extern void EIF_Minit474(void);

#ifdef __cplusplus
}
#endif

#endif
