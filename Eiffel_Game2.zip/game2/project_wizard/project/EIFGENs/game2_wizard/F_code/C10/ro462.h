
#ifndef _C10_ro462_
#define _C10_ro462_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F383_8273(EIF_REFERENCE);
extern EIF_REFERENCE F383_8274(EIF_REFERENCE);
extern EIF_INTEGER_32 F383_8275(EIF_REFERENCE);
extern void F383_8277(EIF_REFERENCE, EIF_REFERENCE);
extern void F383_8278(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit462(void);

#ifdef __cplusplus
}
#endif

#endif
