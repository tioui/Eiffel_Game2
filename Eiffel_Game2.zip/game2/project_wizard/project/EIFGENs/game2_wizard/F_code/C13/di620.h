
#ifndef _C13_di620_
#define _C13_di620_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1117_12239(EIF_REFERENCE);
extern EIF_BOOLEAN F1117_12251(EIF_REFERENCE);
extern void F1117_12262(EIF_REFERENCE);
extern void F1117_12279(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit620(void);

#ifdef __cplusplus
}
#endif

#endif
