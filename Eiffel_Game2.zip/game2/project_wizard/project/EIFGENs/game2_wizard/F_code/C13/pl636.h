
#ifndef _C13_pl636_
#define _C13_pl636_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1127_12992(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit636(void);
extern char *(*R11275[])();

#ifdef __cplusplus
}
#endif

#endif
