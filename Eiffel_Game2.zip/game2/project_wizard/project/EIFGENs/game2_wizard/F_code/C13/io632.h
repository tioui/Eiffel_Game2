
#ifndef _C13_io632_
#define _C13_io632_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1124_12560(EIF_REFERENCE);
extern void F1124_12585(EIF_REFERENCE);
extern EIF_REFERENCE F1124_12635(EIF_REFERENCE);
extern void EIF_Minit632(void);
extern void F1125_12803(EIF_REFERENCE);
extern EIF_BOOLEAN F1125_12775(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
