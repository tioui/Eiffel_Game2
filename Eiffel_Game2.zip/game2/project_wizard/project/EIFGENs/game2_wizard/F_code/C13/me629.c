/*
 * Code for class MEMORY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "me629.h"
#include "eif_memory.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MEMORY}.dispose */
void F1121_12523 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {MEMORY}.full_coalesce */
void F1121_12525 (EIF_REFERENCE Current)
{
	GTCX
	
	eif_mem_coalesc();
	
}

/* {MEMORY}.full_collect */
void F1121_12527 (EIF_REFERENCE Current)
{
	GTCX
	
	plsc();
	
}

void EIF_Minit629 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
