
#ifndef _C13_me629_
#define _C13_me629_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1121_12523(EIF_REFERENCE);
extern void F1121_12525(EIF_REFERENCE);
extern void F1121_12527(EIF_REFERENCE);
extern void EIF_Minit629(void);

#ifdef __cplusplus
}
#endif

#endif
