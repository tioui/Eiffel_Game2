/*
 * Code for class EV_ABSTRACT_PICK_AND_DROPABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev639.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.target_data_function */
static EIF_REFERENCE F1129_13106_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F1129_13106 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O11590[Dtype(Current) - 1128]);
	if (!r) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1414,0xFF01,0xFFF9,1,1336,0,0xFF01,97,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			if (RTAT(typres0)) {
				GTCX
				RTLD;
				RTLI(1);
				RTLR(0,Current);
				RTLIU(1);
				r = (F1129_13106_body (Current));
				*(EIF_REFERENCE *)(Current + O11590[Dtype(Current) - 1128]) = r;
				RTAR(Current, r);
				RTLE;
			}
		}
	}
	return r;
}


/* {EV_ABSTRACT_PICK_AND_DROPABLE}.init_drop_actions */
void F1129_13121 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(6);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,tr1);
	RTLR(4,tr2);
	RTLR(5,tr3);
	RTLIU(6);
	
	RTGC;
	loc2 = F1128_13037(Current);
	loc1 = RTOSCF(13123,F1129_13123,(Current));
	tr1 = F1082_11683(RTCW(arg1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,3,1336,0xFF01,1049,1366,1366,1366,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 4, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
	RTAR(tr2,loc1);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc2;
	((EIF_TYPED_VALUE *)tr2+3)->it_i4 = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1413,0xFF01,0xFFF9,0,1336,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNRF(typres0.id, (EIF_POINTER) __A1878_87, (EIF_POINTER) _A1878_87, (EIF_POINTER)(F1050_11422),tr2, 1, 0);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8455[Dtype(tr1)-608])(RTCW(tr1), tr3);
	tr1 = F1082_11684(RTCW(arg1));
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFFF9,2,1336,0xFF01,1049,1366,1366,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr2 = RTLNTS(typres0.id, 3, 0);
	}
	((EIF_TYPED_VALUE *)tr2+1)->it_r = loc1;
	RTAR(tr2,loc1);
	((EIF_TYPED_VALUE *)tr2+2)->it_i4 = loc2;
	
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1413,0xFF01,0xFFF9,0,1336,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr3 = RTLNRF(typres0.id, (EIF_POINTER) __A1878_93, (EIF_POINTER) _A1878_93, (EIF_POINTER)(F1050_11428),tr2, 1, 0);
	}
	(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8455[Dtype(tr1)-608])(RTCW(tr1), tr3);
	RTLE;
}

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.create_interface_objects */
void F1129_13122 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	{
		/* INLINED CODE (do_nothing) */
		tr1 = RTOSCF(13123,F1129_13123,(Current));
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.pnd_targets */
static EIF_REFERENCE F1129_13123_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (13123);
#define Result RTOSR(13123)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1487, 0x01).id, 1487, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1479_19077(RTCW(tr1));
	Result = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	Result = F1607_21780(RTCW(Result));
	Result = *(EIF_REFERENCE *)(RTCW(Result) + _REFACS_26_);
	RTOSE (13123);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1129_13123 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13123,F1129_13123_body,(Current));
}

/* {EV_ABSTRACT_PICK_AND_DROPABLE}.default_pixmaps */
static EIF_REFERENCE F1129_13124_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (13124);
#define Result RTOSR(13124)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(46, 0x01).id, 46, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13124);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1129_13124 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13124,F1129_13124_body,(Current));
}

void EIF_Minit639 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
