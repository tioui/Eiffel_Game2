
#ifndef _C13_we624_
#define _C13_we624_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1118_12332(EIF_REFERENCE);
extern void F1118_12337(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit624(void);

#ifdef __cplusplus
}
#endif

#endif
