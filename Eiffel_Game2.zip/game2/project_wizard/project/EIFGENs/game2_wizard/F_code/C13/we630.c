/*
 * Code for class WEL_FONT_FAMILY_ENUMERATOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we630.h"
#include "windows.h"
#include "enumfont.h"
#include "../C13/we630.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_FONT_FAMILY_ENUMERATOR}.make */
void F1122_12533 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	cwel_set_enum_font_fam_procedure_address(((EIF_POINTER) F1122_12538));
	F1122_12541(Current, Current);
	F1122_12537(Current, arg1, arg2);
	{
		/* INLINED CODE (default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	cwel_set_enum_font_fam_procedure_address((tp2));
	{
		/* INLINED CODE (default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp2 = tp1;
	tr1 = RTLNS(eif_new_type(1408, 0x00).id, 1408, _OBJSIZ_0_0_0_0_0_1_0_0_);
	*(EIF_POINTER *)tr1 = tp2;
	cwel_set_font_family_enumerator_object((tr1));
	RTLE;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.init_action */
void F1122_12535 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.finish_action */
void F1122_12536 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.enumerate */
void F1122_12537 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,arg2);
	RTLR(2,loc2);
	RTLR(3,tr1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	{
		/* INLINED CODE (init_action) */
		/* END INLINED CODE */
	}
	;
	if ((EIF_BOOLEAN)(arg2 != NULL)) {
		tr1 = RTLNS(eif_new_type(1085, 0x01).id, 1085, _OBJSIZ_1_0_0_1_0_0_0_0_);
		F1085_11737(RTCW(tr1), arg2);
		loc2 = (EIF_REFERENCE) tr1;
		loc1 = F1085_11744(RTCW(loc2));
	}
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
	tp2 = (EIF_POINTER) cwel_enum_font_fam_procedure;
	{
		/* INLINED CODE (default_pointer) */
		tp3 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp4 = tp3;
	EnumFontFamilies(((HDC) tp1), ((LPCTSTR) loc1), ((FONTENUMPROC) tp2), ((LPARAM) tp4));
	{
		/* INLINED CODE (finish_action) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.update_current */
void F1122_12538 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1212, 0x01).id, 1212, _OBJSIZ_0_1_0_0_0_1_0_0_);
	F1213_15028(RTCW(tr1), arg1);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1190, 0x01).id, 1190, _OBJSIZ_0_1_0_0_0_1_0_0_);
	F1130_13375(RTCW(tr1), arg2);
	loc2 = (EIF_REFERENCE) tr1;
	F1123_12549(Current, loc1, loc2, arg3);
	RTLE;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.dispose */
void F1122_12539 (EIF_REFERENCE Current)
{
	GTCX
	
	
	cwel_release_font_family_enumerator_object;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.cwel_set_enum_font_fam_procedure_address */
void F1122_12540 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	cwel_set_enum_font_fam_procedure_address((arg1));
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.cwel_set_font_family_enumerator_object */
void F1122_12541 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	{
		EIF_OBJECT larg1 = &arg1;
		cwel_set_font_family_enumerator_object((larg1));
	}
	RTLE;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.cwel_release_font_family_enumerator_object */
void F1122_12542 (EIF_REFERENCE Current)
{
	GTCX
	
	
	cwel_release_font_family_enumerator_object;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.cwel_enum_font_fam_procedure */
EIF_POINTER F1122_12543 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) cwel_enum_font_fam_procedure;
	return Result;
}

/* {WEL_FONT_FAMILY_ENUMERATOR}.cwin_enum_font_families */
void F1122_12544 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	
	
	EnumFontFamilies(((HDC) arg1), ((LPCTSTR) arg2), ((FONTENUMPROC) arg3), ((LPARAM) arg4));
}

void EIF_Minit630 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
