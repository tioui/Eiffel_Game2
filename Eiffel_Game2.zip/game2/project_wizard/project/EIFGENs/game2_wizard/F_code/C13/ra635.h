
#ifndef _C13_ra635_
#define _C13_ra635_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1126_12976(EIF_REFERENCE, EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_POINTER F1126_12983(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1126_12989(EIF_REFERENCE, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32, EIF_POINTER);
extern void EIF_Minit635(void);

#ifdef __cplusplus
}
#endif

#endif
