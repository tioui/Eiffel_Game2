
#ifndef _C13_id637_
#define _C13_id637_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1128_13037(EIF_REFERENCE);
extern EIF_REFERENCE F1128_13038(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1128_13040(EIF_REFERENCE);
extern EIF_BOOLEAN F1128_13041(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_13042(EIF_REFERENCE, EIF_REFERENCE);
extern void F1128_13043(EIF_REFERENCE);
extern void EIF_Minit637(void);
extern EIF_INTEGER_32 F772_11156(EIF_REFERENCE, EIF_REFERENCE);
extern long O11529[];

#ifdef __cplusplus
}
#endif

#endif
