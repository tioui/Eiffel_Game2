
#ifndef _C13_re609_
#define _C13_re609_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1113_11975(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit609(void);

#ifdef __cplusplus
}
#endif

#endif
