
#ifndef _C13_mu627_
#define _C13_mu627_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1120_12462(EIF_REFERENCE);
extern EIF_BOOLEAN F1120_12464(EIF_REFERENCE);
extern void F1120_12465(EIF_REFERENCE);
extern EIF_BOOLEAN F1120_12466(EIF_REFERENCE);
extern void F1120_12467(EIF_REFERENCE);
extern void F1120_12468(EIF_REFERENCE);
extern void F1120_12471(EIF_REFERENCE);
extern EIF_POINTER F1120_12473(EIF_REFERENCE);
extern void F1120_12474(EIF_REFERENCE, EIF_POINTER);
extern void F1120_12475(EIF_REFERENCE, EIF_POINTER);
extern EIF_BOOLEAN F1120_12476(EIF_REFERENCE, EIF_POINTER);
extern void F1120_12477(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit627(void);

#ifdef __cplusplus
}
#endif

#endif
