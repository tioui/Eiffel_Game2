/*
 * Code for class RAW_FILE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ra635.h"
#include "eif_file.h"
#include <stdio.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {RAW_FILE}.read_to_managed_pointer */
void F1126_12976 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_1_0_0_);
	tp1 = RTPOF(tp1,arg2);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_4_6_2_4_1_0_);
	ti4_1 = (EIF_INTEGER_32) fread((void*) tp1, (size_t) ((EIF_INTEGER_32) 1L), (size_t) arg3, (FILE*) tp2);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_6_2_2_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {RAW_FILE}.file_open */
EIF_POINTER F1126_12983 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	Result = (EIF_POINTER) eif_file_binary_open((EIF_FILENAME) arg1, (int) arg2);
	
	return Result;
}

/* {RAW_FILE}.file_fread */
EIF_INTEGER_32 F1126_12989 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) fread((void*) arg1, (size_t) arg2, (size_t) arg3, (FILE*) arg4);
	
	return Result;
}

void EIF_Minit635 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
