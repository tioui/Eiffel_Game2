/*
 * Code for class EV_WEL_FONT_ENUMERATOR_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev631.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WEL_FONT_ENUMERATOR_IMP}.font_faces */
EIF_REFERENCE F1123_12546 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1056,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F1057_11529(RTCW(tr1), ((EIF_INTEGER_32) 20L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
		{
			static EIF_TYPE_INDEX typarr0[] = {1046,0xFF01,1190,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F1047_11377(RTCW(tr1), ((EIF_INTEGER_32) 20L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
		{
			static EIF_TYPE_INDEX typarr0[] = {1046,0xFF01,1217,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
			tr1 = RTLNSMART(typres0.id);
		}
		F1047_11377(RTCW(tr1), ((EIF_INTEGER_32) 20L));
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		F450_8700(RTCW(tr1));
		tr1 = RTLNS(eif_new_type(1448, 0x01).id, 1448, _OBJSIZ_6_2_0_3_0_7_0_0_);
		loc1 = (EIF_REFERENCE) tr1;
		F1449_18872(RTCW(loc1));
		F1122_12533(Current, loc1, NULL);
		F1449_18873(RTCW(loc1));
	}
	RTLE;
	return (EIF_REFERENCE) *(EIF_REFERENCE *)(Current + _REFACS_2_);
}

/* {EV_WEL_FONT_ENUMERATOR_IMP}.text_metrics */
static EIF_REFERENCE F1123_12547_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F1123_12547 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current);
	if (!r) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1046,0xFF01,1190,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			if (RTAT(typres0)) {
				GTCX
				RTLD;
				RTLI(1);
				RTLR(0,Current);
				RTLIU(1);
				r = (F1123_12547_body (Current));
				*(EIF_REFERENCE *)(Current) = r;
				RTAR(Current, r);
				RTLE;
			}
		}
	}
	return r;
}


/* {EV_WEL_FONT_ENUMERATOR_IMP}.log_fonts */
static EIF_REFERENCE F1123_12548_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F1123_12548 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + _REFACS_1_);
	if (!r) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1046,0xFF01,1217,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			if (RTAT(typres0)) {
				GTCX
				RTLD;
				RTLI(1);
				RTLR(0,Current);
				RTLIU(1);
				r = (F1123_12548_body (Current));
				*(EIF_REFERENCE *)(Current + _REFACS_1_) = r;
				RTAR(Current, r);
				RTLE;
			}
		}
	}
	return r;
}


/* {EV_WEL_FONT_ENUMERATOR_IMP}.action */
void F1123_12549 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,tr1);
	RTLR(4,arg2);
	RTLR(5,tr2);
	RTLIU(6);
	
	RTGC;
	loc1 = F1213_15029(RTCW(arg1));
	loc1 = F1218_15130(RTCW(loc1));
	loc1 = F1_14(loc1);
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_2_) == NULL)) {
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
		tb1 = F1057_11540(RTCW(tr1), loc1);
		if ((EIF_BOOLEAN) !tb1) {
			tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
			(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8455[Dtype(tr1)-608])(RTCW(tr1), loc1);
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current) == NULL)) {
	} else {
		tr1 = *(EIF_REFERENCE *)(Current);
		tr2 = F1_14(arg2);
		F1047_11422(RTCW(tr1), tr2, loc1);
	}
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + _REFACS_1_) == NULL)) {
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
		tr2 = F1213_15029(RTCW(arg1));
		F1047_11422(RTCW(tr1), tr2, loc1);
	}
	RTLE;
}

/* {EV_WEL_FONT_ENUMERATOR_IMP}.internal_font_faces */
static EIF_REFERENCE F1123_12550_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F1123_12550 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + _REFACS_2_);
	if (!r) {
		{
			static EIF_TYPE_INDEX typarr0[] = {1056,0xFF01,1422,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			if (RTAT(typres0)) {
				GTCX
				RTLD;
				RTLI(1);
				RTLR(0,Current);
				RTLIU(1);
				r = (F1123_12550_body (Current));
				*(EIF_REFERENCE *)(Current + _REFACS_2_) = r;
				RTAR(Current, r);
				RTLE;
			}
		}
	}
	return r;
}


void EIF_Minit631 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
