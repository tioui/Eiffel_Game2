
#ifndef _C13_ev613_
#define _C13_ev613_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1244_12054(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern void F1244_12055(EIF_REFERENCE, EIF_INTEGER_32, EIF_INTEGER_32);
extern EIF_INTEGER_32 F1244_12060(EIF_REFERENCE);
extern EIF_INTEGER_32 F1244_12062(EIF_REFERENCE);
extern void EIF_Minit613(void);

#ifdef __cplusplus
}
#endif

#endif
