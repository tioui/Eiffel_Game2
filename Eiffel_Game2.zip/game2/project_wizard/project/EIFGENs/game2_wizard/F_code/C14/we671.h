
#ifndef _C14_we671_
#define _C14_we671_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1144_13524(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1144_13526(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit671(void);

#ifdef __cplusplus
}
#endif

#endif
