
#ifndef _C14_we657_
#define _C14_we657_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1130_13375(EIF_REFERENCE, EIF_POINTER);
extern EIF_POINTER F1130_13376(EIF_REFERENCE);
extern EIF_BOOLEAN F1130_13377(EIF_REFERENCE);
extern EIF_BOOLEAN F1130_13378(EIF_REFERENCE);
extern void F1130_13379(EIF_REFERENCE, EIF_POINTER);
extern void F1130_13380(EIF_REFERENCE);
extern void F1130_13381(EIF_REFERENCE);
extern void F1130_13383(EIF_REFERENCE);
extern EIF_POINTER F1130_13385(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit657(void);
extern char *(*R11804[])();
extern long O11797[];
extern long O11798[];

#ifdef __cplusplus
}
#endif

#endif
