
#ifndef _C14_we668_
#define _C14_we668_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1141_13485(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F1141_13486(EIF_REFERENCE);
extern EIF_POINTER F1141_13487(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void F1141_13488(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit668(void);

#ifdef __cplusplus
}
#endif

#endif
