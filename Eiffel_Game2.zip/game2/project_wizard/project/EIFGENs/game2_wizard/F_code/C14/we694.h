
#ifndef _C14_we694_
#define _C14_we694_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1154_13679(EIF_REFERENCE);
extern void F1154_13681(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32*);
extern void EIF_Minit694(void);

#ifdef __cplusplus
}
#endif

#endif
