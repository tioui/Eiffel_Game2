
#ifndef _C14_we697_
#define _C14_we697_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1157_13703(EIF_REFERENCE);
extern void F1157_13706(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32*);
extern void EIF_Minit697(void);

#ifdef __cplusplus
}
#endif

#endif
