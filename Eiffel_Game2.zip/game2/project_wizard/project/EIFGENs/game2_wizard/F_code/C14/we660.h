
#ifndef _C14_we660_
#define _C14_we660_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1133_13401(EIF_REFERENCE);
extern EIF_POINTER F1133_13405(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit660(void);
extern long O11815[];

#ifdef __cplusplus
}
#endif

#endif
