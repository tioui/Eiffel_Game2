
#ifndef _C14_we665_
#define _C14_we665_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1138_13474(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 13475)


extern EIF_REFERENCE F1138_13475(EIF_REFERENCE);
extern void EIF_Minit665(void);
extern void F1137_13466(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
