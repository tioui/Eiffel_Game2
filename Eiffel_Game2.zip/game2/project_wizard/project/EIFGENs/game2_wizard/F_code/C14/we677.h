
#ifndef _C14_we677_
#define _C14_we677_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1149_13589(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1149_13590(EIF_REFERENCE, EIF_REFERENCE);
extern void F1149_13592(EIF_REFERENCE, EIF_REFERENCE);
extern void F1149_13593(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1149_13598(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_POINTER F1149_13600(EIF_REFERENCE, EIF_POINTER);
extern EIF_POINTER F1149_13601(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit677(void);
extern long O20280[];

#ifdef __cplusplus
}
#endif

#endif
