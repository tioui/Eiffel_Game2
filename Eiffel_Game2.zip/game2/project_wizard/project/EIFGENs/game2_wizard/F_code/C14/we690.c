/*
 * Code for class WEL_GDIP_ANY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we690.h"
#include "wel_gdi_plus.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1150_13621
static void inline_F1150_13621 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	{
	static FARPROC GdipFree = NULL;
	if (!GdipFree) {
		GdipFree = GetProcAddress ((HMODULE)arg1, "GdipFree");
	}
	if (GdipFree) {
		(FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (void *)) GdipFree) ((void *) arg2);
	}
}
	;
}
#define INLINE_F1150_13621
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_GDIP_ANY}.default_create */
void F1150_13616 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1150_13617(Current);
}

/* {WEL_GDIP_ANY}.initialize_gdi_plus */
void F1150_13617 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = RTOSCF(1493,F80_1493,(RTCV(RTOSCF(13622,F1150_13622,(Current)))));
	*(EIF_POINTER *)(Current + O12003[Dtype(Current)-1149]) = (EIF_POINTER) tp1;
	RTLE;
}

/* {WEL_GDIP_ANY}.destroy_item */
void F1150_13620 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O12003[dtype-1149]) != loc1)) {
		tp1 = *(EIF_POINTER *)(Current + O12003[dtype-1149]);
		tp2 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
		inline_F1150_13621(tp1, tp2);
		{
			/* INLINED CODE (default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current + O11797[dtype-1129]) = (EIF_POINTER) tp2;
	}
	RTLE;
}

/* {WEL_GDIP_ANY}.c_gdip_free */
void F1150_13621 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	
	
	inline_F1150_13621 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
}

/* {WEL_GDIP_ANY}.gdi_plus_starter */
static EIF_REFERENCE F1150_13622_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (13622);
#define Result RTOSR(13622)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(79, 0x01).id, 79, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	tb1 = F80_1495(RTCW(Result));
	if (tb1) {
		RTOSCP(1491,F80_1491,(RTCW(Result)));
	}
	RTOSE (13622);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1150_13622 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13622,F1150_13622_body,(Current));
}

void EIF_Minit690 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
