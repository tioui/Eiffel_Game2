
#ifndef _C14_we659_
#define _C14_we659_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1132_13390(EIF_REFERENCE, EIF_POINTER);
extern void F1132_13392(EIF_REFERENCE);
extern void EIF_Minit659(void);

#ifdef __cplusplus
}
#endif

#endif
