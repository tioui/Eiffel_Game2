
#ifndef _C14_we664_
#define _C14_we664_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1137_13465(EIF_REFERENCE, EIF_REFERENCE);
extern void F1137_13466(EIF_REFERENCE, EIF_REFERENCE);
extern void F1137_13470(EIF_REFERENCE);
extern EIF_POINTER F1137_13472(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit664(void);
extern EIF_POINTER F768_11133(EIF_REFERENCE);
extern void F1085_11737(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1085_11744(EIF_REFERENCE);
extern void F768_11114(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
