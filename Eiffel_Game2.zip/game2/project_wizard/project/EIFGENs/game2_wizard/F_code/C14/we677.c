/*
 * Code for class WEL_BRUSH
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we677.h"
#include <wel.h>
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_BRUSH}.make_by_sys_color */
void F1149_13589 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (EIF_POINTER) cwel_integer_to_pointer(((EIF_INTEGER) arg1));
	*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) = (EIF_POINTER) tp1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {WEL_BRUSH}.make_solid */
void F1149_13590 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	ti4_1 = *(EIF_INTEGER_32 *)(RTCW(arg1) + O20280[Dtype(arg1)-1725]);
	tp1 = (EIF_POINTER) CreateSolidBrush(((COLORREF) ti4_1));
	*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_BRUSH}.make_by_pattern */
void F1149_13592 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_3_0_3_0_0_);
	tp1 = (EIF_POINTER) CreatePatternBrush(((HBITMAP) tp1));
	*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_BRUSH}.make_indirect */
void F1149_13593 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_0_0_0_);
	tp1 = (EIF_POINTER) CreateBrushIndirect(((LOGBRUSH *) tp1));
	*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_BRUSH}.cwin_create_solid_brush */
EIF_POINTER F1149_13598 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CreateSolidBrush(((COLORREF) arg1));
	return Result;
}

/* {WEL_BRUSH}.cwin_create_brush_indirect */
EIF_POINTER F1149_13600 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CreateBrushIndirect(((LOGBRUSH *) arg1));
	return Result;
}

/* {WEL_BRUSH}.cwin_create_pattern_brush */
EIF_POINTER F1149_13601 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CreatePatternBrush(((HBITMAP) arg1));
	return Result;
}

void EIF_Minit677 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
