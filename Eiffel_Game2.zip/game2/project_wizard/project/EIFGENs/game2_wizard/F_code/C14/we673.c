/*
 * Code for class WEL_GRAPHICAL_RESOURCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we673.h"
#include <wel.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_GRAPHICAL_RESOURCE}.make_by_icon_info */
void F1146_13558 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_2_2_0_2_0_0_);
	tp1 = (EIF_POINTER) CreateIconIndirect(((ICONINFO *) tp1));
	*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_GRAPHICAL_RESOURCE}.make_by_predefined_id */
void F1146_13561 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1140_13480(Current, arg1);
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_GRAPHICAL_RESOURCE}.get_icon_info */
EIF_REFERENCE F1146_13562 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_2_0_2_0_1_0_0_);
	F1162_13788(RTCW(tr1));
	loc1 = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_);
	tp2 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_2_2_0_2_0_0_);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) GetIconInfo(((HICON) tp1), ((ICONINFO *) tp2)) != ((EIF_INTEGER_32) 0L))) {
		F1176_14165(RTCW(loc1));
		RTLE;
		return (EIF_REFERENCE) loc1;
	}
	RTLE;
	return (EIF_REFERENCE) 0;
}

/* {WEL_GRAPHICAL_RESOURCE}.delete */
void F1146_13563 (EIF_REFERENCE Current)
{
	GTCX
	
	
	F1146_13564(Current);
}

/* {WEL_GRAPHICAL_RESOURCE}.delete_gdi_object */
void F1146_13564 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_BOOLEAN loc2 = (EIF_BOOLEAN) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) != loc1)) {
		loc2 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R11967[Dtype(Current)-1146])(Current);
		if ((EIF_BOOLEAN) !loc2) {
		}
		*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) = (EIF_POINTER) loc1;
	}
	RTLE;
}

/* {WEL_GRAPHICAL_RESOURCE}.cwin_get_icon_info */
EIF_INTEGER_32 F1146_13568 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) GetIconInfo(((HICON) arg1), ((ICONINFO *) arg2));
	return Result;
}

/* {WEL_GRAPHICAL_RESOURCE}.cwin_create_icon_indirect */
EIF_POINTER F1146_13569 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CreateIconIndirect(((ICONINFO *) arg1));
	return Result;
}

void EIF_Minit673 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
