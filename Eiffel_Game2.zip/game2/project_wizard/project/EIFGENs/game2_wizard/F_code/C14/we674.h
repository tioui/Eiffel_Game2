
#ifndef _C14_we674_
#define _C14_we674_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1147_13571(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern EIF_BOOLEAN F1147_13572(EIF_REFERENCE);
extern EIF_POINTER F1147_13573(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern EIF_BOOLEAN F1147_13574(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit674(void);

#ifdef __cplusplus
}
#endif

#endif
