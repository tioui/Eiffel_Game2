/*
 * Code for class WEL_GDI_ANY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we669.h"
#include <wel.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_GDI_ANY}.make_by_pointer */
void F1142_13490 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1130_13375(Current, arg1);
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_GDI_ANY}.gdi_make */
void F1142_13491 (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
}

/* {WEL_GDI_ANY}.gdi_objects_count */
EIF_INTEGER_32 F1142_13492 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(13497,F1142_13497,(Current));
	Result = *(EIF_INTEGER_32 *)(eif_optimize_return = 1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8692[Dtype(tr1)-695])(RTCW(tr1)));
	RTLE;
	return Result;
}

/* {WEL_GDI_ANY}.destroy_item */
void F1142_13493 (EIF_REFERENCE Current)
{
	GTCX
	
	
	(FUNCTION_CAST(void, (EIF_REFERENCE)) R11905[Dtype(Current)-1141])(Current);
}

/* {WEL_GDI_ANY}.delete_gdi_object */
void F1142_13494 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN loc1 = (EIF_BOOLEAN) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current + O11797[dtype-1129]) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current + O11797[dtype-1129]);
		loc1 = (EIF_BOOLEAN) EIF_TEST(DeleteObject(((HGDIOBJ) tp1)));
		{
			/* INLINED CODE (default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current + O11797[dtype-1129]) = (EIF_POINTER) tp2;
	}
	RTLE;
}

/* {WEL_GDI_ANY}.increase_gdi_objects_count */
void F1142_13495 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(13497,F1142_13497,(Current));
	tr2 = RTOSCF(13497,F1142_13497,(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(eif_optimize_return = 1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8692[Dtype(tr2)-695])(RTCW(tr2)));
	F697_9149(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {WEL_GDI_ANY}.decrease_gdi_objects_count */
void F1142_13496 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLIU(3);
	
	RTGC;
	tr1 = RTOSCF(13497,F1142_13497,(Current));
	tr2 = RTOSCF(13497,F1142_13497,(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(eif_optimize_return = 1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8692[Dtype(tr2)-695])(RTCW(tr2)));
	F697_9149(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {WEL_GDI_ANY}.gdi_objects_count_cell */
static EIF_REFERENCE F1142_13497_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (13497);
#define Result RTOSR(13497)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,696,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 696, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F697_9148(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13497);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1142_13497 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13497,F1142_13497_body,(Current));
}

/* {WEL_GDI_ANY}.cwin_delete_object */
EIF_BOOLEAN F1142_13498 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(DeleteObject(((HGDIOBJ) arg1)));
	return Result;
}

void EIF_Minit669 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
