/*
 * Code for class WEL_ANY
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we657.h"
#include <wel.h>

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_ANY}.make_by_pointer */
void F1130_13375 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	*(EIF_POINTER *)(Current + O11797[dtype-1129]) = (EIF_POINTER) arg1;
	*(EIF_BOOLEAN *)(Current + O11798[dtype-1129]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	RTLE;
}

/* {WEL_ANY}.item */
EIF_POINTER F1130_13376 (EIF_REFERENCE Current)
{
	return *(EIF_POINTER *)(Current + O11797[Dtype(Current) - 1129]);
}


/* {WEL_ANY}.shared */
EIF_BOOLEAN F1130_13377 (EIF_REFERENCE Current)
{
	return *(EIF_BOOLEAN *)(Current + O11798[Dtype(Current) - 1129]);
}


/* {WEL_ANY}.exists */
EIF_BOOLEAN F1130_13378 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current + O11797[Dtype(Current)-1129]);
	{
		/* INLINED CODE (default_pointer) */
		tp2 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	tp3 = tp2;
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(tp1 != tp3);
	RTLE;
	return Result;
}

/* {WEL_ANY}.set_item */
void F1130_13379 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	
	
	*(EIF_POINTER *)(Current + O11797[Dtype(Current)-1129]) = (EIF_POINTER) arg1;
}

/* {WEL_ANY}.set_shared */
void F1130_13380 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11798[Dtype(Current)-1129]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
}

/* {WEL_ANY}.set_unshared */
void F1130_13381 (EIF_REFERENCE Current)
{
	GTCX
	
	
	*(EIF_BOOLEAN *)(Current + O11798[Dtype(Current)-1129]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
}

/* {WEL_ANY}.dispose */
void F1130_13383 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if (F1130_13378(Current)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11798[dtype-1129]);
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R11804[dtype-1130])(Current);
	}
	RTLE;
}

/* {WEL_ANY}.cwel_integer_to_pointer */
EIF_POINTER F1130_13385 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) cwel_integer_to_pointer(((EIF_INTEGER) arg1));
	return Result;
}

void EIF_Minit657 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
