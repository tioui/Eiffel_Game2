
#ifndef _C14_we691_
#define _C14_we691_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1151_13624(EIF_REFERENCE);
extern EIF_INTEGER_32 F1151_13626(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern void EIF_Minit691(void);

#ifdef __cplusplus
}
#endif

#endif
