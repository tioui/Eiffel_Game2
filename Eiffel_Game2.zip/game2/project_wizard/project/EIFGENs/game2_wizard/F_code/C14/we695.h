
#ifndef _C14_we695_
#define _C14_we695_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1155_13685(EIF_REFERENCE);
extern void F1155_13689(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32*);
extern void EIF_Minit695(void);

#ifdef __cplusplus
}
#endif

#endif
