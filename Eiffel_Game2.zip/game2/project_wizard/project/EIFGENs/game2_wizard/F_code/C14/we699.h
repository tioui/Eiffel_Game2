
#ifndef _C14_we699_
#define _C14_we699_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1159_13709(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_POINTER F1159_13710(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32, EIF_INTEGER_32*);
extern void EIF_Minit699(void);
extern void F1150_13616(EIF_REFERENCE);
extern long O11797[];

#ifdef __cplusplus
}
#endif

#endif
