
#ifndef _C14_we666_
#define _C14_we666_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1139_13476(EIF_REFERENCE);RTOSHF (EIF_REFERENCE, 13477)


extern EIF_REFERENCE F1139_13477(EIF_REFERENCE);
extern void EIF_Minit666(void);
extern void F1137_13466(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
