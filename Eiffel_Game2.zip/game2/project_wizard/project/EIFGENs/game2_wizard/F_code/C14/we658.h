
#ifndef _C14_we658_
#define _C14_we658_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1131_13389(EIF_REFERENCE);
extern void EIF_Minit658(void);

#ifdef __cplusplus
}
#endif

#endif
