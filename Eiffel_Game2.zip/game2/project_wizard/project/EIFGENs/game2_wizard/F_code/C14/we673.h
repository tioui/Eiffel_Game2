
#ifndef _C14_we673_
#define _C14_we673_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1146_13558(EIF_REFERENCE, EIF_REFERENCE);
extern void F1146_13561(EIF_REFERENCE, EIF_POINTER);
extern EIF_REFERENCE F1146_13562(EIF_REFERENCE);
extern void F1146_13563(EIF_REFERENCE);
extern void F1146_13564(EIF_REFERENCE);
extern EIF_INTEGER_32 F1146_13568(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
extern EIF_POINTER F1146_13569(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit673(void);
extern void F1176_14165(EIF_REFERENCE);
extern void F1140_13480(EIF_REFERENCE, EIF_POINTER);
extern void F1162_13788(EIF_REFERENCE);
extern char *(*R11967[])();

#ifdef __cplusplus
}
#endif

#endif
