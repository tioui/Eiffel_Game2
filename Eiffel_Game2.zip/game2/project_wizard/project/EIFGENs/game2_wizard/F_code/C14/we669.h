
#ifndef _C14_we669_
#define _C14_we669_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1142_13490(EIF_REFERENCE, EIF_POINTER);
extern void F1142_13491(EIF_REFERENCE);
extern EIF_INTEGER_32 F1142_13492(EIF_REFERENCE);
extern void F1142_13493(EIF_REFERENCE);
extern void F1142_13494(EIF_REFERENCE);
extern void F1142_13495(EIF_REFERENCE);
extern void F1142_13496(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,13497)
static EIF_REFERENCE F1142_13497_body(EIF_REFERENCE);
extern EIF_REFERENCE F1142_13497(EIF_REFERENCE);
extern EIF_BOOLEAN F1142_13498(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit669(void);
extern void F697_9149(EIF_REFERENCE, EIF_INTEGER_32);
extern void F697_9148(EIF_REFERENCE, EIF_INTEGER_32);
extern void F1130_13375(EIF_REFERENCE, EIF_POINTER);
extern char *(*R11905[])();
extern char *(*R8692[])();
extern long O11797[];

#ifdef __cplusplus
}
#endif

#endif
