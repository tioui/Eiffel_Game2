
#ifndef _C14_we690_
#define _C14_we690_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1150_13616(EIF_REFERENCE);
extern void F1150_13617(EIF_REFERENCE);
extern void F1150_13620(EIF_REFERENCE);
extern void F1150_13621(EIF_REFERENCE, EIF_POINTER, EIF_POINTER);
RTOSHF (EIF_REFERENCE,13622)
static EIF_REFERENCE F1150_13622_body(EIF_REFERENCE);
extern EIF_REFERENCE F1150_13622(EIF_REFERENCE);
extern void EIF_Minit690(void);
extern EIF_BOOLEAN F80_1495(EIF_REFERENCE);
extern EIF_POINTER F80_1493(EIF_REFERENCE);
extern void F80_1491(EIF_REFERENCE);
RTOSHF(EIF_POINTER,1493)
RTOSHP(1491)
extern long O12003[];
extern long O11797[];

#ifdef __cplusplus
}
#endif

#endif
