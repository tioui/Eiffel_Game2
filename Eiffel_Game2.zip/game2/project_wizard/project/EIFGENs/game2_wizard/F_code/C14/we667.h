
#ifndef _C14_we667_
#define _C14_we667_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1140_13480(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit667(void);
extern char *(*R11896[])();
extern long O11798[];

#ifdef __cplusplus
}
#endif

#endif
