/*
 * Code for class WEL_BITMAP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we670.h"
#include <wel.h>
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1143_13522
static EIF_POINTER inline_F1143_13522 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER* arg4, EIF_POINTER arg5, EIF_NATURAL_64 arg6)
{
	return (EIF_POINTER) (CreateDIBSection (
				(HDC) arg1,
				(CONST BITMAPINFO *) arg2,
				(UINT) arg3,
				(VOID **) arg4,
				(HANDLE) arg5,
				(DWORD) arg6
				))
	;
}
#define INLINE_F1143_13522
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_BITMAP}.make_compatible */
void F1143_13501 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
	tp1 = (EIF_POINTER) CreateCompatibleBitmap(((HDC) tp1), ((int) arg2), ((int) arg3));
	*(EIF_POINTER *)(Current+ _PTROFF_0_3_0_3_0_0_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_BITMAP}.make_by_dib */
void F1143_13502 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(4);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLR(3,tr1);
	RTLIU(4);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
	tr1 = *(EIF_REFERENCE *)(RTCW(arg2) + _REFACS_1_);
	tp2 = *(EIF_POINTER *)(RTCW(tr1)+ _PTROFF_0_1_0_0_0_0_);
	ti4_1 = (EIF_INTEGER_32) CBM_INIT;
	tp3 = F1231_15533(RTCW(arg2));
	tp4 = *(EIF_POINTER *)(RTCW(arg2)+ _PTROFF_2_1_0_1_0_0_);
	tp1 = (EIF_POINTER) CreateDIBitmap(((HDC) tp1), ((BITMAPINFOHEADER *) tp2), ((DWORD) ti4_1), ((void *) tp3), ((BITMAPINFO *) tp4), ((UINT) arg3));
	*(EIF_POINTER *)(Current+ _PTROFF_0_3_0_3_0_0_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_BITMAP}.make_by_bitmap */
void F1143_13503 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_3_0_3_0_0_);
	ti4_1 = F1143_13507(RTCW(arg1));
	ti4_2 = F1143_13508(RTCW(arg1));
	tp1 = (EIF_POINTER) CopyImage(((HANDLE) tp1), ((UINT) ((EIF_INTEGER_32) 0L)), ((int) ti4_1), ((int) ti4_2), ((UINT) ((EIF_INTEGER_32) 0L)));
	*(EIF_POINTER *)(Current+ _PTROFF_0_3_0_3_0_0_) = (EIF_POINTER) tp1;
	*(EIF_BOOLEAN *)(Current+ _CHROFF_0_1_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
	tb1 = '\01';
	tb2 = *(EIF_BOOLEAN *)(RTCW(arg1)+ _CHROFF_0_2_);
	if (!tb2) {
		tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_3_0_3_0_1_);
		{
			/* INLINED CODE (default_pointer) */
			tp2 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tb1 = (EIF_BOOLEAN)(tp1 != tp2);
	}
	if (tb1) {
		*(EIF_BOOLEAN *)(Current+ _CHROFF_0_2_) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_BITMAP}.make_direct */
void F1143_13505 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg5);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(767, 0x01).id, 767, _OBJSIZ_1_0_0_1_0_0_0_0_);
	F768_11114(RTCW(tr1), arg5);
	loc1 = (EIF_REFERENCE) tr1;
	tp1 = F768_11133(RTCW(loc1));
	tp1 = (EIF_POINTER) CreateBitmap(((int) arg1), ((int) arg2), ((UINT) arg3), ((UINT) arg4), ((CONST VOID *) tp1));
	*(EIF_POINTER *)(Current+ _PTROFF_0_3_0_3_0_0_) = (EIF_POINTER) tp1;
	{
		/* INLINED CODE (gdi_make) */
		/* END INLINED CODE */
	}
	;
	RTLE;
}

/* {WEL_BITMAP}.make_dib */
void F1143_13506 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_0_0_0_);
	tp1 = inline_F1143_13522(loc1, tp1, ((EIF_INTEGER_32) 0L), (EIF_POINTER *) &(loc2), loc1, (EIF_NATURAL_64) ((EIF_INTEGER_32) 0L));
	*(EIF_POINTER *)(Current+ _PTROFF_0_3_0_3_0_0_) = (EIF_POINTER) tp1;
	*(EIF_POINTER *)(Current+ _PTROFF_0_3_0_3_0_1_) = (EIF_POINTER) loc2;
	RTLE;
}

/* {WEL_BITMAP}.width */
EIF_INTEGER_32 F1143_13507 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1168_13877(RTCV(F1143_13509(Current)));
	RTLE;
	return Result;
}

/* {WEL_BITMAP}.height */
EIF_INTEGER_32 F1143_13508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = F1168_13878(RTCV(F1143_13509(Current)));
	RTLE;
	return Result;
}

/* {WEL_BITMAP}.log_bitmap */
EIF_REFERENCE F1143_13509 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1167, 0x01).id, 1167, _OBJSIZ_0_1_0_0_0_1_0_0_);
	F1168_13875(RTCW(tr1), Current);
	RTLE;
	return (EIF_REFERENCE) tr1;
}

/* {WEL_BITMAP}.load_item */
void F1143_13513 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = (EIF_POINTER) LoadBitmap(((HINSTANCE) arg1), ((LPCTSTR) arg2));
	*(EIF_POINTER *)(Current+ _PTROFF_0_3_0_3_0_0_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {WEL_BITMAP}.cwin_create_compatible_bitmap */
EIF_POINTER F1143_13514 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CreateCompatibleBitmap(((HDC) arg1), ((int) arg2), ((int) arg3));
	return Result;
}

/* {WEL_BITMAP}.cwin_create_di_bitmap */
EIF_POINTER F1143_13515 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER arg4, EIF_POINTER arg5, EIF_INTEGER_32 arg6)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CreateDIBitmap(((HDC) arg1), ((BITMAPINFOHEADER *) arg2), ((DWORD) arg3), ((void *) arg4), ((BITMAPINFO *) arg5), ((UINT) arg6));
	return Result;
}

/* {WEL_BITMAP}.cwin_load_bitmap */
EIF_POINTER F1143_13518 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) LoadBitmap(((HINSTANCE) arg1), ((LPCTSTR) arg2));
	return Result;
}

/* {WEL_BITMAP}.cwin_copy_image */
EIF_POINTER F1143_13519 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CopyImage(((HANDLE) arg1), ((UINT) arg2), ((int) arg3), ((int) arg4), ((UINT) arg5));
	return Result;
}

/* {WEL_BITMAP}.cwin_create_bitmap */
EIF_POINTER F1143_13521 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3, EIF_INTEGER_32 arg4, EIF_POINTER arg5)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = (EIF_POINTER) CreateBitmap(((int) arg1), ((int) arg2), ((UINT) arg3), ((UINT) arg4), ((CONST VOID *) arg5));
	return Result;
}

/* {WEL_BITMAP}.cwin_create_dib_section */
EIF_POINTER F1143_13522 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32 arg3, EIF_POINTER* arg4, EIF_POINTER arg5, EIF_NATURAL_64 arg6)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1143_13522 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32) arg3, (EIF_POINTER*) arg4, (EIF_POINTER) arg5, (EIF_NATURAL_64) arg6);
	return Result;
}

/* {WEL_BITMAP}.cbm_init */
EIF_INTEGER_32 F1143_13523 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	
	Result = (EIF_INTEGER_32) CBM_INIT;
	return Result;
}

void EIF_Minit670 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
