
#ifndef _C14_we693_
#define _C14_we693_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1153_13675(EIF_REFERENCE);
extern void F1153_13677(EIF_REFERENCE, EIF_POINTER, EIF_POINTER, EIF_INTEGER_32*);
extern void EIF_Minit693(void);

#ifdef __cplusplus
}
#endif

#endif
