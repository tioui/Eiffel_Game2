/*
 * Code for class WEL_GDIP_GRAPHICS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we692.h"
#include "wel_gdi_plus.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1152_13652
static EIF_POINTER inline_F1152_13652 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	{
	static FARPROC GdipCreateFromHDC = NULL;
	GpGraphics *l_result = NULL;
	*(EIF_INTEGER *) arg3 = 1;
	
	if (!GdipCreateFromHDC) {
		GdipCreateFromHDC = GetProcAddress ((HMODULE) arg1, "GdipCreateFromHDC");
	}
	if (GdipCreateFromHDC) {
		*(EIF_INTEGER *) arg3 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (HDC, GpGraphics **)) GdipCreateFromHDC)
					((HDC) arg2,
					(GpGraphics **) &l_result);
	}
	return (EIF_POINTER) l_result;
}
	;
}
#define INLINE_F1152_13652
#endif
#ifndef INLINE_F1152_13661
static void inline_F1152_13661 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_INTEGER_32 arg10, EIF_INTEGER_32 arg11, EIF_INTEGER_32 arg12, EIF_POINTER arg13, EIF_POINTER arg14, EIF_POINTER arg15, EIF_INTEGER_32* arg16)
{
	{
	static FARPROC GdipDrawImageRectRectI = NULL;
	*(EIF_INTEGER *) arg16 = 1;
	
	if (!GdipDrawImageRectRectI) {
		GdipDrawImageRectRectI = GetProcAddress ((HMODULE) arg1, "GdipDrawImageRectRectI");
	}
	if (GdipDrawImageRectRectI) {
		*(EIF_INTEGER *) arg16 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpGraphics *, GpImage *, INT, INT, INT, INT, INT, INT, INT, INT, GpUnit, GDIPCONST GpImageAttributes*, DrawImageAbort, VOID *)) GdipDrawImageRectRectI)
					((GpGraphics *) arg2,
					(GpImage *) arg3,
					(INT) arg4,
					(INT) arg5,
					(INT) arg6,
					(INT) arg7,
					(INT) arg8,
					(INT) arg9,
					(INT) arg10,
					(INT) arg11,
					(GpUnit) arg12,
					(GDIPCONST GpImageAttributes*) arg13,
					(DrawImageAbort) arg14,
					(VOID *) arg15);
	}
}
	;
}
#define INLINE_F1152_13661
#endif
#ifndef INLINE_F1152_13663
static void inline_F1152_13663 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32* arg8)
{
	{
				static FARPROC GdipFillRectangleI = NULL;
				*(EIF_INTEGER *) arg8 = 1;

				if (!GdipFillRectangleI) {
					GdipFillRectangleI = GetProcAddress ((HMODULE) arg1, "GdipFillRectangleI");
				}
				if (GdipFillRectangleI) {
					*(EIF_INTEGER *) arg8 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpGraphics *, GpBrush *, INT, INT, INT, INT)) GdipFillRectangleI)
								((GpGraphics *) arg2,
								(GpBrush *) arg3,
								(INT) arg4,
								(INT) arg5,
								(INT) arg6,
								(INT) arg7);
				}
			}
	;
}
#define INLINE_F1152_13663
#endif
#ifndef INLINE_F1152_13667
static void inline_F1152_13667 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_64 arg3, EIF_INTEGER_32* arg4)
{
	{
				static FARPROC GdipGraphicsClear = NULL;
				*(EIF_INTEGER *) arg4 = 1;

				if (!GdipGraphicsClear) {
					GdipGraphicsClear = GetProcAddress ((HMODULE) arg1, "GdipGraphicsClear");
				}
				if (GdipGraphicsClear) {
					*(EIF_INTEGER *) arg4 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpGraphics *, ARGB)) GdipGraphicsClear)
								((GpGraphics *) arg2,
								(ARGB) arg3);
				}
			}
	;
}
#define INLINE_F1152_13667
#endif
#ifndef INLINE_F1152_13656
static void inline_F1152_13656 (EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	{
	static FARPROC GdipDeleteGraphics = NULL;
	*(EIF_INTEGER *) arg3 = 1;
	
	if (!GdipDeleteGraphics) {
		GdipDeleteGraphics = GetProcAddress ((HMODULE) arg1, "GdipDeleteGraphics");
	}
	
	if (GdipDeleteGraphics) {			
		*(EIF_INTEGER *) arg3 = (FUNCTION_CAST_TYPE (GpStatus, WINGDIPAPI, (GpGraphics *)) GdipDeleteGraphics)
					((GpGraphics *) arg2);
	}					
}
	;
}
#define INLINE_F1152_13656
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_GDIP_GRAPHICS}.make_from_dc */
void F1152_13628 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	F1150_13616(Current);
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
	tp1 = inline_F1152_13652(tp1, tp2, (EIF_INTEGER_32 *) &(loc1));
	*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {WEL_GDIP_GRAPHICS}.draw_image */
void F1152_13634 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_INTEGER_32 arg2, EIF_INTEGER_32 arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1201, 0x01).id, 1201, _OBJSIZ_0_1_0_0_0_1_0_0_);
	ti4_1 = F1160_13732(RTCW(arg1));
	ti4_2 = F1160_13733(RTCW(arg1));
	F1202_14800(RTCW(tr1), arg2, arg3, (EIF_INTEGER_32) (arg2 + ti4_1), (EIF_INTEGER_32) (arg3 + ti4_2));
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1201, 0x01).id, 1201, _OBJSIZ_0_1_0_0_0_1_0_0_);
	ti4_1 = F1160_13732(RTCW(arg1));
	ti4_2 = F1160_13733(RTCW(arg1));
	F1202_14800(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2);
	loc2 = (EIF_REFERENCE) tr1;
	F1152_13635(Current, arg1, loc1, loc2);
	F1130_13383(RTCW(loc1));
	F1130_13383(RTCW(loc2));
	RTLE;
}

/* {WEL_GDIP_GRAPHICS}.draw_image_with_dest_rect_src_rect */
void F1152_13635 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3)
{
	GTCX
	
	
	F1152_13636(Current, arg1, arg2, arg3, ((EIF_INTEGER_32) 2L), NULL);
}

/* {WEL_GDIP_GRAPHICS}.draw_image_with_src_rect_dest_rect_unit_attributes */
void F1152_13636 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2, EIF_REFERENCE arg3, EIF_INTEGER_32 arg4, EIF_REFERENCE arg5)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER loc2 = (EIF_POINTER) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_POINTER tp4;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	EIF_INTEGER_32 ti4_5;
	EIF_INTEGER_32 ti4_6;
	EIF_INTEGER_32 ti4_7;
	EIF_INTEGER_32 ti4_8;
	RTLD;
	
	RTLI(5);
	RTLR(0,arg5);
	RTLR(1,Current);
	RTLR(2,arg1);
	RTLR(3,arg2);
	RTLR(4,arg3);
	RTLIU(5);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg5 == NULL)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_1_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
		tp3 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
		ti4_1 = F1202_14806(RTCW(arg2));
		ti4_2 = F1202_14808(RTCW(arg2));
		ti4_3 = F1202_14811(RTCW(arg2));
		ti4_4 = F1202_14812(RTCW(arg2));
		ti4_5 = F1202_14806(RTCW(arg3));
		ti4_6 = F1202_14808(RTCW(arg3));
		ti4_7 = F1202_14811(RTCW(arg3));
		ti4_8 = F1202_14812(RTCW(arg3));
		inline_F1152_13661(tp1, tp2, tp3, ti4_1, ti4_2, ti4_3, ti4_4, ti4_5, ti4_6, ti4_7, ti4_8, arg4, loc2, loc2, loc2, (EIF_INTEGER_32 *) &(loc1));
	} else {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_1_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
		tp3 = *(EIF_POINTER *)(RTCW(arg1) + O11797[Dtype(arg1)-1129]);
		ti4_1 = F1202_14806(RTCW(arg2));
		ti4_2 = F1202_14808(RTCW(arg2));
		ti4_3 = F1202_14811(RTCW(arg2));
		ti4_4 = F1202_14812(RTCW(arg2));
		ti4_5 = F1202_14806(RTCW(arg3));
		ti4_6 = F1202_14808(RTCW(arg3));
		ti4_7 = F1202_14811(RTCW(arg3));
		ti4_8 = F1202_14812(RTCW(arg3));
		tp4 = *(EIF_POINTER *)(RTCW(arg5)+ _PTROFF_0_1_0_0_0_0_);
		inline_F1152_13661(tp1, tp2, tp3, ti4_1, ti4_2, ti4_3, ti4_4, ti4_5, ti4_6, ti4_7, ti4_8, arg4, tp4, loc2, loc2, (EIF_INTEGER_32 *) &(loc1));
	}
	RTLE;
}

/* {WEL_GDIP_GRAPHICS}.fill_rectangle */
void F1152_13639 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_REFERENCE arg2)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_POINTER tp3;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_INTEGER_32 ti4_3;
	EIF_INTEGER_32 ti4_4;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,arg2);
	RTLIU(3);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	tp3 = *(EIF_POINTER *)(RTCW(arg1)+ _PTROFF_0_1_0_0_0_0_);
	ti4_1 = F52_1125(RTCW(arg2));
	ti4_2 = F52_1126(RTCW(arg2));
	ti4_3 = F52_1127(RTCW(arg2));
	ti4_4 = F52_1128(RTCW(arg2));
	inline_F1152_13663(tp1, tp2, tp3, ti4_1, ti4_2, ti4_3, ti4_4, (EIF_INTEGER_32 *) &(loc1));
	RTLE;
}

/* {WEL_GDIP_GRAPHICS}.clear */
void F1152_13643 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	EIF_INTEGER_64 ti8_1;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLIU(2);
	
	RTGC;
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_1_);
	tp2 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
	ti8_1 = *(EIF_INTEGER_64 *)(RTCW(arg1)+ _I64OFF_0_0_0_0_0_0_0_);
	inline_F1152_13667(tp1, tp2, ti8_1, (EIF_INTEGER_32 *) &(loc1));
	RTLE;
}

/* {WEL_GDIP_GRAPHICS}.destroy_item */
void F1152_13650 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_POINTER tp1;
	EIF_POINTER tp2;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	{
		/* INLINED CODE (default_pointer) */
		tp1 = (EIF_POINTER)  0;
		/* END INLINED CODE */
	}
	if ((EIF_BOOLEAN)(*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_) != tp1)) {
		tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_1_);
		tp2 = *(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_);
		inline_F1152_13656(tp1, tp2, (EIF_INTEGER_32 *) &(loc1));
		{
			/* INLINED CODE (default_pointer) */
			tp1 = (EIF_POINTER)  0;
			/* END INLINED CODE */
		}
		tp2 = tp1;
		*(EIF_POINTER *)(Current+ _PTROFF_0_1_0_0_0_0_) = (EIF_POINTER) tp2;
	}
	RTLE;
}

/* {WEL_GDIP_GRAPHICS}.c_gdip_create_from_hdc */
EIF_POINTER F1152_13652 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1152_13652 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3);
	return Result;
}

/* {WEL_GDIP_GRAPHICS}.c_gdip_delete_graphics */
void F1152_13656 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_32* arg3)
{
	GTCX
	
	
	inline_F1152_13656 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_32*) arg3);
}

/* {WEL_GDIP_GRAPHICS}.c_gdip_draw_image_rect_rect_i */
void F1152_13661 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32 arg8, EIF_INTEGER_32 arg9, EIF_INTEGER_32 arg10, EIF_INTEGER_32 arg11, EIF_INTEGER_32 arg12, EIF_POINTER arg13, EIF_POINTER arg14, EIF_POINTER arg15, EIF_INTEGER_32* arg16)
{
	GTCX
	
	
	inline_F1152_13661 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5, (EIF_INTEGER_32) arg6, (EIF_INTEGER_32) arg7, (EIF_INTEGER_32) arg8, (EIF_INTEGER_32) arg9, (EIF_INTEGER_32) arg10, (EIF_INTEGER_32) arg11, (EIF_INTEGER_32) arg12, (EIF_POINTER) arg13, (EIF_POINTER) arg14, (EIF_POINTER) arg15, (EIF_INTEGER_32*) arg16);
}

/* {WEL_GDIP_GRAPHICS}.c_gdip_fill_rectangle_i */
void F1152_13663 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_INTEGER_32 arg4, EIF_INTEGER_32 arg5, EIF_INTEGER_32 arg6, EIF_INTEGER_32 arg7, EIF_INTEGER_32* arg8)
{
	GTCX
	
	
	inline_F1152_13663 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_POINTER) arg3, (EIF_INTEGER_32) arg4, (EIF_INTEGER_32) arg5, (EIF_INTEGER_32) arg6, (EIF_INTEGER_32) arg7, (EIF_INTEGER_32*) arg8);
}

/* {WEL_GDIP_GRAPHICS}.c_gdip_clear */
void F1152_13667 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2, EIF_INTEGER_64 arg3, EIF_INTEGER_32* arg4)
{
	GTCX
	
	
	inline_F1152_13667 ((EIF_POINTER) arg1, (EIF_POINTER) arg2, (EIF_INTEGER_64) arg3, (EIF_INTEGER_32*) arg4);
}

void EIF_Minit692 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
