/*
 * Code for class EV_IMAGE_LIST_IMP
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev663.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_IMAGE_LIST_IMP}.make_with_size */
void F1136_13451 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTCFDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	F1135_13414(Current, arg1, arg2, ((EIF_INTEGER_32) 32L), (EIF_BOOLEAN) 1);
	F1136_13452(Current);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1047,0xFF01,0xFFF9,2,1336,1366,1366,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1048_11377(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_3_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1048,1366,0xFF01,1288,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1049_11377(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1049,1366,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1050_11377(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_1_) = (EIF_REFERENCE) tr1;
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1049,1366,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(dftype, typarr0)));
		tr1 = RTLNSMART(typres0.id);
	}
	F1050_11377(RTCW(tr1), ((EIF_INTEGER_32) 4L));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + _REFACS_2_) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.add_transparent_pixmap */
void F1136_13452 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLR(2,loc1);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLR(5,loc4);
	RTLR(6,loc5);
	RTLIU(7);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_6_2_0_3_0_7_0_0_);
	F1444_18829(RTCW(tr1));
	loc3 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1142, 0x01).id, 1142, _OBJSIZ_0_3_0_3_0_2_0_0_);
	F1143_13501(RTCW(tr1), loc3, ((EIF_INTEGER_32) 16L), ((EIF_INTEGER_32) 16L));
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1142, 0x01).id, 1142, _OBJSIZ_0_3_0_3_0_2_0_0_);
	F1143_13501(RTCW(tr1), loc3, ((EIF_INTEGER_32) 16L), ((EIF_INTEGER_32) 16L));
	loc2 = (EIF_REFERENCE) tr1;
	F1443_18676(RTCW(loc3), loc1);
	ti4_1 = ((EIF_INTEGER_32) 16711778L);
	F1443_18728(RTCW(loc3), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 16L), ((EIF_INTEGER_32) 16L), ti4_1);
	F1443_18682(RTCW(loc3));
	tr1 = RTLNS(eif_new_type(1175, 0x01).id, 1175, _OBJSIZ_2_2_0_2_0_1_0_0_);
	F1162_13788(RTCW(tr1));
	loc4 = (EIF_REFERENCE) tr1;
	F1176_14179(RTCW(loc4), loc2);
	F1176_14178(RTCW(loc4), loc1);
	F1176_14180(RTCW(loc4), (EIF_BOOLEAN) 1);
	tr1 = RTLNS(eif_new_type(1146, 0x01).id, 1146, _OBJSIZ_0_2_0_3_0_1_0_0_);
	F1146_13558(RTCW(tr1), loc4);
	loc5 = (EIF_REFERENCE) tr1;
	F1135_13425(Current, loc5);
	F1176_14188(RTCW(loc4));
	F773_11167(RTCW(loc1));
	F773_11167(RTCW(loc2));
	F773_11167(RTCW(loc3));
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.pixmap_position */
void F1136_13453 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg1);
	RTLR(3,loc2);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1799, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_40_);
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tb2 = F1049_11383(RTCW(tr1), loc2);
			tb1 = tb2;
		}
		if (tb1) {
			tr1 = *(EIF_REFERENCE *)(Current);
			ti4_1 = F1049_11381(RTCW(tr1), loc2);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ti4_1;
		} else {
			tb1 = '\0';
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_41_12_6_3_);
			if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 0L))) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_41_12_6_3_);
				tb2 = F1050_11383(RTCW(tr1), ti4_1);
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_41_12_6_3_);
				ti4_1 = F1050_11381(RTCW(tr1), ti4_1);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ti4_1;
			}
		}
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) == ((EIF_INTEGER_32) -1L))) {
		F1136_13457(Current, arg1);
	}
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.add_pixmap */
void F1136_13454 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 loc4 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1799, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_40_);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current);
			tb1 = F1049_11383(RTCW(tr1), loc2);
			if (tb1) {
				tr1 = *(EIF_REFERENCE *)(Current);
				ti4_1 = F1049_11381(RTCW(tr1), loc2);
				*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ti4_1;
			} else {
				loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_35_);
				if ((EIF_BOOLEAN)(loc3 != NULL)) {
					loc4 = F773_11162(RTCW(loc3));
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					tb1 = F1050_11383(RTCW(tr1), loc4);
					if (tb1) {
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = F1050_11381(RTCW(tr1), loc4);
						*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ti4_1;
					} else {
						F1136_13456(Current, arg1);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
						F1050_11422(RTCW(tr1), ti4_1, loc4);
						tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
						F1050_11422(RTCW(tr1), loc4, ti4_1);
						tr1 = *(EIF_REFERENCE *)(Current);
						ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
						F1049_11422(RTCW(tr1), ti4_1, loc2);
					}
				} else {
					F1136_13456(Current, arg1);
					tr1 = *(EIF_REFERENCE *)(Current);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
					F1049_11422(RTCW(tr1), ti4_1, loc2);
				}
			}
		} else {
			ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_41_12_6_3_);
			if ((EIF_BOOLEAN) (ti4_1 >= ((EIF_INTEGER_32) 0L))) {
				loc4 = *(EIF_INTEGER_32 *)(RTCW(loc1)+ _LNGOFF_41_12_6_3_);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				tb1 = F1050_11383(RTCW(tr1), loc4);
				if (tb1) {
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = F1050_11381(RTCW(tr1), loc4);
					*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ti4_1;
				} else {
					F1136_13456(Current, arg1);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
					F1050_11422(RTCW(tr1), ti4_1, loc4);
					tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
					ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
					F1050_11422(RTCW(tr1), loc4, ti4_1);
				}
			} else {
				F1136_13456(Current, arg1);
			}
		}
	} else {
		F1136_13456(Current, arg1);
	}
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.extend_pixmap */
void F1136_13455 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,loc2);
	RTLR(3,Current);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc1 = RTRV(eif_new_type(1799, 0x00), loc1);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_40_);
	}
	F1136_13458(Current, arg1);
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		tr1 = *(EIF_REFERENCE *)(Current);
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
		F1049_11422(RTCW(tr1), ti4_1, loc2);
	} else {
		if ((EIF_BOOLEAN)(loc1 != NULL)) {
			loc3 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_35_);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_1_);
				ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
				ti4_2 = F773_11162(RTCW(loc3));
				F1050_11422(RTCW(tr1), ti4_1, ti4_2);
				tr1 = *(EIF_REFERENCE *)(Current + _REFACS_2_);
				ti4_1 = F773_11162(RTCW(loc3));
				ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
				F1050_11422(RTCW(tr1), ti4_1, ti4_2);
			}
		}
	}
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.internal_add_pixmap */
void F1136_13456 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLR(6,loc3);
	RTLIU(7);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc5 = RTRV(eif_new_type(400, 0x00), loc5);
	RTCT0(NULL, EX_CHECK);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8197[Dtype(loc5)-1799])(RTCW(loc5));
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8198[Dtype(loc5)-1799])(RTCW(loc5));
	}
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = F401_8447(RTCW(loc5));
		F773_11163(RTCW(loc2));
	} else {
		F773_11165(RTCW(loc2));
	}
	loc1 = F773_11162(RTCW(loc2));
	tb1 = '\01';
	if (!(EIF_BOOLEAN)(loc1 == ((EIF_INTEGER_32) 0L))) {
		tb2 = F1048_11383(RTCW(loc4), loc1);
		tb1 = (EIF_BOOLEAN) !tb2;
	}
	if (tb1) {
		F1135_13425(Current, loc2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1336,1366,1366,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ((EIF_INTEGER_32) 1L);
		F1048_11422(RTCW(loc4), tr1, loc1);
	} else {
		loc3 = F1048_11381(RTCW(loc4), loc1);
		RTCT0(NULL, EX_CHECK);
		if ((EIF_BOOLEAN)(loc3 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		ti4_1 = eif_integer_32_item(RTCW(loc3),1);
		*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ti4_1;
	}
	F773_11164(RTCW(loc2));
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.internal_pixmap_position */
void F1136_13457 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc5);
	RTLR(1,arg1);
	RTLR(2,loc4);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,loc3);
	RTLIU(6);
	
	RTGC;
	loc5 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc5 = RTRV(eif_new_type(400, 0x00), loc5);
	RTCT0(NULL, EX_CHECK);
	if ((EIF_BOOLEAN)(loc5 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc4 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8197[Dtype(loc5)-1799])(RTCW(loc5));
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8198[Dtype(loc5)-1799])(RTCW(loc5));
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc1 = F773_11162(RTCW(loc2));
		tb1 = '\0';
		if ((EIF_BOOLEAN)(loc1 != ((EIF_INTEGER_32) 0L))) {
			tb2 = F1048_11383(RTCW(loc4), loc1);
			tb1 = tb2;
		}
		if (tb1) {
			loc3 = F1048_11381(RTCW(loc4), loc1);
			RTCT0(NULL, EX_CHECK);
			if ((EIF_BOOLEAN)(loc3 != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			ti4_1 = eif_integer_32_item(RTCW(loc3),1);
			*(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_) = (EIF_INTEGER_32) ti4_1;
		}
	}
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.internal_extend_pixmap */
void F1136_13458 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(6);
	RTLR(0,loc4);
	RTLR(1,arg1);
	RTLR(2,loc3);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLR(5,tr1);
	RTLIU(6);
	
	RTGC;
	loc4 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc4 = RTRV(eif_new_type(400, 0x00), loc4);
	RTCT0(NULL, EX_CHECK);
	if ((EIF_BOOLEAN)(loc4 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	loc3 = *(EIF_REFERENCE *)(Current + _REFACS_3_);
	loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8197[Dtype(loc4)-1799])(RTCW(loc4));
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8198[Dtype(loc4)-1799])(RTCW(loc4));
		loc2 = RTRV(eif_new_type(1145, 0x00), loc2);
	}
	if ((EIF_BOOLEAN)(loc2 != NULL)) {
		loc1 = F773_11162(RTCW(loc2));
		F1135_13425(Current, loc2);
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,2,1336,1366,1366,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 3, 1);
		}
		ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_3_);
		((EIF_TYPED_VALUE *)tr1+1)->it_i4 = ti4_1;
		((EIF_TYPED_VALUE *)tr1+2)->it_i4 = ((EIF_INTEGER_32) 1L);
		F1048_11422(RTCW(loc3), tr1, loc1);
	} else {
		F1136_13459(Current, arg1);
	}
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.add_pixmap_bitmap */
void F1136_13459 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc4 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc5 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc6 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc7 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(10);
	RTLR(0,loc2);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLR(3,loc1);
	RTLR(4,tr1);
	RTLR(5,loc3);
	RTLR(6,loc4);
	RTLR(7,loc5);
	RTLR(8,loc7);
	RTLR(9,loc6);
	RTLIU(10);
	
	RTGC;
	loc2 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_3_);
	loc2 = RTRV(eif_new_type(400, 0x00), loc2);
	if ((EIF_BOOLEAN)(loc2 == NULL)) {
		RTCT0(NULL, EX_CHECK);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
	}
	tb1 = '\01';
	ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8211[Dtype(loc2)-1799])(RTCW(loc2));
	if (!((EIF_BOOLEAN)(ti4_1 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_5_)))) {
		ti4_1 = (FUNCTION_CAST(EIF_INTEGER_32, (EIF_REFERENCE)) R8210[Dtype(loc2)-1799])(RTCW(loc2));
		tb1 = (EIF_BOOLEAN)(ti4_1 != *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_4_));
	}
	if (tb1) {
		tr1 = RTLNS(eif_new_type(1544, 0x01).id, 1544, _OBJSIZ_6_3_0_1_0_0_0_0_);
		F1479_19077(RTCW(tr1));
		loc1 = (EIF_REFERENCE) tr1;
		(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R18[Dtype(loc1)-0])(RTCW(loc1), arg1);
		F1545_20820(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_4_), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_4_3_0_5_));
		loc2 = *(EIF_REFERENCE *)(RTCW(loc1) + _REFACS_3_);
		loc2 = RTRV(eif_new_type(400, 0x00), loc2);
		RTCT0(NULL, EX_CHECK);
		if ((EIF_BOOLEAN)(loc2 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
	}
	loc3 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8195[Dtype(loc2)-1799])(RTCW(loc2));
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R8199[Dtype(loc2)-1799])(RTCW(loc2));
	if (tb1) {
		loc4 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8196[Dtype(loc2)-1799])(RTCW(loc2));
		RTCT0(NULL, EX_CHECK);
		if ((EIF_BOOLEAN)(loc4 != NULL)) {
			RTCK0;
		} else {
			RTCF0;
		}
		tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_6_2_0_3_0_7_0_0_);
		F1444_18829(RTCW(tr1));
		loc5 = (EIF_REFERENCE) tr1;
		F1443_18676(RTCW(loc5), loc4);
		tr1 = RTLNS(eif_new_type(1443, 0x01).id, 1443, _OBJSIZ_6_2_0_3_0_7_0_0_);
		F1444_18830(RTCW(tr1), loc5);
		loc7 = (EIF_REFERENCE) tr1;
		tr1 = RTLNS(eif_new_type(1142, 0x01).id, 1142, _OBJSIZ_0_3_0_3_0_2_0_0_);
		ti4_1 = F1143_13507(RTCW(loc4));
		ti4_2 = F1143_13508(RTCW(loc4));
		F1143_13501(RTCW(tr1), loc7, ti4_1, ti4_2);
		loc6 = (EIF_REFERENCE) tr1;
		F773_11163(RTCW(loc6));
		F1443_18676(RTCW(loc7), loc6);
		ti4_1 = F1143_13507(RTCW(loc4));
		ti4_2 = F1143_13508(RTCW(loc4));
		F1443_18728(RTCW(loc7), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2, ((EIF_INTEGER_32) 16711778L));
		ti4_1 = F1143_13507(RTCW(loc4));
		ti4_2 = F1143_13508(RTCW(loc4));
		F1443_18722(RTCW(loc7), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ti4_1, ti4_2, loc5, ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 6684742L));
		F1443_18682(RTCW(loc5));
		F773_11167(RTCW(loc5));
		F1443_18682(RTCW(loc7));
		F773_11167(RTCW(loc7));
		F1135_13422(Current, loc3, loc6);
		F773_11164(RTCW(loc6));
		F773_11164(RTCW(loc4));
		loc4 = (EIF_REFERENCE) NULL;
	} else {
		F1135_13420(Current, loc3);
	}
	F773_11164(RTCW(loc3));
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		F1479_19080(RTCW(loc1));
		loc1 = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {EV_IMAGE_LIST_IMP}.filenames_index */
EIF_REFERENCE F1136_13460 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


/* {EV_IMAGE_LIST_IMP}.bitmap_ids_index */
EIF_REFERENCE F1136_13461 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_1_);
}


/* {EV_IMAGE_LIST_IMP}.image_id_to_bitmap_id_index */
EIF_REFERENCE F1136_13462 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_2_);
}


/* {EV_IMAGE_LIST_IMP}.image_list_info */
EIF_REFERENCE F1136_13463 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_3_);
}


/* {EV_IMAGE_LIST_IMP}.raster_constants */
static EIF_REFERENCE F1136_13464_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (13464);
#define Result RTOSR(13464)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(208, 0x01).id, 208, _OBJSIZ_0_0_0_0_0_0_0_0_);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (13464);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1136_13464 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(13464,F1136_13464_body,(Current));
}

void EIF_Minit663 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
