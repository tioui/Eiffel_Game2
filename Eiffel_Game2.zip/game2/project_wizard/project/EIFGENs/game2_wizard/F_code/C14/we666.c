/*
 * Code for class WEL_RICH_EDIT_DLL
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we666.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_RICH_EDIT_DLL}.make */
void F1139_13476 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	tr1 = RTOSCF(13477,F1139_13477,(Current));
	F1137_13466(Current, tr1);
	RTLE;
}

/* {WEL_RICH_EDIT_DLL}.rich_edit_dll_name */

EIF_REFERENCE F1139_13477 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (13477,RTMS_EX_H("riched32.dll",12,172585836));
}

void EIF_Minit666 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
