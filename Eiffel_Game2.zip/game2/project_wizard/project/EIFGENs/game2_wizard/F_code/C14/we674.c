/*
 * Code for class WEL_ICON
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we674.h"
#include <wel.h>
#include <winuser.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef INLINE_F1147_13573
static EIF_POINTER inline_F1147_13573 (EIF_POINTER arg1, EIF_POINTER arg2)
{
	return LoadImage((HINSTANCE)arg1, MAKEINTRESOURCE(arg2), IMAGE_ICON, 0, 0, LR_SHARED | LR_DEFAULTSIZE);
	;
}
#define INLINE_F1147_13573
#endif

#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_ICON}.load_item */
void F1147_13571 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER tp1;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tp1 = inline_F1147_13573(arg1, arg2);
	*(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_) = (EIF_POINTER) tp1;
	RTLE;
}

/* {WEL_ICON}.destroy_resource */
EIF_BOOLEAN F1147_13572 (EIF_REFERENCE Current)
{
	GTCX
	EIF_POINTER tp1;
	
	
	tp1 = *(EIF_POINTER *)(Current+ _PTROFF_0_2_0_3_0_0_);
	return (EIF_BOOLEAN) (EIF_BOOLEAN) EIF_TEST(DestroyIcon(((HICON) tp1)));
}

/* {WEL_ICON}.cwin_load_icon_image */
EIF_POINTER F1147_13573 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER Result = ((EIF_POINTER) 0);
	
	
	
	Result = inline_F1147_13573 ((EIF_POINTER) arg1, (EIF_POINTER) arg2);
	return Result;
}

/* {WEL_ICON}.cwin_destroy_icon */
EIF_BOOLEAN F1147_13574 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	
	
	Result = (EIF_BOOLEAN) EIF_TEST(DestroyIcon(((HICON) arg1)));
	return Result;
}

void EIF_Minit674 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
