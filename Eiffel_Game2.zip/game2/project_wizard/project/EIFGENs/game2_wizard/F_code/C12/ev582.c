/*
 * Code for class EV_SHARED_APPLICATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev582.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_SHARED_APPLICATION}.ev_application */
EIF_REFERENCE F1091_11888 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0(NULL, EX_CHECK);
	tr1 = F1488_19323(RTCV(RTOSCF(11891,F1091_11891,(Current))));
	loc1 = tr1;
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {EV_SHARED_APPLICATION}.shared_environment */
static EIF_REFERENCE F1091_11891_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (11891);
#define Result RTOSR(11891)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1487, 0x01).id, 1487, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1479_19077(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (11891);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1091_11891 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11891,F1091_11891_body,(Current));
}

void EIF_Minit582 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
