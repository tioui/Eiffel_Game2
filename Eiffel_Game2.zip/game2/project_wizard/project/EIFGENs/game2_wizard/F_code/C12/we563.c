/*
 * Code for class WEL_WINDOWS_VERSION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we563.h"
#include "windows.h"
#include "wel_dynload.h"
#include "eif_misc.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_WINDOWS_VERSION}.is_windows_95 */
EIF_BOOLEAN F1042_11240 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\0';
	tb1 = '\0';
	if (F1042_11247(Current)) {
		tb1 = (EIF_BOOLEAN)(F1042_11254(Current) == ((EIF_INTEGER_32) 4L));
	}
	if (tb1) {
		Result = (EIF_BOOLEAN) (F1042_11255(Current) < ((EIF_INTEGER_32) 10L));
	}
	RTLE;
	return Result;
}

/* {WEL_WINDOWS_VERSION}.is_windows_9x */
EIF_BOOLEAN F1042_11247 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = RTOSCF(11270,F1042_11270,(Current));
	ti4_1 = eif_bit_and(ti4_1,(EIF_INTEGER_32) ((EIF_INTEGER_64) RTI64C(2147483648)));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 != ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {WEL_WINDOWS_VERSION}.is_windows_nt */
EIF_BOOLEAN F1042_11248 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = RTOSCF(11270,F1042_11270,(Current));
	ti4_1 = eif_bit_and(ti4_1,(EIF_INTEGER_32) ((EIF_INTEGER_64) RTI64C(2147483648)));
	Result = (EIF_BOOLEAN) (EIF_BOOLEAN)(ti4_1 == ((EIF_INTEGER_32) 0L));
	RTLE;
	return Result;
}

/* {WEL_WINDOWS_VERSION}.is_windows_xp_compatible */
EIF_BOOLEAN F1042_11253 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	Result = '\01';
	tb1 = '\0';
	if (F1042_11248(Current)) {
		tb2 = '\0';
		if ((EIF_BOOLEAN)(F1042_11254(Current) == ((EIF_INTEGER_32) 5L))) {
			tb2 = (EIF_BOOLEAN) (F1042_11255(Current) >= ((EIF_INTEGER_32) 1L));
		}
		tb1 = tb2;
	}
	if (!tb1) {
		Result = (EIF_BOOLEAN) (F1042_11254(Current) > ((EIF_INTEGER_32) 5L));
	}
	RTLE;
	return Result;
}

/* {WEL_WINDOWS_VERSION}.major_version */
EIF_INTEGER_32 F1042_11254 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = RTOSCF(11270,F1042_11270,(Current));
	Result = eif_bit_and(ti4_1,((EIF_INTEGER_32) 255L));
	Result = (EIF_INTEGER_32) Result;
	RTLE;
	return Result;
}

/* {WEL_WINDOWS_VERSION}.minor_version */
EIF_INTEGER_32 F1042_11255 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	ti4_1 = RTOSCF(11270,F1042_11270,(Current));
	ti4_1 = eif_bit_and(ti4_1,((EIF_INTEGER_32) 65280L));
	Result = eif_bit_shift_right((ti4_1),((EIF_INTEGER_32) 8L));
	RTLE;
	return Result;
}

/* {WEL_WINDOWS_VERSION}.comctl32_version */
static EIF_INTEGER_32 F1042_11259_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (11259);
#define Result RTOSR(11259)
	Result = (EIF_INTEGER_32) cwin_get_comctl32dll_version();
	RTOSE (11259);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1042_11259 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11259,F1042_11259_body,(Current));
}

/* {WEL_WINDOWS_VERSION}.shell32_version */
static EIF_INTEGER_32 F1042_11260_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (11260);
#define Result RTOSR(11260)
	Result = (EIF_INTEGER_32) cwin_get_shell32dll_version();
	RTOSE (11260);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1042_11260 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11260,F1042_11260_body,(Current));
}

/* {WEL_WINDOWS_VERSION}.internal_version */
static EIF_INTEGER_32 F1042_11270_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (11270);
#define Result RTOSR(11270)
	Result = (EIF_INTEGER_32) GetVersion();
	RTOSE (11270);
	RTEE;
	return Result;
#undef Result
}

EIF_INTEGER_32 F1042_11270 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11270,F1042_11270_body,(Current));
}

/* {WEL_WINDOWS_VERSION}.cwin_get_version */
EIF_INTEGER_32 F1042_11271 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) GetVersion();
	
	return Result;
}

/* {WEL_WINDOWS_VERSION}.cwin_get_shell32dll_version */
EIF_INTEGER_32 F1042_11274 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) cwin_get_shell32dll_version();
	
	return Result;
}

/* {WEL_WINDOWS_VERSION}.cwin_get_comctl32dll_version */
EIF_INTEGER_32 F1042_11275 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) cwin_get_comctl32dll_version();
	
	return Result;
}

void EIF_Minit563 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
