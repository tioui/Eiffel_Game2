
#ifndef _C12_ar560_
#define _C12_ar560_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1035_11204(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit560(void);

#ifdef __cplusplus
}
#endif

#endif
