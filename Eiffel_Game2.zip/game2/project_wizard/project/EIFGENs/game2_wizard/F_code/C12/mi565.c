/*
 * Code for class MISMATCH_CORRECTOR
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi565.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_CORRECTOR}.correct_mismatch */
void F1044_11290 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,loc2);
	RTLR(4,Current);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1423, 0x01).id, 1423, _OBJSIZ_1_1_0_3_0_0_0_0_);
	tr2 = RTMS_EX_H("Mismatch: ",10,1538098208);
	F1421_17564(RTCW(tr1), tr2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(356, 0x01).id, 356, _OBJSIZ_0_0_0_0_0_0_0_0_);
	loc2 = (EIF_REFERENCE) tr1;
	tr1 = F1_5(Current);
	tr1 = F1290_15689(RTCW(tr1));
	F1424_17760(RTCW(loc1), tr1);
	F357_8167(RTCW(loc2), loc1);
	RTLE;
}

/* {MISMATCH_CORRECTOR}.mismatch_information */
static EIF_REFERENCE F1044_11291_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(1);
	RTLR(0,tr1);
	RTLIU(1);
	
	RTEV;
	RTGC;
	RTOSP (11291);
#define Result RTOSR(11291)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1052, 0x01).id, 1052, _OBJSIZ_9_3_0_7_0_0_0_0_);
	F1053_11501(RTCW(tr1));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (11291);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1044_11291 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11291,F1044_11291_body,(Current));
}

void EIF_Minit565 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
