
#ifndef _C12_we554_
#define _C12_we554_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F773_11162(EIF_REFERENCE);
extern void F773_11163(EIF_REFERENCE);
extern void F773_11164(EIF_REFERENCE);
extern void F773_11165(EIF_REFERENCE);
extern void F773_11166(EIF_REFERENCE);
extern void F773_11167(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,11171)
static EIF_REFERENCE F773_11171_body(EIF_REFERENCE);
extern EIF_REFERENCE F773_11171(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,11172)
static EIF_REFERENCE F773_11172_body(EIF_REFERENCE);
extern EIF_REFERENCE F773_11172(EIF_REFERENCE);
extern void EIF_Minit554(void);
extern void F1059_11529(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F772_11156(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F1130_13378(EIF_REFERENCE);
extern void F697_9148(EIF_REFERENCE, EIF_INTEGER_32);
extern char *(*R10119[])();
extern char *(*R8692[])();
extern long O10109[];
extern long O10112[];
extern long O10120[];
extern long O10121[];
extern long O11798[];

#ifdef __cplusplus
}
#endif

#endif
