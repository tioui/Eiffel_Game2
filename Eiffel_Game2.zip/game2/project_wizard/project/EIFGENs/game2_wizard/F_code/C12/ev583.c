/*
 * Code for class EV_PND_ACTION_SEQUENCE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev583.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_PND_ACTION_SEQUENCE}.call */
void F1093_11893 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE tr3 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTLD;
	
	RTLI(7);
	RTLR(0,arg1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,tr2);
	RTLR(4,loc1);
	RTLR(5,loc2);
	RTLR(6,tr3);
	RTLIU(7);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != NULL)) {
		switch (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_10_2_0_1_)) {
			case 1L:
				tr1 = eif_boxed_item(arg1,1);
				tr2 = RTCCL(tr1);
				if (F1093_11898(Current, tr2)) {
					{
						static EIF_TYPE_INDEX typarr0[] = {0xFF01,1056,0xFF01,1413,0xFFF9,1,1336,0xFF01,0,0xFFFF};
						EIF_TYPE typres0;
						static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
						
						typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
						tr1 = RTLNS(typres0.id, 1056, _OBJSIZ_1_1_0_1_0_0_0_0_);
					}
					ti4_1 = F1057_11549(Current);
					F1057_11529(RTCW(tr1), ti4_1);
					loc1 = (EIF_REFERENCE) tr1;
					(FUNCTION_CAST(void, (EIF_REFERENCE, EIF_REFERENCE)) R8456[Dtype(loc1)-510])(RTCW(loc1), Current);
					tr1 = F1082_11686(Current);
					F1014_10767(RTCW(tr1), (EIF_BOOLEAN) 0);
					F1057_11559(RTCW(loc1));
					for (;;) {
						tb1 = '\01';
						ti4_1 = *(EIF_INTEGER_32 *)(RTCW(loc1) + O10416[Dtype(loc1)-1056]);
						ti4_2 = F1057_11549(RTCW(loc1));
						if (!(EIF_BOOLEAN) (ti4_1 > ti4_2)) {
							tb2 = F1014_10765(RTCV(F1082_11686(Current)));
							tb1 = tb2;
						}
						if (tb1) break;
						tr1 = F1057_11533(RTCW(loc1));
						tb2 = F1413_16857(RTCW(tr1), arg1);
						if (tb2) {
							loc2 = F1057_11533(RTCW(loc1));
							loc2 = F1413_16854(RTCW(loc2));
							tr1 = eif_boxed_item(arg1,1);
							tr2 = RTCCL(tr1);
							
							eif_put_reference_item(RTCW(loc2),1,tr2);
							tr3 = F1057_11533(RTCW(loc1));
							(FUNCTION_CAST(void, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(RTCW(tr3)+ _PTROFF_4_2_0_3_0_2_))(
								*(EIF_POINTER *)(RTCW(tr3)+ _PTROFF_4_2_0_3_0_1_),
								*(EIF_REFERENCE *)(RTCW(tr3) + _REFACS_1_), loc2);
							;
						}
						F1057_11561(RTCW(loc1));
					}
					F1014_10769(RTCV(F1082_11686(Current)));
				}
				break;
			case 2L:
				tr3 = F1082_11688(Current);
				F1011_10738(RTCW(tr3), arg1);
				break;
			case 3L:
				break;
			default:
				RTEC(EN_WHEN);
		}
	}
	RTLE;
}

/* {EV_PND_ACTION_SEQUENCE}.accepts_pebble */
EIF_BOOLEAN F1093_11895 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,arg1);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTCCL(arg1);
	if (F1093_11898(Current, tr1)) {
		{
			static EIF_TYPE_INDEX typarr0[] = {0xFF01,0xFFF9,1,1336,0xFF01,0,0xFFFF};
			EIF_TYPE typres0;
			static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
			
			typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
			tr1 = RTLNTS(typres0.id, 2, 0);
		}
		((EIF_TYPED_VALUE *)tr1+1)->it_r = arg1;
		RTAR(tr1,arg1);
		loc2 = (EIF_REFERENCE) tr1;
		loc1 = F1057_11539(Current);
		F1057_11559(Current);
		for (;;) {
			tb1 = '\01';
			if (!Result) {
				tb1 = F978_10509(Current);
			}
			if (tb1) break;
			tr1 = F1057_11533(Current);
			Result = F1413_16857(RTCW(tr1), loc2);
			F1057_11561(Current);
		}
		F1057_11564(Current, loc1);
	}
	RTLE;
	return Result;
}

/* {EV_PND_ACTION_SEQUENCE}.veto_pebble_function */
EIF_REFERENCE F1093_11896 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_9_);
}


/* {EV_PND_ACTION_SEQUENCE}.veto_pebble_function_result */
EIF_BOOLEAN F1093_11898 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN Result = ((EIF_BOOLEAN) 0);
	
	RTCFDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc2);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,loc1);
	RTLR(4,arg1);
	RTLIU(5);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(Current + _REFACS_9_);
	loc2 = tr1;
	if (EIF_TEST(loc2)) {
		loc1 = F1413_16854(loc2);
		tr1 = RTCCL(arg1);
		tb1 = F1337_15721(RTCW(loc1), tr1, ((EIF_INTEGER_32) 1L));
		if (tb1) {
			tr1 = RTCCL(arg1);
			
			eif_put_reference_item(RTCW(loc1),1,tr1);
			Result = '\0';
			tb1 = F1413_16857(loc2, loc1);
			if (tb1) {
				tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_POINTER, EIF_REFERENCE, EIF_REFERENCE)) *(EIF_POINTER *)(loc2+ _PTROFF_4_3_0_3_0_2_))(
					*(EIF_POINTER *)(loc2+ _PTROFF_4_3_0_3_0_1_),
					*(EIF_REFERENCE *)(loc2 + _REFACS_1_), loc1);
				;
				tb1 = tb1;
				Result = tb1;
			}
		} else {
			RTLE;
			return (EIF_BOOLEAN) (EIF_BOOLEAN) 0;
		}
	} else {
		RTLE;
		return (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	}
	RTLE;
	return Result;
}

void EIF_Minit583 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
