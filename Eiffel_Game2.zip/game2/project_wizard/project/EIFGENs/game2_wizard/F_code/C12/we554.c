/*
 * Code for class WEL_REFERENCE_TRACKABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "we554.h"
#include "eif_object_id.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {WEL_REFERENCE_TRACKABLE}.object_id */
EIF_INTEGER_32 F773_11162 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O10120[dtype-772]) == ((EIF_INTEGER_32) 0L))) {
		ti4_1 = F772_11156(Current, Current);
		*(EIF_INTEGER_32 *)(Current + O10120[dtype-772]) = (EIF_INTEGER_32) ti4_1;
	}
	RTLE;
	return (EIF_INTEGER_32) *(EIF_INTEGER_32 *)(Current + O10120[dtype-772]);
}

/* {WEL_REFERENCE_TRACKABLE}.enable_reference_tracking */
void F773_11163 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	RTCDT;
	RTLD;
	
	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTGC;
	*(EIF_BOOLEAN *)(Current + O10109[dtype-772]) = (EIF_BOOLEAN) (EIF_BOOLEAN) 1;
	if ((EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11798[dtype-1129])) {
		*(EIF_INTEGER_32 *)(Current + O10112[dtype-772]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 1L);
	} else {
		*(EIF_INTEGER_32 *)(Current + O10112[dtype-772]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) -1L);
	}
	tr1 = RTOSCF(11171,F773_11171,(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(eif_optimize_return = 1, (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R8692[Dtype(tr1)-695])(RTCW(tr1)));
	*(EIF_INTEGER_32 *)(Current + O10121[dtype-772]) = (EIF_INTEGER_32) ti4_1;
	tr1 = RTOSCF(11171,F773_11171,(Current));
	ti4_1 = *(EIF_INTEGER_32 *)(Current + O10121[dtype-772]);
	F697_9148(RTCW(tr1), (EIF_INTEGER_32) (ti4_1 + ((EIF_INTEGER_32) 1L)));
	RTLE;
}

/* {WEL_REFERENCE_TRACKABLE}.decrement_reference */
void F773_11164 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O10112[dtype-772]) > ((EIF_INTEGER_32) 0L))) {
		(*(EIF_INTEGER_32 *)(Current + O10112[dtype-772]))--;
		if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O10112[dtype-772]) == ((EIF_INTEGER_32) 0L))) {
			(FUNCTION_CAST(void, (EIF_REFERENCE)) R10119[dtype-1135])(Current);
		}
	} else {
	}
	RTLE;
}

/* {WEL_REFERENCE_TRACKABLE}.increment_reference */
void F773_11165 (EIF_REFERENCE Current)
{
	GTCX
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	if ((EIF_BOOLEAN) (*(EIF_INTEGER_32 *)(Current + O10112[dtype-772]) > ((EIF_INTEGER_32) 0L))) {
		(*(EIF_INTEGER_32 *)(Current + O10112[dtype-772]))++;
	}
	RTLE;
}

/* {WEL_REFERENCE_TRACKABLE}.dispose */
void F773_11166 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 ti4_1;
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if (F1130_13378(Current)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11798[dtype-1129]);
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10119[dtype-1135])(Current);
	}
	if ((EIF_BOOLEAN)(*(EIF_INTEGER_32 *)(Current + O10120[dtype-772]) != ((EIF_INTEGER_32) 0L))) {
		ti4_1 = *(EIF_INTEGER_32 *)(Current + O10120[dtype-772]);
		eif_object_id_free(ti4_1);
		*(EIF_INTEGER_32 *)(Current + O10120[dtype-772]) = (EIF_INTEGER_32) ((EIF_INTEGER_32) 0L);
	}
	RTLE;
}

/* {WEL_REFERENCE_TRACKABLE}.delete */
void F773_11167 (EIF_REFERENCE Current)
{
	GTCX
	EIF_BOOLEAN tb1;
	RTCDT;
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	tb1 = '\0';
	if (F1130_13378(Current)) {
		tb1 = (EIF_BOOLEAN) !*(EIF_BOOLEAN *)(Current + O11798[dtype-1129]);
	}
	if (tb1) {
		(FUNCTION_CAST(void, (EIF_REFERENCE)) R10119[dtype-1135])(Current);
	}
	RTLE;
}

/* {WEL_REFERENCE_TRACKABLE}.internal_number_id_cell */
static EIF_REFERENCE F773_11171_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (11171);
#define Result RTOSR(11171)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,696,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 696, _OBJSIZ_0_0_0_1_0_0_0_0_);
	}
	F697_9148(RTCW(tr1), ((EIF_INTEGER_32) 0L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (11171);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F773_11171 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11171,F773_11171_body,(Current));
}

/* {WEL_REFERENCE_TRACKABLE}.internal_id_list */
static EIF_REFERENCE F773_11172_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(2);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLIU(2);
	
	RTEV;
	RTGC;
	RTOSP (11172);
#define Result RTOSR(11172)
	RTOC_NEW(Result);
	{
		static EIF_TYPE_INDEX typarr0[] = {0xFF01,1058,1366,0xFFFF};
		EIF_TYPE typres0;
		static EIF_TYPE typcache0 = {INVALID_DTYPE, 0};
		
		typres0 = (typcache0.id != INVALID_DTYPE ? typcache0 : (typcache0 = eif_compound_id(Dftype(Current), typarr0)));
		tr1 = RTLNS(typres0.id, 1058, _OBJSIZ_1_1_0_1_0_0_0_0_);
	}
	F1059_11529(RTCW(tr1), ((EIF_INTEGER_32) 10L));
	Result = (EIF_REFERENCE) tr1;
	RTOSE (11172);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F773_11172 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11172,F773_11172_body,(Current));
}

void EIF_Minit554 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
