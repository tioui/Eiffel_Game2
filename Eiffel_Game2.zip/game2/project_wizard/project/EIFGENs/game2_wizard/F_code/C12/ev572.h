
#ifndef _C12_ev572_
#define _C12_ev572_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1081_11659(EIF_REFERENCE);
extern void F1081_11660(EIF_REFERENCE, EIF_REFERENCE);
extern void F1081_11661(EIF_REFERENCE, EIF_REFERENCE);
extern void EIF_Minit572(void);
extern EIF_REFERENCE __A572_166_2();
extern void F1079_11653(EIF_REFERENCE);
extern void F1075_11629(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE __A572_167_2();
extern void F1081_11660(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE _A572_166_2();
extern void F1596_21501(EIF_REFERENCE);
extern void F1081_11661(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE _A572_167_2();
extern void F1596_21502(EIF_REFERENCE);
extern EIF_TYPE_INDEX Y8500[];
extern EIF_TYPE_INDEX *Y8500_gen_type [];

#ifdef __cplusplus
}
#endif

#endif
