
#ifndef _C12_ev550_
#define _C12_ev550_

#ifdef __cplusplus
extern "C" {
#endif

extern void F770_11145(EIF_REFERENCE, EIF_REFERENCE);
extern void F770_11146(EIF_REFERENCE);
extern void F770_11147(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_BOOLEAN F770_11148(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F770_11149(EIF_REFERENCE);
extern void EIF_Minit550(void);
extern void F1606_21682(EIF_REFERENCE, EIF_BOOLEAN);
extern EIF_BOOLEAN F1592_21420(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
