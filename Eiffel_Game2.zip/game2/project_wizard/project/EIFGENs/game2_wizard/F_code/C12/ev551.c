/*
 * Code for class EV_WEL_TOOLTIPABLE
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev551.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_WEL_TOOLTIPABLE}.tooltip */
EIF_REFERENCE F771_11150 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTCDT;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,tr1);
	RTLR(2,Result);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10104[dtype-770]) == NULL)) {
		tr1 = RTLNS(eif_new_type(1422, 0x01).id, 1422, _OBJSIZ_1_1_0_3_0_0_0_0_);
		F1419_17415(RTCW(tr1));
		RTLE;
		return (EIF_REFERENCE) tr1;
	} else {
		tr1 = *(EIF_REFERENCE *)(Current + O10104[dtype-770]);
		Result = F1_14(tr1);
	}
	RTLE;
	return Result;
}

/* {EV_WEL_TOOLTIPABLE}.set_tooltip */
void F771_11151 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	EIF_BOOLEAN tb2;
	RTCDT;
	RTLD;
	
	RTLI(5);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLR(4,loc2);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1487, 0x01).id, 1487, _OBJSIZ_2_0_0_0_0_0_0_0_);
	F1479_19077(RTCW(tr1));
	loc1 = *(EIF_REFERENCE *)(RTCW(tr1) + _REFACS_1_);
	loc1 = F1607_21780(RTCW(loc1));
	loc1 = RTRV(eif_new_type(1832, 0x00), loc1);
	RTCT0("l_app_not_void", EX_CHECK);
	if ((EIF_BOOLEAN)(loc1 != NULL)) {
		RTCK0;
	} else {
		RTCF0;
	}
	tb1 = (FUNCTION_CAST(EIF_BOOLEAN, (EIF_REFERENCE)) R15003[Dtype(arg1)-1422])(RTCW(arg1));
	if ((EIF_BOOLEAN) !tb1) {
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10103[dtype-770]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O10103[dtype-770]);
			F1822_25721(RTCW(tr1), arg1);
			tb1 = '\01';
			if (!(EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10104[dtype-770]) == NULL)) {
				tr1 = *(EIF_REFERENCE *)(Current + O10104[dtype-770]);
				tb2 = F617_9087(RTCW(tr1));
				tb1 = tb2;
			}
			if (tb1) {
				tr1 = RTOSCF(26042,F1833_26042,(RTCW(loc1)));
				F1848_26652(RTCW(tr1), *(EIF_REFERENCE *)(Current + O10103[dtype-770]));
			} else {
				tr1 = RTOSCF(26042,F1833_26042,(RTCW(loc1)));
				F1848_26655(RTCW(tr1), *(EIF_REFERENCE *)(Current + O10103[dtype-770]));
			}
		} else {
			loc2 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R10105[dtype-770])(Current);
			if ((EIF_BOOLEAN)(loc2 != NULL)) {
				tr1 = RTLNSMART(eif_new_type(1821, 0).id);
				F1822_25705(RTCW(tr1));
				RTAR(Current, tr1);
				*(EIF_REFERENCE *)(Current + O10103[dtype-770]) = (EIF_REFERENCE) tr1;
				tr1 = *(EIF_REFERENCE *)(Current + O10103[dtype-770]);
				F1822_25721(RTCW(tr1), arg1);
				tr1 = *(EIF_REFERENCE *)(Current + O10103[dtype-770]);
				F1822_25715(RTCW(tr1), (EIF_INTEGER_32) (((EIF_INTEGER_32) 16L) + ((EIF_INTEGER_32) 1L)));
				tr1 = *(EIF_REFERENCE *)(Current + O10103[dtype-770]);
				F1822_25717(RTCW(tr1), loc2);
				tr1 = RTOSCF(26042,F1833_26042,(RTCW(loc1)));
				F1848_26652(RTCW(tr1), *(EIF_REFERENCE *)(Current + O10103[dtype-770]));
			}
		}
	} else {
		tb1 = '\0';
		if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10104[dtype-770]) != NULL)) {
			tr1 = *(EIF_REFERENCE *)(Current + O10104[dtype-770]);
			tb2 = F617_9087(RTCW(tr1));
			tb1 = (EIF_BOOLEAN) !tb2;
		}
		if (tb1) {
			RTCT0("tool_info_not_void", EX_CHECK);
			if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10103[dtype-770]) != NULL)) {
				RTCK0;
			} else {
				RTCF0;
			}
			tr1 = RTOSCF(26042,F1833_26042,(RTCW(loc1)));
			F1848_26654(RTCW(tr1), *(EIF_REFERENCE *)(Current + O10103[dtype-770]));
		}
	}
	tr1 = F1419_17474(RTCW(arg1));
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current + O10104[dtype-770]) = (EIF_REFERENCE) tr1;
	if ((EIF_BOOLEAN)(*(EIF_REFERENCE *)(Current + O10104[dtype-770]) == arg1)) {
		tr1 = F1419_17474(RTCW(arg1));
		tr1 = F1_14(tr1);
		RTAR(Current, tr1);
		*(EIF_REFERENCE *)(Current + O10104[dtype-770]) = (EIF_REFERENCE) tr1;
	}
	RTLE;
}

/* {EV_WEL_TOOLTIPABLE}.tool_info */
static EIF_REFERENCE F771_11152_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F771_11152 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O10103[Dtype(Current) - 770]);
	if (!r) {
		if (RTAT(eif_new_type(1821, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F771_11152_body (Current));
			*(EIF_REFERENCE *)(Current + O10103[Dtype(Current) - 770]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WEL_TOOLTIPABLE}.internal_tooltip_string */
static EIF_REFERENCE F771_11153_body (EIF_REFERENCE Current)
{
	GTCX
	
	
	RTGC;
	return (EIF_REFERENCE) 0;
}

EIF_REFERENCE F771_11153 (EIF_REFERENCE Current)
{
	EIF_REFERENCE r;
	r = *(EIF_REFERENCE *)(Current + O10104[Dtype(Current) - 770]);
	if (!r) {
		if (RTAT(eif_new_type(1422, 0))) {
			GTCX
			RTLD;
			RTLI(1);
			RTLR(0,Current);
			RTLIU(1);
			r = (F771_11153_body (Current));
			*(EIF_REFERENCE *)(Current + O10104[Dtype(Current) - 770]) = r;
			RTAR(Current, r);
			RTLE;
		}
	}
	return r;
}


/* {EV_WEL_TOOLTIPABLE}.tooltip_window */
EIF_REFERENCE F771_11154 (EIF_REFERENCE Current)
{
	GTCX
	
	
	return (EIF_REFERENCE) NULL;
}

void EIF_Minit551 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
