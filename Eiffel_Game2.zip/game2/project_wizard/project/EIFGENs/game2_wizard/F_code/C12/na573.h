
#ifndef _C12_na573_
#define _C12_na573_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_INTEGER_32 F1083_11700(EIF_REFERENCE, EIF_POINTER);
extern EIF_NATURAL_64 F1083_11701(EIF_REFERENCE, EIF_POINTER);
extern void EIF_Minit573(void);

#ifdef __cplusplus
}
#endif

#endif
