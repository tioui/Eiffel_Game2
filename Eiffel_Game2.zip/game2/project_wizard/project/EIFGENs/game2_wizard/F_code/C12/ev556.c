/*
 * Code for class EV_GDI_ALLOCATED_PENS
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev556.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_GDI_ALLOCATED_PENS}.get */
EIF_REFERENCE F1032_11192 (EIF_REFERENCE Current, EIF_INTEGER_32 arg1, EIF_INTEGER_32 arg2, EIF_REFERENCE arg3)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,Current);
	RTLR(1,loc1);
	RTLR(2,arg3);
	RTLR(3,Result);
	RTLR(4,tr1);
	RTLIU(5);
	
	RTGC;
	(*(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_))++;
	loc1 = RTOSCF(11193,F1032_11193,(Current));
	F1411_16838(RTCW(loc1), arg1, arg2, arg3);
	if (F317_7668(Current, loc1)) {
		Result = F317_7670(Current, *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_1_));
	} else {
		tr1 = RTLNS(eif_new_type(1147, 0x01).id, 1147, _OBJSIZ_0_2_0_3_0_1_0_0_);
		F1148_13581(RTCW(tr1), arg1, arg2, arg3);
		Result = (EIF_REFERENCE) tr1;
		F773_11163(RTCW(Result));
		loc1 = F1_14(loc1);
		F1410_16827(RTCW(loc1), Result);
		F1410_16826(RTCW(loc1), *(EIF_INTEGER_32 *)(Current+ _LNGOFF_1_0_0_2_));
		F317_7669(Current, loc1);
	}
	RTLE;
	return Result;
}

/* {EV_GDI_ALLOCATED_PENS}.reusable_search_object */
static EIF_REFERENCE F1032_11193_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	

	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,loc2);
	RTLIU(3);
	
	RTEV;
	RTGC;
	RTOSP (11193);
#define Result RTOSR(11193)
	RTOC_NEW(Result);
	tr1 = RTLNS(eif_new_type(1725, 0x01).id, 1725, _OBJSIZ_0_0_0_1_0_0_0_0_);
	F1726_24065(RTCW(tr1));
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1191, 0x01).id, 1191, _OBJSIZ_0_1_0_0_0_1_0_0_);
	F1192_14500(RTCW(tr1), ((EIF_INTEGER_32) 0L), loc1, ((EIF_INTEGER_32) 0L));
	loc2 = (EIF_REFERENCE) tr1;
	tr1 = RTLNS(eif_new_type(1410, 0x01).id, 1410, _OBJSIZ_1_0_0_8_0_0_0_0_);
	F1411_16829(RTCW(tr1), ((EIF_INTEGER_32) 0L), ((EIF_INTEGER_32) 1L), loc2);
	Result = (EIF_REFERENCE) tr1;
	RTOSE (11193);
	RTLE;
	RTEE;
	return Result;
#undef Result
}

EIF_REFERENCE F1032_11193 (EIF_REFERENCE Current)
{
	GTCX
	return RTOSCF(11193,F1032_11193_body,(Current));
}

void EIF_Minit556 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
