/*
 * Code for class EXECUTION_ENVIRONMENT
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ex574.h"
#include "eif_dir.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EXECUTION_ENVIRONMENT}.current_working_path */
EIF_REFERENCE F1084_11704 (EIF_REFERENCE Current)
{
	GTCX
	EIF_INTEGER_32 loc1 = (EIF_INTEGER_32) 0;
	EIF_INTEGER_32 loc2 = (EIF_INTEGER_32) 0;
	EIF_REFERENCE loc3 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE tr2 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc3);
	RTLR(1,tr1);
	RTLR(2,tr2);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	loc1 = (EIF_INTEGER_32) ((EIF_INTEGER_32) 50L);
	tr1 = RTLNS(eif_new_type(1118, 0x01).id, 1118, _OBJSIZ_0_1_0_1_0_1_1_0_);
	F1119_12367(RTCW(tr1), loc1);
	loc3 = (EIF_REFERENCE) tr1;
	tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
	loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
	if ((EIF_BOOLEAN)(loc2 == ((EIF_INTEGER_32) -1L))) {
		tr1 = RTLNS(eif_new_type(1288, 0x01).id, 1288, _OBJSIZ_2_1_0_0_0_0_0_0_);
		tr2 = RTMS_EX_H(".",1,46);
		F1289_15605(RTCW(tr1), tr2);
		Result = (EIF_REFERENCE) tr1;
	} else {
		if ((EIF_BOOLEAN) (loc2 > loc1)) {
			loc1 = (EIF_INTEGER_32) loc2;
			F1119_12457(RTCW(loc3), loc1);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			loc2 = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) tp1, (EIF_INTEGER) loc1);
		}
		if ((EIF_BOOLEAN) ((EIF_BOOLEAN) (loc2 > ((EIF_INTEGER_32) 0L)) && (EIF_BOOLEAN) (loc2 <= loc1))) {
			tr1 = RTLNS(eif_new_type(1288, 0x01).id, 1288, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tp1 = *(EIF_POINTER *)(RTCW(loc3)+ _PTROFF_0_1_0_1_0_0_);
			F1289_15609(RTCW(tr1), tp1);
			Result = (EIF_REFERENCE) tr1;
		} else {
			tr1 = RTLNS(eif_new_type(1288, 0x01).id, 1288, _OBJSIZ_2_1_0_0_0_0_0_0_);
			tr2 = RTMS_EX_H(".",1,46);
			F1289_15605(RTCW(tr1), tr2);
			Result = (EIF_REFERENCE) tr1;
		}
	}
	RTLE;
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.change_working_path */
void F1084_11718 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_POINTER tp1;
	EIF_INTEGER_32 ti4_1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc1);
	RTLR(1,arg1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	loc1 = F1289_15646(RTCW(arg1));
	tp1 = *(EIF_POINTER *)(RTCW(loc1)+ _PTROFF_0_1_0_1_0_0_);
	ti4_1 = (EIF_INTEGER_32) eif_chdir((EIF_FILENAME) tp1);
	*(EIF_INTEGER_32 *)(Current+ _LNGOFF_0_0_0_0_) = (EIF_INTEGER_32) ti4_1;
	RTLE;
}

/* {EXECUTION_ENVIRONMENT}.eif_dir_current */
EIF_INTEGER_32 F1084_11727 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_INTEGER_32 arg2)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_dir_current((EIF_FILENAME) arg1, (EIF_INTEGER) arg2);
	
	return Result;
}

/* {EXECUTION_ENVIRONMENT}.eif_chdir */
EIF_INTEGER_32 F1084_11730 (EIF_REFERENCE Current, EIF_POINTER arg1)
{
	GTCX
	EIF_INTEGER_32 Result = ((EIF_INTEGER_32) 0);
	
	
	Result = (EIF_INTEGER_32) eif_chdir((EIF_FILENAME) arg1);
	
	return Result;
}

void EIF_Minit574 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
