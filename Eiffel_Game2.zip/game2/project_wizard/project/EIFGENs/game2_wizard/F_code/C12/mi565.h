
#ifndef _C12_mi565_
#define _C12_mi565_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1044_11290(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,11291)
static EIF_REFERENCE F1044_11291_body(EIF_REFERENCE);
extern EIF_REFERENCE F1044_11291(EIF_REFERENCE);
extern void EIF_Minit565(void);
extern void F1424_17760(EIF_REFERENCE, EIF_REFERENCE);
extern EIF_REFERENCE F1290_15689(EIF_REFERENCE);
extern void F1053_11501(EIF_REFERENCE);
extern EIF_REFERENCE F1_5(EIF_REFERENCE);
extern void F1421_17564(EIF_REFERENCE, EIF_REFERENCE);
extern void F357_8167(EIF_REFERENCE, EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
