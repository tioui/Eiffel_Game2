
#ifndef _C12_ev582_
#define _C12_ev582_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F1091_11888(EIF_REFERENCE);
RTOSHF (EIF_REFERENCE,11891)
static EIF_REFERENCE F1091_11891_body(EIF_REFERENCE);
extern EIF_REFERENCE F1091_11891(EIF_REFERENCE);
extern void EIF_Minit582(void);
extern void F1479_19077(EIF_REFERENCE);
extern EIF_REFERENCE F1488_19323(EIF_REFERENCE);

#ifdef __cplusplus
}
#endif

#endif
