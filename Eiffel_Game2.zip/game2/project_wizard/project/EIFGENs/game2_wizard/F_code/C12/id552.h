
#ifndef _C12_id552_
#define _C12_id552_

#ifdef __cplusplus
extern "C" {
#endif

extern EIF_REFERENCE F772_11155(EIF_REFERENCE, EIF_INTEGER_32);
extern EIF_INTEGER_32 F772_11156(EIF_REFERENCE, EIF_REFERENCE);
extern void F772_11157(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit552(void);

#ifdef __cplusplus
}
#endif

#endif
