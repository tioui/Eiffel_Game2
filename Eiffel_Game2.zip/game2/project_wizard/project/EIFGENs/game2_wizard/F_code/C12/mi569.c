/*
 * Code for class MISMATCH_INFORMATION
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "mi569.h"
#include <eif_retrieve.h>
#include "../C33/ha1623.h"
#include "../C12/mi569.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {MISMATCH_INFORMATION}.default_create */
void F1053_11501 (EIF_REFERENCE Current)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,Current);
	RTLIU(1);
	
	RTGC;
	F1047_11377(Current, ((EIF_INTEGER_32) 5L));
	RTOSCP(11511,F1053_11511,(Current));
	RTLE;
}

/* {MISMATCH_INFORMATION}.class_name */
EIF_REFERENCE F1053_11502 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLR(2,tr1);
	RTLR(3,Result);
	RTLIU(4);
	
	RTGC;
	RTCT0(NULL, EX_CHECK);
	tr1 = RTOSCF(11505,F1053_11505,(Current));
	tr1 = F1047_11381(Current, tr1);
	loc1 = RTCCL(tr1);
	loc1 = RTRV(eif_new_type(1423, 0x01),loc1);
	if (EIF_TEST(loc1)) {
		RTCK0;
	} else {
		RTCF0;
	}
	Result = (EIF_REFERENCE) loc1;
	RTLE;
	return Result;
}

/* {MISMATCH_INFORMATION}.stored_version */
EIF_REFERENCE F1053_11503 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_7_);
}


/* {MISMATCH_INFORMATION}.current_version */
EIF_REFERENCE F1053_11504 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current + _REFACS_8_);
}


/* {MISMATCH_INFORMATION}.type_name_key */

EIF_REFERENCE F1053_11505 (EIF_REFERENCE Current)
{
	GTCX
	RTOSC (11505,RTMS_EX_H("_type_name",10,803527013));
}

/* {MISMATCH_INFORMATION}.out */
EIF_REFERENCE F1053_11508 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_INTEGER_32 ti4_1;
	EIF_INTEGER_32 ti4_2;
	EIF_REFERENCE Result = ((EIF_REFERENCE) 0);
	
	RTLD;
	
	RTLI(5);
	RTLR(0,tr1);
	RTLR(1,Current);
	RTLR(2,Result);
	RTLR(3,loc2);
	RTLR(4,loc1);
	RTLIU(5);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1423, 0x01).id, 1423, _OBJSIZ_1_1_0_3_0_0_0_0_);
	ti4_1 = *(EIF_INTEGER_32 *)(RTCV(F1053_11502(Current))+ _LNGOFF_1_1_0_2_);
	ti4_2 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_);
	F1421_17562(RTCW(tr1), (EIF_INTEGER_32) ((EIF_INTEGER_32) (((EIF_INTEGER_32) 20L) + ti4_1) + (EIF_INTEGER_32) (((EIF_INTEGER_32) 40L) * ti4_2)));
	Result = (EIF_REFERENCE) tr1;
	tr1 = RTMS_EX_H("Attributes of original class ",29,488257824);
	F1424_17760(RTCW(Result), tr1);
	tr1 = F1053_11502(Current);
	F1424_17760(RTCW(Result), tr1);
	tr1 = RTMS_EX_H(": ",2,14880);
	F1424_17760(RTCW(Result), tr1);
	ti4_1 = *(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_);
	F1424_17764(RTCW(Result), (EIF_INTEGER_32) (ti4_1 - ((EIF_INTEGER_32) 1L)));
	tr1 = RTMS_EX_H(" item",5,1769481581);
	F1424_17760(RTCW(Result), tr1);
	if ((EIF_BOOLEAN)((EIF_INTEGER_32) (*(EIF_INTEGER_32 *)(Current+ _LNGOFF_9_3_0_6_) - ((EIF_INTEGER_32) 1L)) != ((EIF_INTEGER_32) 1L))) {
		F1424_17774(RTCW(Result), (EIF_CHARACTER_8) 's');
	}
	F1424_17774(RTCW(Result), (EIF_CHARACTER_8) '\012');
	F1047_11415(Current);
	for (;;) {
		if (F1047_11410(Current)) break;
		loc2 = F1047_11388(Current);
		if (!RTEQ(loc2, RTOSCF(11505,F1053_11505,(Current)))) {
			tr1 = RTMS_EX_H("  ",2,8224);
			F1424_17760(RTCW(Result), tr1);
			if ((EIF_BOOLEAN)(loc2 == NULL)) {
				tr1 = RTMS_EX_H("Void",4,1450142052);
				F1424_17760(RTCW(Result), tr1);
			} else {
				F1424_17760(RTCW(Result), loc2);
			}
			tr1 = RTMS_EX_H(": ",2,14880);
			F1424_17760(RTCW(Result), tr1);
			loc1 = F1047_11387(Current);
			if ((EIF_BOOLEAN)(loc1 == NULL)) {
				tr1 = RTMS_EX_H("Void",4,1450142052);
				F1424_17760(RTCW(Result), tr1);
			} else {
				tr1 = (FUNCTION_CAST(EIF_REFERENCE, (EIF_REFERENCE)) R28[Dtype(loc1)-0])(RTCW(loc1));
				F1424_17760(RTCW(Result), tr1);
			}
			F1424_17774(RTCW(Result), (EIF_CHARACTER_8) '\012');
		}
		F1047_11416(Current);
	}
	RTLE;
	return Result;
}

/* {MISMATCH_INFORMATION}.internal_put */
void F1053_11509 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(4);
	RTLR(0,loc1);
	RTLR(1,tr1);
	RTLR(2,arg1);
	RTLR(3,Current);
	RTLIU(4);
	
	RTGC;
	tr1 = RTLNS(eif_new_type(1423, 0x01).id, 1423, _OBJSIZ_1_1_0_3_0_0_0_0_);
	F1421_17565(RTCW(tr1), arg2);
	loc1 = (EIF_REFERENCE) tr1;
	tr1 = RTCCL(arg1);
	F1047_11422(Current, tr1, loc1);
	RTLE;
}

/* {MISMATCH_INFORMATION}.set_string_versions */
void F1053_11510 (EIF_REFERENCE Current, EIF_POINTER arg1, EIF_POINTER arg2)
{
	GTCX
	EIF_POINTER loc1 = (EIF_POINTER) 0;
	EIF_REFERENCE loc2 = (EIF_REFERENCE) 0;
	EIF_REFERENCE tr1 = NULL;
	EIF_BOOLEAN tb1;
	RTLD;
	
	RTLI(3);
	RTLR(0,loc2);
	RTLR(1,tr1);
	RTLR(2,Current);
	RTLIU(3);
	
	RTGC;
	if ((EIF_BOOLEAN)(arg1 != loc1)) {
		tr1 = RTLNS(eif_new_type(1426, 0x01).id, 1426, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1421_17565(RTCW(tr1), arg1);
		loc2 = (EIF_REFERENCE) tr1;
		tb1 = F1427_17892(RTCW(loc2));
		if (tb1) {
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
		} else {
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) loc2;
		}
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_7_) = (EIF_REFERENCE) NULL;
	}
	if ((EIF_BOOLEAN)(arg2 != loc1)) {
		tr1 = RTLNS(eif_new_type(1426, 0x01).id, 1426, _OBJSIZ_1_0_0_4_0_0_0_0_);
		F1421_17565(RTCW(tr1), arg2);
		loc2 = (EIF_REFERENCE) tr1;
		tb1 = F1427_17892(RTCW(loc2));
		if (tb1) {
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
		} else {
			RTAR(Current, loc2);
			*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) loc2;
		}
	} else {
		*(EIF_REFERENCE *)(Current + _REFACS_8_) = (EIF_REFERENCE) NULL;
	}
	RTLE;
}

/* {MISMATCH_INFORMATION}.set_callback_pointers */
static void F1053_11511_body (EIF_REFERENCE Current)
{
	GTCX
	RTEX;
	

	
	RTEV;
	RTOSP (11511);
	F1053_11512(Current, Current, (EIF_POINTER) F1047_11431, (EIF_POINTER) F1053_11509, (EIF_POINTER) F1053_11510);
	RTOSE (11511);
	RTEE;
#undef Result
}

void F1053_11511 (EIF_REFERENCE Current)
{
	GTCX
	RTOSCP(11511,F1053_11511_body,(Current));
}

/* {MISMATCH_INFORMATION}.set_mismatch_information_access */
void F1053_11512 (EIF_REFERENCE Current, EIF_REFERENCE arg1, EIF_POINTER arg2, EIF_POINTER arg3, EIF_POINTER arg4)
{
	GTCX
	RTLD;
	
	RTLI(1);
	RTLR(0,arg1);
	RTLIU(1);
	
	{
		EIF_OBJECT larg1 = &arg1;
		EIF_POINTER larg2 = arg2;
		EIF_POINTER larg3 = arg3;
		EIF_POINTER larg4 = arg4;set_mismatch_information_access((EIF_OBJECT) larg1, (EIF_PROCEDURE) larg2, (EIF_PROCEDURE) larg3, (EIF_PROCEDURE) larg4);
		
	}
	RTLE;
}

void EIF_Minit569 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
