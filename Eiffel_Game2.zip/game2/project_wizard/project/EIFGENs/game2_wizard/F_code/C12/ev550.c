/*
 * Code for class EV_APPLICATION_HANDLER
 */

#include "eif_eiffel.h"
#include "../E1/estructure.h"
#include "../E1/eoffsets.h"

#include "ev550.h"

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif


#ifdef __cplusplus
extern "C" {
#endif

/* {EV_APPLICATION_HANDLER}.make */
void F770_11145 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_REFERENCE tr1 = NULL;
	RTLD;
	
	RTLI(3);
	RTLR(0,Current);
	RTLR(1,arg1);
	RTLR(2,tr1);
	RTLIU(3);
	
	RTGC;
	tr1 = *(EIF_REFERENCE *)(RTCW(arg1) + _REFACS_1_);
	RTAR(Current, tr1);
	*(EIF_REFERENCE *)(Current) = (EIF_REFERENCE) tr1;
	RTLE;
}

/* {EV_APPLICATION_HANDLER}.launch */
void F770_11146 (EIF_REFERENCE Current)
{
	GTCX
	EIF_REFERENCE loc1 = (EIF_REFERENCE) 0;
	RTLD;
	
	RTLI(2);
	RTLR(0,loc1);
	RTLR(1,Current);
	RTLIU(2);
	
	RTGC;
	loc1 = *(EIF_REFERENCE *)(Current);
	for (;;) {
		if (F770_11148(Current, loc1)) break;
		F770_11147(Current, loc1);
	}
	RTLE;
}

/* {EV_APPLICATION_HANDLER}.process_application_event_queue */
void F770_11147 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	
	
	F1606_21682(RTCW(arg1), (EIF_BOOLEAN) 1);
}

/* {EV_APPLICATION_HANDLER}.is_application_destroyed */
EIF_BOOLEAN F770_11148 (EIF_REFERENCE Current, EIF_REFERENCE arg1)
{
	GTCX
	EIF_BOOLEAN tb1;
	
	
	tb1 = F1592_21420(RTCW(arg1));
	return (EIF_BOOLEAN) tb1;
}

/* {EV_APPLICATION_HANDLER}.application_i */
EIF_REFERENCE F770_11149 (EIF_REFERENCE Current)
{
	return *(EIF_REFERENCE *)(Current);
}


void EIF_Minit550 (void)
{
	GTCX
}


#ifdef __cplusplus
}
#endif
