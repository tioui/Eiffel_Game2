
#ifndef _C12_ha561_
#define _C12_ha561_

#ifdef __cplusplus
extern "C" {
#endif

extern void F1036_11212(EIF_REFERENCE, EIF_INTEGER_32);
extern void EIF_Minit561(void);

#ifdef __cplusplus
}
#endif

#endif
