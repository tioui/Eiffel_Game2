Copy the C_lib_win (current directory) into the Eiffel Game Lib directory. Copy all .dll files of the directory DLL into the root directory of your project using the Eiffel Game Lib.
