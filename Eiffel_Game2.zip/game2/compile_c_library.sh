#!/bin/sh
cd Clib
finish_freezing -library
