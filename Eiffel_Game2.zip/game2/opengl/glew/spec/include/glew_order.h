#ifndef GLEW_ORDER_H
#define GLEW_ORDER_H

#include<GL/glew.h>
#include<GL/gl.h>
#include<GL/glu.h>

#endif /* GLEW_ORDER_H */
