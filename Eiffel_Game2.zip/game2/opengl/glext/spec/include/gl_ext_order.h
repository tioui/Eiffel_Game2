#ifndef GLEXT_ORDER_H
#define GLEXT_ORDER_H

#ifdef _MSC_VER
#define EPOXY_DLL
#endif

#include <epoxy/gl.h>
#include <GL/glu.h>

#endif /* GLEXT_ORDER_H */
