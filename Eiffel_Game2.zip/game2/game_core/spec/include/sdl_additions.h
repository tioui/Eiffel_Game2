#ifndef CORE_MORE_H
#define CORE_MORE_H
#include <SDL.h>
#include "cpf_additions.h"


void setSDLRWops(SDL_RWops *rwop,CustomPackageFileInfos* cpfInfos);


#endif
